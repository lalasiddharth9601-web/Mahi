package com.vinit.mahi

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONObject

/** Safe string read from a JSONObject (JSON null becomes an empty string). */
fun JSONObject.s(k: String): String {
    val v = opt(k)
    return if (v == null || v == JSONObject.NULL) "" else v.toString()
}

object Store {
    private lateinit var app: Context

    fun init(c: Context) {
        if (!::app.isInitialized) app = c.applicationContext
    }

    private val prefs get() = app.getSharedPreferences("mahi", Context.MODE_PRIVATE)

    var apiKey: String
        get() = prefs.getString("key", "") ?: ""
        set(v) { prefs.edit().putString("key", v.trim()).apply() }

    var mode: String
        get() = prefs.getString("mode", "sid") ?: "sid"
        set(v) { prefs.edit().putString("mode", v).apply() }

    var naturalVoice: Boolean
        get() = prefs.getBoolean("natural", true)
        set(v) { prefs.edit().putBoolean("natural", v).apply() }

    var handsFree: Boolean
        get() = prefs.getBoolean("hands", false)
        set(v) { prefs.edit().putBoolean("hands", v).apply() }

    var lastTtsErr: String
        get() = prefs.getString("ttsErr", "") ?: ""
        set(v) { prefs.edit().putString("ttsErr", v).apply() }

    var liveMode: Boolean
        get() = prefs.getBoolean("live", true)
        set(v) { prefs.edit().putBoolean("live", v).apply() }

    var goodLive: Int
        get() = prefs.getInt("goodLive", -1)
        set(v) { prefs.edit().putInt("goodLive", v).apply() }

    var liveStatus: String
        get() = prefs.getString("liveStatus", "") ?: ""
        set(v) { prefs.edit().putString("liveStatus", v).apply() }

    var screenUntil: Long
        get() = prefs.getLong("screenUntil", 0L)
        set(v) { prefs.edit().putLong("screenUntil", v).apply() }

    var goodLive2: Int
        get() = prefs.getInt("goodLive2", -1)
        set(v) { prefs.edit().putInt("goodLive2", v).apply() }

    var confirmContacts: Boolean
        get() = prefs.getBoolean("confirmContacts", true)
        set(v) { prefs.edit().putBoolean("confirmContacts", v).apply() }

    var setupDone: Boolean
        get() = prefs.getBoolean("setupDone", false)
        set(v) { prefs.edit().putBoolean("setupDone", v).apply() }

    var alwaysSetup: Boolean
        get() = prefs.getBoolean("alwaysSetup", false)
        set(v) { prefs.edit().putBoolean("alwaysSetup", v).apply() }

    var accSeen: Boolean
        get() = prefs.getBoolean("accSeen", false)
        set(v) { prefs.edit().putBoolean("accSeen", v).apply() }

    var lastAccNote: Long
        get() = prefs.getLong("lastAccNote", 0L)
        set(v) { prefs.edit().putLong("lastAccNote", v).apply() }

    var goodText: String
        get() = prefs.getString("goodText", "") ?: ""
        set(v) { prefs.edit().putString("goodText", v).apply() }

    var goodTts: Int
        get() = prefs.getInt("goodTts", -1)
        set(v) { prefs.edit().putInt("goodTts", v).apply() }

    private class Db(c: Context) : SQLiteOpenHelper(c, "mahi.db", null, 2) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL("CREATE TABLE msgs(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, role TEXT, text TEXT)")
            db.execSQL("CREATE TABLE facts(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, fact TEXT)")
            db.execSQL("CREATE TABLE notes(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, who TEXT, msg TEXT, done INTEGER)")
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            if (oldVersion < 2) {
                db.execSQL("CREATE TABLE IF NOT EXISTS notes(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, who TEXT, msg TEXT, done INTEGER)")
            }
        }
    }

    private val db: SQLiteDatabase by lazy { Db(app).writableDatabase }

    fun addMsg(role: String, text: String) {
        val cv = ContentValues()
        cv.put("ts", System.currentTimeMillis())
        cv.put("role", role)
        cv.put("text", text)
        db.insert("msgs", null, cv)
    }

    /** Last n messages, oldest first, always starting with a "user" message. */
    fun recent(n: Int): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        db.rawQuery("SELECT role, text FROM msgs ORDER BY id DESC LIMIT $n", null).use { c ->
            while (c.moveToNext()) out.add(Pair(c.getString(0), c.getString(1)))
        }
        out.reverse()
        while (out.isNotEmpty() && out[0].first != "user") out.removeAt(0)
        return out
    }

    fun addFact(f: String) {
        val fact = f.trim()
        if (fact.isEmpty()) return
        var exists = false
        db.rawQuery("SELECT 1 FROM facts WHERE fact = ?", arrayOf(fact)).use { c ->
            exists = c.moveToFirst()
        }
        if (exists) return
        val cv = ContentValues()
        cv.put("ts", System.currentTimeMillis())
        cv.put("fact", fact)
        db.insert("facts", null, cv)
    }

    fun facts(): List<String> {
        val out = ArrayList<String>()
        db.rawQuery("SELECT fact FROM facts ORDER BY id DESC LIMIT 80", null).use { c ->
            while (c.moveToNext()) out.add(c.getString(0))
        }
        out.reverse()
        return out
    }

    fun addNote(who: String, msg: String) {
        val cv = ContentValues()
        cv.put("ts", System.currentTimeMillis())
        cv.put("who", who)
        cv.put("msg", msg)
        cv.put("done", 0)
        db.insert("notes", null, cv)
    }

    /** Unread call notes as readable lines. */
    fun unreadNotes(): List<String> {
        val out = ArrayList<String>()
        val fmt = java.text.SimpleDateFormat("d MMM, hh:mm a", java.util.Locale.ENGLISH)
        db.rawQuery("SELECT ts, who, msg FROM notes WHERE done = 0 ORDER BY id", null).use { c ->
            while (c.moveToNext()) out.add(fmt.format(java.util.Date(c.getLong(0))) + " - " + c.getString(1) + ": " + c.getString(2))
        }
        return out
    }

    fun markNotesRead() {
        db.execSQL("UPDATE notes SET done = 1 WHERE done = 0")
    }
}
