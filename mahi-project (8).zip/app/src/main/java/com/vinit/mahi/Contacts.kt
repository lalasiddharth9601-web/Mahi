package com.vinit.mahi

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract

/** Finds the right contact even when the name is spoken in Hindi, e.g. "मम्मी" -> "Mummy" or "विनीत भैया" -> "Vineet Bhaiya". */
object Contacts {
    class Match(val name: String, val number: String, val score: Double = 0.0, val alt: String = "")

    private val groups: List<Set<String>> = listOf(
        setOf("mummy", "mumma", "mom", "mother", "maa", "mamma", "ammi", "mataji", "माँ", "मां", "मम्मी", "मम्मा", "मॉम", "माता"),
        setOf("papa", "pappa", "dad", "daddy", "father", "pitaji", "पापा", "पिताजी", "डैडी", "पिता"),
        setOf("bhaiya", "bhai", "bhaiyya", "brother", "bro", "भैया", "भाई", "भइया"),
        setOf("didi", "sister", "behen", "bahen", "behan", "दीदी", "बहन"),
        setOf("nani", "नानी"),
        setOf("nana", "नाना"),
        setOf("dadi", "दादी"),
        setOf("dada", "दादा"),
        setOf("chacha", "चाचा"),
        setOf("chachi", "चाची"),
        setOf("mama", "मामा"),
        setOf("mami", "मामी"),
        setOf("mausi", "मौसी"),
        setOf("bua", "बुआ"),
        setOf("tau", "ताऊ"),
        setOf("bhabhi", "भाभी")
    )

    private val dev: Map<Char, Char> = mapOf(
        'क' to 'k', 'ख' to 'k', 'ग' to 'g', 'घ' to 'g', 'ङ' to 'n',
        'च' to 'c', 'छ' to 'c', 'ज' to 'j', 'झ' to 'j', 'ञ' to 'n',
        'ट' to 't', 'ठ' to 't', 'ड' to 'd', 'ढ' to 'd', 'ण' to 'n',
        'त' to 't', 'थ' to 't', 'द' to 'd', 'ध' to 'd', 'न' to 'n',
        'प' to 'p', 'फ' to 'p', 'ब' to 'b', 'भ' to 'b', 'म' to 'm',
        'र' to 'r', 'ल' to 'l', 'व' to 'v', 'श' to 's', 'ष' to 's', 'स' to 's', 'ह' to 'h'
    )

    private fun isWordChar(ch: Char): Boolean {
        if (Character.isLetterOrDigit(ch)) return true
        val t = Character.getType(ch)
        return t == Character.NON_SPACING_MARK.toInt() || t == Character.COMBINING_SPACING_MARK.toInt()
    }

    private fun tokens(s: String): List<String> {
        val sb = StringBuilder()
        for (ch in s.lowercase()) sb.append(if (isWordChar(ch)) ch else ' ')
        return sb.toString().split(" ").filter { it.isNotEmpty() }
    }

    private fun groupOf(t: String): Int {
        for (i in groups.indices) if (groups[i].contains(t)) return i
        return -1
    }

    /** Sound skeleton: consonants only, same alphabet for Hindi and English spellings. */
    private fun skeleton(s: String): String {
        val out = StringBuilder()
        val low = s.lowercase()
        var prev = ' '
        for (i in low.indices) {
            val ch = low[i]
            var m: Char? = dev[ch]
            if (m == null) {
                when (ch) {
                    'a', 'e', 'i', 'o', 'u', 'y' -> m = null
                    'h' -> m = if (i > 0 && "kgcjtdpbs".indexOf(low[i - 1]) >= 0) null else 'h'
                    'c' -> m = if (i + 1 < low.length && low[i + 1] == 'h') 'c' else 'k'
                    'q', 'x' -> m = 'k'
                    'z' -> m = 'j'
                    'f' -> m = 'p'
                    'w' -> m = 'v'
                    else -> m = if (ch in 'a'..'z') ch else null
                }
            }
            if (m != null && m != prev) {
                out.append(m)
                prev = m
            }
        }
        return out.toString()
    }

    private fun lev(a: String, b: String): Int {
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1)
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(minOf(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost)
            }
            prev = cur
        }
        return prev[b.length]
    }

    private fun sim(a: String, b: String): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        return 1.0 - lev(a, b).toDouble() / maxOf(a.length, b.length).toDouble()
    }

    private fun score(query: String, name: String): Double {
        val qt = tokens(query)
        val ct = tokens(name)
        if (qt.isEmpty() || ct.isEmpty()) return 0.0
        if (qt.joinToString(" ") == ct.joinToString(" ")) return 2.0
        val qg = HashSet<Int>()
        for (t in qt) {
            val g = groupOf(t)
            if (g >= 0) qg.add(g)
        }
        val cg = HashSet<Int>()
        for (t in ct) {
            val g = groupOf(t)
            if (g >= 0) cg.add(g)
        }
        val qCore = qt.filter { groupOf(it) < 0 }
        val cCore = ct.filter { groupOf(it) < 0 }
        val shared = qg.any { cg.contains(it) }
        if (qCore.isEmpty()) {
            if (!shared) return 0.0
            return 1.0 + (if (cCore.isEmpty()) 0.05 else 0.0)
        }
        val qs = skeleton(qCore.joinToString(""))
        val base = if (cCore.isEmpty()) ct else cCore
        var s = sim(qs, skeleton(base.joinToString("")))
        for (t in base) s = maxOf(s, sim(qs, skeleton(t)))
        if (qg.isNotEmpty()) {
            if (shared) s += 0.1 else if (cg.isNotEmpty()) s -= 0.2
        }
        return s
    }

    private fun allPhones(c: Context): List<Match> {
        val out = ArrayList<Match>()
        if (c.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return out
        try {
            val cur = c.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ), null, null, null
            )
            if (cur != null) {
                cur.use {
                    while (it.moveToNext()) {
                        val n = it.getString(0) ?: continue
                        val num = it.getString(1) ?: continue
                        out.add(Match(n, num))
                    }
                }
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun names(c: Context, limit: Int): List<String> {
        val set = LinkedHashSet<String>()
        for (m in allPhones(c)) {
            if (set.size >= limit) break
            set.add(m.name)
        }
        return set.toList()
    }

    fun find(c: Context, who: String): Match? {
        var best: Match? = null
        var bestScore = 0.0
        var second: Match? = null
        var secondScore = 0.0
        for (m in allPhones(c)) {
            val sc = score(who, m.name)
            val b = best
            if (b != null && m.name == b.name) {
                continue
            }
            if (sc > bestScore || (sc == bestScore && b != null && m.name.length < b.name.length)) {
                second = best
                secondScore = bestScore
                bestScore = sc
                best = m
            } else if (sc > secondScore) {
                second = m
                secondScore = sc
            }
        }
        val bm = best ?: return null
        if (bestScore < 0.7) return null
        val sm = second
        var alt = ""
        if (sm != null && sm.name != bm.name && secondScore >= 0.7 && bestScore - secondScore < 0.05 && bestScore < 1.9) alt = sm.name
        return Match(bm.name, bm.number, bestScore, alt)
    }
}
