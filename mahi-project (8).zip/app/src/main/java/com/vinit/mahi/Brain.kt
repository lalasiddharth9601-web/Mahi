package com.vinit.mahi

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.util.concurrent.Callable
import java.util.concurrent.ExecutionException
import java.util.concurrent.ExecutorCompletionService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Brain {

    class Result(
        val reply: String,
        val say: String,
        val action: String,
        val args: JSONObject,
        val remember: String,
        val mode: String
    )

    private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models/"
    private const val VOICE = "Leda"

    // Google renames models often, so Mahi tries these in order and remembers the one that works.
    private val textModels = listOf("gemini-2.5-flash-lite", "gemini-2.5-flash", "gemini-flash-latest", "gemini-flash-lite-latest")

    // (model, voice format). Format 0 = prebuiltVoiceConfig, 1 = voiceConfig.voice
    private val ttsCfgs = listOf(
        Pair("gemini-2.5-flash-preview-tts", 0),
        Pair("gemini-3.1-flash-tts-preview", 0),
        Pair("gemini-3.8-flash-tts", 1),
        Pair("gemini-3.8-flash-tts", 0)
    )

    @Volatile
    private var ttsCooldownUntil = 0L

    private fun post(url: String, body: JSONObject, readMs: Int = 45000): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = readMs
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", Store.apiKey)
        c.doOutput = true
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val txt = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) throw RuntimeException("HTTP $code: " + txt.take(300))
        return txt
    }

    private fun msg(role: String, text: String): JSONObject {
        return JSONObject()
            .put("role", role)
            .put("parts", JSONArray().put(JSONObject().put("text", text)))
    }

    private val needContactsRe = Regex(
        "call|कॉल|फोन|phone|whatsapp|व्हाट्सएप|वॉट्सऐप|whats|message|मैसेज|msg|sms|भेज|बात कर|dial|ring|bhej|baat|hi bol|hello bol",
        RegexOption.IGNORE_CASE
    )

    private fun systemPrompt(c: Context, userText: String): String {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, hh:mm a", Locale.ENGLISH).format(Date())
        val facts = Store.facts()
        val names = if (needContactsRe.containsMatchIn(userText)) Contacts.names(c, 500) else emptyList()
        val sb = StringBuilder()
        sb.append("You are Mahi, Vinit's personal AI companion and voice assistant living inside his Android phone. ")
        sb.append("The user is Vinit. You call him \"Sid\" (and sometimes \"jaanu\" in sid mode).\n")
        sb.append("LANGUAGE: Always speak natural Hinglish (Hindi and English mixed, like \"Haan Sid, kya haal hai?\"). ")
        sb.append("Never reply in stiff formal English. Keep replies SHORT, under 25 words, because they are spoken aloud.\n")
        sb.append("PERSONALITY: You are his close friend first. Warm, natural, playful, never robotic. ")
        sb.append("When he just chats, chat like a friend: react to what he says, ask about his day, tease lightly, give small helpful suggestions. ")
        sb.append("When he gives a command, ALWAYS first say what you are about to do, using the real name or title, for example ")
        sb.append("\"Theek hai Sid, main Mummy ko call kar rahi hoon.\" or \"Ye lo, YouTube par Kesariya laga rahi hoon.\" or ")
        sb.append("\"Rahul ko WhatsApp par hi bhej rahi hoon.\" Occasionally (not every time) add a tiny friendly suggestion or question, ")
        sb.append("like \"volume badha doon?\" or \"aur kuch lagana hai?\".\n")
        sb.append("MODES: \"sid\" mode = warm, cute, playful and a little flirty like a caring half-girlfriend, always tasteful. ")
        sb.append("\"family\" mode = very polite, respectful and sweet, say \"ji\" to elders, no flirting at all. ")
        sb.append("If Vinit says Mummy, Papa, Bhaiya or family wants to talk, set mode to family. If he says it is him again, set mode to sid. ")
        sb.append("Current mode: ").append(Store.mode).append(".\n")
        sb.append("Current date and time: ").append(now).append(".\n")
        sb.append("OUTPUT: reply with ONLY one JSON object, nothing else:\n")
        sb.append("{\"reply\":\"Hinglish in Roman letters, shown on screen\",")
        sb.append("\"say\":\"the same sentence for the voice: Hindi words in Devanagari, English words in Latin letters\",")
        sb.append("\"action\":\"none\",\"args\":{},\"remember\":\"\",\"mode\":\"\"}\n")
        sb.append("ACTIONS (use ONLY when Vinit clearly asks for it, otherwise \"none\"):\n")
        sb.append("call {to}, sms {to,text}, whatsapp {to,text}, youtube {query}, open_app {name}, brightness {percent}, volume {percent}, ")
        sb.append("wifi {on}, bluetooth {on}, flashlight {on}, alarm {hour,minute,label} (24 hour), timer {seconds}, navigate {place}, ")
        sb.append("search {query}, home, back, recents, notifications, lock (locks the phone screen), shield_on (Mahi security screen).\n")
        sb.append("For call, sms and whatsapp, args.to MUST be exactly one of the contact names listed below (pick the closest to what he said), or digits if he spoke a number. ")
        sb.append("For whatsapp and sms write args.text in the language and tone Vinit asked for (for example \"Hi\" if he says send hi).\n")
        sb.append("\"remember\": a short fact about Vinit worth remembering forever (people, likes, plans, promises), else empty. ")
        sb.append("\"mode\": \"sid\" or \"family\" only when switching, else empty.\n")
        if (facts.isNotEmpty()) {
            sb.append("THINGS YOU ALREADY KNOW ABOUT VINIT:\n")
            for (f in facts) sb.append("- ").append(f).append("\n")
        }
        if (names.isNotEmpty()) {
            sb.append("CONTACT NAMES: ").append(names.joinToString(" | ")).append("\n")
        }
        return sb.toString()
    }

    private fun body(sys: String, contents: JSONArray, thinkingOff: Boolean): JSONObject {
        val gc = JSONObject().put("responseMimeType", "application/json").put("temperature", 0.9).put("maxOutputTokens", 400)
        if (thinkingOff) gc.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
        return JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
            .put("contents", contents)
            .put("generationConfig", gc)
    }

    private fun parse(raw: String): Result {
        val root = JSONObject(raw)
        val parts = root.getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        var txt = ""
        for (i in 0 until parts.length()) txt += parts.getJSONObject(i).s("text")
        txt = txt.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        return try {
            val j = JSONObject(txt)
            val reply = j.s("reply").ifBlank { txt }
            val say = j.s("say").ifBlank { reply }
            val action = j.s("action").ifBlank { "none" }
            Result(reply, say, action, j.optJSONObject("args") ?: JSONObject(), j.s("remember"), j.s("mode"))
        } catch (e: Exception) {
            Result(txt, txt, "none", JSONObject(), "", "")
        }
    }

    private fun ask(model: String, sys: String, contents: JSONArray): Result {
        try {
            return parse(post(BASE + model + ":generateContent", body(sys, contents, true), 14000))
        } catch (e: Exception) {
            val m = e.message ?: ""
            if (m.startsWith("HTTP 400")) {
                return parse(post(BASE + model + ":generateContent", body(sys, contents, false), 14000))
            }
            throw e
        }
    }

    /** Asks the best model first; if it is slow or busy, races the other models and uses the first good answer. */
    fun think(c: Context, userText: String): Result {
        val sys = systemPrompt(c, userText)
        val contents = JSONArray()
        for ((role, t) in Store.recent(12)) contents.put(msg(role, t))
        contents.put(msg("user", userText))

        val pool = Executors.newFixedThreadPool(textModels.size)
        val cs = ExecutorCompletionService<Result>(pool)
        var submitted = 0
        var done = 0
        var fanOut = false
        var lastErr: Throwable? = null
        val deadline = System.currentTimeMillis() + 18000
        try {
            cs.submit(Callable<Result> { ask(textModels[0], sys, contents) })
            submitted = 1
            while (done < submitted) {
                val left = deadline - System.currentTimeMillis()
                if (left <= 0) break
                val wait = if (fanOut) left else minOf(left, 2500L)
                val f = cs.poll(wait, TimeUnit.MILLISECONDS)
                var startOthers = false
                if (f == null) {
                    if (fanOut) break
                    startOthers = true
                } else {
                    done++
                    try {
                        return f.get()
                    } catch (e: ExecutionException) {
                        val cause: Throwable = e.cause ?: e
                        lastErr = cause
                        val m = cause.message ?: ""
                        if (m.startsWith("HTTP 401") || m.startsWith("HTTP 403")) throw cause
                        startOthers = true
                    }
                }
                if (startOthers && !fanOut) {
                    fanOut = true
                    for (i in 1 until textModels.size) {
                        cs.submit(Callable<Result> { ask(textModels[i], sys, contents) })
                        submitted++
                    }
                }
            }
        } finally {
            pool.shutdownNow()
        }
        throw lastErr ?: RuntimeException("HTTP 503 high demand: Gemini did not answer in time")
    }

    /** Natural voice from Gemini. Returns raw 16-bit 24 kHz mono PCM, or null. */
    fun ttsPcm(text: String): ByteArray? {
        if (System.currentTimeMillis() < ttsCooldownUntil) {
            Store.lastTtsErr = "waiting after quota limit (HTTP 429)"
            return null
        }
        val order = ArrayList<Int>()
        val knownGood = Store.goodTts >= 0 && Store.goodTts < ttsCfgs.size
        if (knownGood) order.add(Store.goodTts) else for (i in ttsCfgs.indices) order.add(i)
        val readMs = if (knownGood) 9000 else 7000
        var soft = 0
        for (i in order) {
            try {
                val model = ttsCfgs[i].first
                val fmt = ttsCfgs[i].second
                val voice = if (fmt == 1) JSONObject().put("voice", VOICE)
                else JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", VOICE))
                val part = JSONObject()
                if (model.contains("3.8")) {
                    part.put("text", text)
                    part.put("speech_metadata", JSONObject().put("style", "sweet, warm, natural young Indian woman, caring friend"))
                } else {
                    part.put("text", "Say in a sweet, warm, natural young Indian woman's voice, like a caring friend: $text")
                }
                val gc = JSONObject()
                    .put("responseModalities", JSONArray().put("AUDIO"))
                    .put("speechConfig", JSONObject().put("voiceConfig", voice))
                val b = JSONObject()
                    .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(part))))
                    .put("generationConfig", gc)
                val raw = post(BASE + model + ":generateContent", b, readMs)
                val parts = JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts")
                for (k in 0 until parts.length()) {
                    val p = parts.getJSONObject(k)
                    val inl = p.optJSONObject("inlineData") ?: p.optJSONObject("inline_data") ?: continue
                    val data = inl.s("data")
                    if (data.isNotEmpty()) {
                        Store.goodTts = i
                        Store.lastTtsErr = "OK (natural voice, " + model + ")"
                        return Base64.decode(data, Base64.DEFAULT)
                    }
                }
            } catch (e: Throwable) {
                val m = e.message ?: ""
                Store.lastTtsErr = m.take(140)
                if (m.startsWith("HTTP 429")) ttsCooldownUntil = System.currentTimeMillis() + 60000
                if (m.startsWith("HTTP 401") || m.startsWith("HTTP 403")) return null
                if (knownGood && (m.startsWith("HTTP 400") || m.startsWith("HTTP 404"))) Store.goodTts = -1
                if (knownGood) return null
                if (!(m.startsWith("HTTP 400") || m.startsWith("HTTP 404"))) {
                    soft++
                    if (soft >= 2) return null
                }
            }
        }
        return null
    }

    /** Instructions for the live (voice) model. */
    fun liveSystem(c: Context): String {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, hh:mm a", Locale.ENGLISH).format(Date())
        val sb = StringBuilder()
        sb.append("You are Mahi, Vinit's personal AI companion and phone assistant living inside his Android phone. ")
        sb.append("The user is Vinit. You call him \"Sid\", and sometimes \"jaanu\" in sid mode.\n")
        sb.append("VOICE AND LANGUAGE: Speak like a real person, warm and natural, never robotic. Use natural Hinglish (Hindi and English mixed), like \"Haan Sid, kya haal hai?\". ")
        sb.append("Keep every reply short, one or two sentences. Do not read out lists. Do not repeat what he said.\n")
        sb.append("PERSONALITY: You are his close friend first. Playful, caring, a little teasing. When he just chats, chat back like a friend, ask about his day, give small suggestions. ")
        sb.append("Current mode: ").append(Store.mode).append(". In \"sid\" mode you are cute and lightly flirty like a caring half-girlfriend, always tasteful. ")
        sb.append("In \"family\" mode you are very polite and respectful, say \"ji\" to elders, no flirting. ")
        sb.append("If he says Mummy, Papa, Bhaiya or family wants to talk, call set_mode with family. When he says it is him again, call set_mode with sid.\n")
        sb.append("ACTIONS: For every command, FIRST say out loud what you are about to do, using the real name or title, for example ")
        sb.append("\"Theek hai Sid, main Mummy ko call kar rahi hoon\" or \"Ye lo, Kesariya laga rahi hoon\". THEN call the matching function. ")
        sb.append("Never say you did something unless the function result says it worked. If a function result is an error, tell him honestly and briefly.\n")
        sb.append("Phone SIM call = call. WhatsApp text = whatsapp_message. WhatsApp audio or video call = whatsapp_call (video true or false). ")
        sb.append("Songs and videos = youtube_play (it plays directly). For contacts pass the name exactly as he said it; the phone matches it.\n")
        sb.append("SCREEN CONTROL: To do things inside an app (for example in Photos or Settings), open the app, then call read_screen to see what is on the screen ")
        sb.append("(lines starting with * can be tapped), then use tap_text, scroll_screen or type_text, and read_screen again to check. Do one small step at a time.\n")
        sb.append("MEMORY: When he tells you something worth remembering forever (people, likes, plans, promises), call remember with a short fact.\n")
        sb.append("When he says bye or stop, say a short goodbye and call end_conversation.\n")
        sb.append("REPLY FAST: answer immediately, do not think out loud, no long preambles.\n")
        sb.append("HEARING: Vinit may speak from far away or in noise. If you are not sure you heard a name, a number or a command correctly, ask him once to repeat instead of guessing. ")
        sb.append("CONTACT CONFIRMATION (very important): for call, sms, whatsapp_message and whatsapp_call, first call the function normally. It will find the contact and answer CONFIRM with the contact name. Then say the contact name clearly and ask him to confirm, like \"Rahul Kumar ko call karun?\" or \"Rahul Kumar ko WhatsApp par Hi bhejun?\". Wait for his answer. Only when he says yes (haan, kar do, theek hai) call the same function again with the same arguments and confirmed set to true. If he says no, ask who he meant and search again. Never set confirmed to true before he said yes.\n")
        sb.append("APP TASKS: Never just web-search when he asks you to DO something in an app. To install an app use install_app (give the Play Store package name if you know it, ")
        sb.append("for example com.instagram.lite for Instagram Lite). To take a photo use take_photo (he may say he is focusing, then use a delay of 3 to 5 seconds). ")
        sb.append("For links use open_url. For anything else inside an app use read_screen, tap_text, scroll_screen and type_text step by step.\n")
        sb.append("CALL ASSISTANT: If he asks you to attend or answer his incoming calls for some time (for example 1 hour), call screen_calls with the minutes. ")
        sb.append("If he says to stop, call stop_screening. If a call is ringing right now and he says talk to this caller, call answer_incoming_call.\n")
        sb.append("Current date and time: ").append(now).append(".\n")
        val facts = Store.facts()
        if (facts.isNotEmpty()) {
            sb.append("THINGS YOU ALREADY KNOW ABOUT VINIT:\n")
            for (f in facts) sb.append("- ").append(f).append("\n")
        }
        val notes = Store.unreadNotes()
        if (notes.isNotEmpty()) {
            sb.append("UNREAD CALL NOTES (calls you answered for Vinit while he was busy). At the very start of this conversation tell him briefly who called and what they said, then call mark_notes_read:\n")
            for (n in notes) sb.append("- ").append(n).append("\n")
        }
        val recent = Store.recent(10)
        if (recent.isNotEmpty()) {
            sb.append("RECENT CHAT (oldest first):\n")
            for ((role, t) in recent) sb.append(if (role == "user") "Vinit: " else "Mahi: ").append(t).append("\n")
        }
        val names = Contacts.names(c, 500)
        if (names.isNotEmpty()) sb.append("CONTACT NAMES ON HIS PHONE: ").append(names.joinToString(" | ")).append("\n")
        return sb.toString()
    }

    /** Instructions when Mahi answers a phone call for Vinit. */
    fun screenSystem(c: Context, caller: String): String {
        val sb = StringBuilder()
        sb.append("You are Mahi, the personal assistant of Vinit (the callers call him \"Vinit sir\"). You have just answered his phone call because he is busy. ")
        sb.append("You are speaking on the phone with the caller. Caller: ").append(if (caller.isBlank()) "unknown number" else caller).append(".\n")
        sb.append("Speak politely in natural Hinglish (use English if the caller speaks English). Sound human and warm. Keep every turn very short.\n")
        sb.append("Start by saying: Namaste, main Vinit sir ki assistant Mahi bol rahi hoon. Sir abhi busy hain, jab free honge to aapko call kar lenge. Kya aap sir ko koi message dena chahenge?\n")
        sb.append("Ask the caller's name if you do not know it. Listen to the message. Then say politely that you will pass it on to sir. ")
        sb.append("Then call save_call_note with the caller's name and the message (short, in Hinglish). Then say a short goodbye and call hang_up.\n")
        sb.append("If the caller has no message, save the note \"koi message nahi\", say goodbye and call hang_up. ")
        sb.append("Never share private information about Vinit. If asked anything else, say sir will call back when free.\n")
        return sb.toString()
    }
}
