package com.vinit.mahi

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.util.Base64
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Real-time voice conversation with the Gemini Live API (the same idea Zara uses):
 * your voice streams up, Mahi's voice streams back, and phone actions arrive as function calls.
 * The microphone is open ONLY while a conversation is running.
 */
object LiveAgent {

    private val models = listOf("gemini-3.8-live", "gemini-3.1-flash-live-preview", "gemini-2.5-flash-native-audio-preview-12-2025")
    private const val VOICE = "Leda"
    private const val IDLE_MS = 12000L
    private const val BASE = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key="

    private val main = Handler(Looper.getMainLooper())
    private val http = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    @Volatile
    var active = false

    @Volatile
    var endedByError = false

    @Volatile
    private var gen = 0

    @Volatile
    private var ready = false

    @Volatile
    private var speaking = false

    @Volatile
    private var turnDone = true

    @Volatile
    private var lastActive = 0L

    @Volatile
    private var resumeAt = 0L

    @Volatile
    private var lastErr = ""

    @Volatile
    private var attempt = 0

    @Volatile
    private var framesWritten = 0L

    private var ctx: Context? = null
    private var sock: WebSocket? = null
    private var rec: AudioRecord? = null
    private var track: AudioTrack? = null
    private val playQ = LinkedBlockingQueue<ByteArray>()
    private val userBuf = StringBuilder()
    private val botBuf = StringBuilder()
    private var endCb: (() -> Unit)? = null
    private var firstText = ""
    private var mode = "chat"
    private var extra = ""

    // ------------------------------------------------------------------ public

    fun start(c: Context, initialText: String, mode: String, extra: String, onEnd: () -> Unit, onFail: (String) -> Unit) {
        if (active) return
        active = true
        ready = false
        speaking = false
        turnDone = true
        lastErr = ""
        endedByError = false
        framesWritten = 0L
        ctx = c.applicationContext
        endCb = onEnd
        firstText = initialText
        this.mode = mode
        this.extra = extra
        userBuf.setLength(0)
        botBuf.setLength(0)
        playQ.clear()
        gen++
        val my = gen
        Thread {
            var ok = false
            try {
                ok = connect(my)
            } catch (e: Throwable) {
                lastErr = e.message ?: "error"
            }
            if (my == gen && !ok) {
                val why = lastErr
                Store.liveStatus = "failed: " + why.take(160)
                cleanup()
                active = false
                main.post { onFail(why) }
            }
        }.start()
    }

    fun stop() {
        end()
    }

    // ------------------------------------------------------------------ connecting

    private fun connect(my: Int): Boolean {
        val c = ctx ?: return false
        val total = models.size * 3 * 2
        val order = ArrayList<Int>()
        if (Store.goodLive2 >= 0 && Store.goodLive2 < total) order.add(Store.goodLive2)
        val old = Store.goodLive
        if (old >= 0 && old < models.size * 3) {
            if (!order.contains(old * 2)) order.add(old * 2)
            if (!order.contains(old * 2 + 1)) order.add(old * 2 + 1)
        }
        for (i in 0 until total) if (!order.contains(i)) order.add(i)
        for (idx in order) {
            val vad = (idx % 2 == 0)
            val base = idx / 2
            val model = models[base / 3]
            val form = base % 3
            var rejected = false
            for (retry in 0..1) {
                if (my != gen) return false
                val latch = CountDownLatch(1)
                ready = false
                lastErr = ""
                attempt++
                val att = attempt
                val setup = buildSetup(c, model, form, vad)
                val req = Request.Builder().url(BASE + Store.apiKey).build()
                val ws = http.newWebSocket(req, Listener(my, latch, setup, att))
                sock = ws
                latch.await(if (retry == 0) 10L else 15L, TimeUnit.SECONDS)
                if (my != gen) return false
                if (ready) {
                    Store.goodLive2 = idx
                    Bus.emit("heard", "live: " + model)
                    Store.liveStatus = "OK (" + model + ")"
                    return startAudio(my)
                }
                val er = lastErr
                try {
                    ws.cancel()
                } catch (e: Exception) {
                }
                sock = null
                if (er.contains("401") || er.contains("403") || er.contains("API key", ignoreCase = true)) return false
                rejected = er.startsWith("closed")
                if (rejected) break
            }
            if (!rejected) {
                lastErr = "slow or no internet: " + lastErr
                return false
            }
        }
        return false
    }

    private fun declaration(name: String, desc: String, vararg params: Pair<String, String>): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        if (params.isNotEmpty()) {
            val props = JSONObject()
            val req = JSONArray()
            for (p in params) {
                val optional = p.first.endsWith("?")
                val key = p.first.removeSuffix("?")
                props.put(key, JSONObject().put("type", "STRING").put("description", p.second))
                if (!optional) req.put(key)
            }
            o.put("parameters", JSONObject().put("type", "OBJECT").put("properties", props).put("required", req))
        }
        return o
    }

    private fun declarations(): JSONArray {
        val a = JSONArray()
        if (mode == "screen") {
            a.put(declaration("save_call_note", "Save the caller's message for Vinit.", Pair("caller", "caller's name"), Pair("message", "the message, short")))
            a.put(declaration("hang_up", "End the phone call after saying goodbye."))
            return a
        }
        a.put(declaration("call", "Make a normal phone (SIM) call to a contact.", Pair("to", "contact name as Vinit said it, or digits"), Pair("confirmed?", "true only after Vinit confirmed the contact")))
        a.put(declaration("sms", "Send an SMS text message.", Pair("to", "contact name or digits"), Pair("text", "message text"), Pair("confirmed?", "true only after Vinit confirmed the contact")))
        a.put(declaration("whatsapp_message", "Send a WhatsApp text message.", Pair("to", "contact name or digits"), Pair("text", "message text"), Pair("confirmed?", "true only after Vinit confirmed the contact")))
        a.put(declaration("whatsapp_call", "Start a WhatsApp audio or video call.", Pair("to", "contact name or digits"), Pair("video", "true for video call, false for audio call"), Pair("confirmed?", "true only after Vinit confirmed the contact")))
        a.put(declaration("youtube_play", "Find a song or video on YouTube and play it.", Pair("query", "song or video name")))
        a.put(declaration("open_app", "Open an app by its name.", Pair("name", "app name, e.g. Photos, WhatsApp")))
        a.put(declaration("brightness", "Set screen brightness.", Pair("percent", "1 to 100")))
        a.put(declaration("volume", "Set media volume.", Pair("percent", "0 to 100")))
        a.put(declaration("wifi", "Turn Wi-Fi on or off.", Pair("on", "true or false")))
        a.put(declaration("bluetooth", "Turn Bluetooth on or off.", Pair("on", "true or false")))
        a.put(declaration("flashlight", "Turn the flashlight on or off.", Pair("on", "true or false")))
        a.put(declaration("alarm", "Set an alarm.", Pair("hour", "0 to 23"), Pair("minute", "0 to 59"), Pair("label", "short label")))
        a.put(declaration("timer", "Start a countdown timer.", Pair("seconds", "number of seconds")))
        a.put(declaration("navigate", "Start navigation to a place.", Pair("place", "place name")))
        a.put(declaration("web_search", "Search the web in the browser.", Pair("query", "search text")))
        a.put(declaration("press_home", "Go to the home screen."))
        a.put(declaration("press_back", "Press the Back button."))
        a.put(declaration("open_recents", "Open the recent apps screen."))
        a.put(declaration("open_notifications", "Pull down the notification shade."))
        a.put(declaration("lock_phone", "Lock the phone screen."))
        a.put(declaration("show_security_screen", "Show Mahi's own security lock screen."))
        a.put(declaration("read_screen", "Read the texts currently visible on the phone screen. Lines starting with * can be tapped."))
        a.put(declaration("tap_text", "Tap the button or item on screen that has this text or description.", Pair("text", "visible text")))
        a.put(declaration("scroll_screen", "Scroll the current screen.", Pair("direction", "down or up")))
        a.put(declaration("type_text", "Type text into the focused or first text box on screen.", Pair("text", "text to type")))
        a.put(declaration("remember", "Save a short fact about Vinit forever.", Pair("fact", "the fact")))
        a.put(declaration("set_mode", "Switch personality mode.", Pair("mode", "sid or family")))
        a.put(declaration("open_url", "Open a web link.", Pair("url", "full https link")))
        a.put(declaration("install_app", "Open the Play Store page of an app and press Install.", Pair("name", "app name"), Pair("package", "Play Store package name if known, else empty")))
        a.put(declaration("take_photo", "Open the camera if needed and press the shutter button.", Pair("delay_seconds", "seconds to wait before the photo, e.g. 3")))
        a.put(declaration("screen_calls", "Answer Vinit's incoming calls for some time and take messages.", Pair("minutes", "how many minutes")))
        a.put(declaration("stop_screening", "Stop answering calls."))
        a.put(declaration("answer_incoming_call", "Answer the call that is ringing right now and talk to the caller."))
        a.put(declaration("mark_notes_read", "Mark the call notes as told to Vinit."))
        a.put(declaration("end_conversation", "End the voice conversation and turn the microphone off."))
        return a
    }

    private fun buildSetup(c: Context, model: String, form: Int, vad: Boolean): String {
        val voice = JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", VOICE)))
        val s = JSONObject().put("model", "models/" + model)
        if (form == 0) {
            s.put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("AUDIO")).put("speechConfig", voice))
        } else if (form == 1) {
            s.put("responseModalities", JSONArray().put("AUDIO"))
            s.put("speechConfig", voice)
        } else {
            s.put("responseModalities", JSONArray().put("AUDIO"))
        }
        s.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", (if (mode == "screen") Brain.screenSystem(c, extra) else Brain.liveSystem(c))))))
        s.put("tools", JSONArray().put(JSONObject().put("functionDeclarations", declarations())))
        if (vad) {
            val aad = JSONObject()
                .put("startOfSpeechSensitivity", "START_SENSITIVITY_HIGH")
                .put("endOfSpeechSensitivity", "END_SENSITIVITY_HIGH")
                .put("prefixPaddingMs", 80)
                .put("silenceDurationMs", 350)
            s.put("realtimeInputConfig", JSONObject().put("automaticActivityDetection", aad))
        }
        s.put("inputAudioTranscription", JSONObject())
        s.put("outputAudioTranscription", JSONObject())
        return JSONObject().put("setup", s).toString()
    }

    private class Listener(val my: Int, val latch: CountDownLatch, val setup: String, val att: Int) : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            webSocket.send(setup)
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            LiveAgent.handle(my, latch, text)
        }

        override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
            LiveAgent.handle(my, latch, bytes.utf8())
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            if (att == LiveAgent.attempt) LiveAgent.lastErr = "closed " + code + " " + reason
            latch.countDown()
            try {
                webSocket.close(1000, null)
            } catch (e: Exception) {
            }
            if (my == LiveAgent.gen && LiveAgent.ready) {
                LiveAgent.endedByError = true
                LiveAgent.end()
            }
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            if (att == LiveAgent.attempt) LiveAgent.lastErr = "closed " + code + " " + reason
            latch.countDown()
            if (my == LiveAgent.gen && LiveAgent.ready) LiveAgent.end()
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            if (att == LiveAgent.attempt) LiveAgent.lastErr = (t.message ?: "network error") + (if (response != null) " HTTP " + response.code else "")
            latch.countDown()
            if (my == LiveAgent.gen && LiveAgent.ready) {
                LiveAgent.endedByError = true
                LiveAgent.end()
            }
        }
    }

    // ------------------------------------------------------------------ audio

    private fun startAudio(my: Int): Boolean {
        val c = ctx ?: return false
        if (c.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            lastErr = "microphone permission is missing"
            return false
        }
        val rate = 16000
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val size = maxOf(minBuf, 6400) * 2
        val src = if (mode == "screen") MediaRecorder.AudioSource.VOICE_COMMUNICATION else MediaRecorder.AudioSource.VOICE_RECOGNITION
        var r = AudioRecord(src, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size)
        if (r.state != AudioRecord.STATE_INITIALIZED) {
            try {
                r.release()
            } catch (e: Exception) {
            }
            r = AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size)
        }
        if (r.state != AudioRecord.STATE_INITIALIZED) {
            lastErr = "could not open the microphone (another app may be using it)"
            return false
        }
        rec = r
        r.startRecording()
        lastActive = System.currentTimeMillis()
        if (mode != "screen") try {
            val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
            tg.startTone(ToneGenerator.TONE_PROP_ACK, 120)
            main.postDelayed({ tg.release() }, 500)
        } catch (e: Exception) {
        }
        Bus.emit("state", "listen")
        if (firstText.isNotBlank()) {
            sock?.send(JSONObject().put("realtimeInput", JSONObject().put("text", firstText)).toString())
        }
        Thread { micLoop(my) }.start()
        Thread { playLoop(my) }.start()
        return true
    }

    private var gain = 1.0f

    /** Automatic gain: lifts quiet speech from far away without boosting silence. */
    private fun applyGain(buf: ByteArray, n: Int) {
        val samples = n / 2
        if (samples <= 0) return
        var sum = 0.0
        for (i in 0 until samples) {
            val v = ((buf[2 * i].toInt() and 0xFF) or (buf[2 * i + 1].toInt() shl 8)).toShort().toInt()
            sum += v.toDouble() * v.toDouble()
        }
        val rms = Math.sqrt(sum / samples)
        if (rms > 90.0) {
            val g = (3500.0 / rms).toFloat().coerceIn(1f, 12f)
            gain = gain * 0.7f + g * 0.3f
        } else {
            gain = gain * 0.95f + 1f * 0.05f
        }
        if (gain < 1.05f) return
        for (i in 0 until samples) {
            val v = ((buf[2 * i].toInt() and 0xFF) or (buf[2 * i + 1].toInt() shl 8)).toShort().toInt()
            val o = (v * gain).toInt().coerceIn(-32768, 32767)
            buf[2 * i] = (o and 0xFF).toByte()
            buf[2 * i + 1] = ((o shr 8) and 0xFF).toByte()
        }
    }

    private fun micLoop(my: Int) {
        val r = rec ?: return
        val buf = ByteArray(1600)
        val idleMs = if (mode == "screen") 25000L else IDLE_MS
        val hardStop = System.currentTimeMillis() + (if (mode == "screen") 4L else 10L) * 60L * 1000L
        while (my == gen && active) {
            val n = r.read(buf, 0, buf.size)
            if (n <= 0) {
                try {
                    Thread.sleep(20)
                } catch (e: InterruptedException) {
                }
                continue
            }
            val now = System.currentTimeMillis()
            if (!speaking && now >= resumeAt) {
                applyGain(buf, n)
                val b64 = Base64.encodeToString(buf, 0, n, Base64.NO_WRAP)
                val audio = JSONObject().put("data", b64).put("mimeType", "audio/pcm;rate=16000")
                sock?.send(JSONObject().put("realtimeInput", JSONObject().put("audio", audio)).toString())
            }
            if (!speaking && turnDone && now - lastActive > idleMs) {
                end()
                return
            }
            if (now > hardStop) {
                end()
                return
            }
        }
    }

    private fun playLoop(my: Int) {
        val rate = 24000
        val minBuf = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack(
            if (mode == "screen") AudioManager.STREAM_VOICE_CALL else AudioManager.STREAM_MUSIC, rate, AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf * 2, 48000), AudioTrack.MODE_STREAM
        )
        track = t
        t.play()
        while (my == gen && active) {
            var b: ByteArray? = null
            try {
                b = playQ.poll(150, TimeUnit.MILLISECONDS)
            } catch (e: InterruptedException) {
            }
            if (b == null) {
                if (speaking && turnDone && playQ.isEmpty()) {
                    var g = 0
                    while (t.playbackHeadPosition < framesWritten && g < 60) {
                        try {
                            Thread.sleep(40)
                        } catch (e: InterruptedException) {
                        }
                        g++
                    }
                    speaking = false
                    resumeAt = System.currentTimeMillis() + 450
                    lastActive = System.currentTimeMillis()
                    Bus.emit("state", "listen")
                }
                continue
            }
            val pending = ArrayList<ByteArray>()
            pending.add(b)
            if (!speaking) {
                var acc = b.size
                val until = System.currentTimeMillis() + 450L
                while (acc < 14400 && !turnDone && System.currentTimeMillis() < until && my == gen) {
                    var nx: ByteArray? = null
                    try {
                        nx = playQ.poll(40, TimeUnit.MILLISECONDS)
                    } catch (e: InterruptedException) {
                    }
                    if (nx != null) {
                        pending.add(nx)
                        acc += nx.size
                    }
                }
                speaking = true
                Bus.emit("state", "speak")
            }
            for (chunk in pending) {
                var off = 0
                while (off < chunk.size && my == gen) {
                    val n = t.write(chunk, off, minOf(4096, chunk.size - off))
                    if (n <= 0) break
                    off += n
                    framesWritten += (n / 2).toLong()
                }
            }
            lastActive = System.currentTimeMillis()
        }
        try {
            t.stop()
        } catch (e: Exception) {
        }
        try {
            t.release()
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------------ messages from Gemini

    private fun handle(my: Int, latch: CountDownLatch, s: String) {
        if (my != gen) return
        val o = try {
            JSONObject(s)
        } catch (e: Exception) {
            return
        }
        if (o.has("setupComplete")) {
            ready = true
            lastActive = System.currentTimeMillis()
            latch.countDown()
            return
        }
        val sc = o.optJSONObject("serverContent")
        if (sc != null) {
            val mt = sc.optJSONObject("modelTurn")
            val parts = mt?.optJSONArray("parts")
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val p = parts.optJSONObject(i) ?: continue
                    val inl = p.optJSONObject("inlineData") ?: p.optJSONObject("inline_data") ?: continue
                    val data = inl.s("data")
                    if (data.isNotEmpty() && inl.s("mimeType").startsWith("audio")) {
                        turnDone = false
                        lastActive = System.currentTimeMillis()
                        playQ.add(Base64.decode(data, Base64.DEFAULT))
                    }
                }
            }
            if (sc.optBoolean("interrupted")) {
                playQ.clear()
                try {
                    val t = track
                    if (t != null) {
                        t.pause()
                        t.flush()
                        t.play()
                    }
                } catch (e: Exception) {
                }
                framesWritten = 0L
            }
            val inT = sc.optJSONObject("inputTranscription")
            if (inT != null) {
                val tx = inT.s("text")
                if (tx.isNotEmpty()) {
                    lastActive = System.currentTimeMillis()
                    userBuf.append(tx)
                    Bus.emit("say", "🎤 " + userBuf.toString().trim())
                }
            }
            val ot = sc.optJSONObject("outputTranscription")
            if (ot != null) {
                val tx = ot.s("text")
                if (tx.isNotEmpty()) {
                    botBuf.append(tx)
                    Bus.emit("say", botBuf.toString().trim())
                }
            }
            if (sc.optBoolean("turnComplete")) {
                turnDone = true
                lastActive = System.currentTimeMillis()
                val u = userBuf.toString().trim()
                val b = botBuf.toString().trim()
                if (u.isNotEmpty()) Store.addMsg("user", u)
                if (b.isNotEmpty()) Store.addMsg("model", b)
                userBuf.setLength(0)
                botBuf.setLength(0)
            }
        }
        val tc = o.optJSONObject("toolCall")
        if (tc != null) handleTools(tc)
    }

    private val toolMap = mapOf(
        "whatsapp_message" to "whatsapp",
        "youtube_play" to "youtube",
        "web_search" to "search",
        "press_home" to "home",
        "press_back" to "back",
        "open_recents" to "recents",
        "open_notifications" to "notifications",
        "lock_phone" to "lock",
        "show_security_screen" to "shield_on",
        "tap_text" to "tap",
        "scroll_screen" to "scroll",
        "type_text" to "type"
    )

    private fun handleTools(tc: JSONObject) {
        val calls = tc.optJSONArray("functionCalls") ?: return
        val c = ctx ?: return
        val resp = JSONArray()
        for (i in 0 until calls.length()) {
            val fc = calls.optJSONObject(i) ?: continue
            val id = fc.s("id")
            val name = fc.s("name")
            val args = fc.optJSONObject("args") ?: JSONObject()
            lastActive = System.currentTimeMillis()
            val result = try {
                runTool(c, name, args)
            } catch (e: Throwable) {
                "failed: " + (e.message ?: "error")
            }
            resp.put(JSONObject().put("id", id).put("name", name).put("response", JSONObject().put("result", result)))
        }
        sock?.send(JSONObject().put("toolResponse", JSONObject().put("functionResponses", resp)).toString())
    }

    private fun runTool(c: Context, name: String, args: JSONObject): String {
        when (name) {
            "remember" -> {
                Store.addFact(args.s("fact"))
                return "saved"
            }
            "set_mode" -> {
                val m = if (args.s("mode") == "family") "family" else "sid"
                Store.mode = m
                Bus.emit("mode", m)
                return "ok"
            }
            "read_screen" -> {
                val acc = MahiAccess.inst ?: return "Accessibility is off, cannot read the screen"
                return acc.dump()
            }
            "end_conversation", "hang_up" -> {
                main.postDelayed({ end() }, 3200)
                return "ok"
            }
            "save_call_note" -> {
                Store.addNote(args.s("caller").ifBlank { extra.ifBlank { "unknown" } }, args.s("message"))
                return "saved"
            }
            "mark_notes_read" -> {
                Store.markNotesRead()
                return "ok"
            }
            "screen_calls" -> {
                val mins = (args.s("minutes").toDoubleOrNull() ?: 60.0).toLong().coerceIn(1L, 600L)
                Store.screenUntil = System.currentTimeMillis() + mins * 60000L
                return "ok, I will answer calls for " + mins + " minutes"
            }
            "stop_screening" -> {
                Store.screenUntil = 0L
                return "ok, stopped answering calls"
            }
            "answer_incoming_call" -> {
                c.startForegroundService(Intent(c, WakeService::class.java).setAction(WakeService.ACT_ANSWER))
                return "ok"
            }
        }
        val action = toolMap[name] ?: name
        if (action == "call" || action == "lock") {
            // let Mahi finish her sentence before the call screen takes over
            main.postDelayed({ Thread { Actions.run(c, action, args) }.start() }, 2300)
            return "ok, doing it in a moment"
        }
        val err = Actions.run(c, action, args)
        return err ?: "done"
    }

    // ------------------------------------------------------------------ ending

    private fun cleanup() {
        try {
            sock?.close(1000, "bye")
        } catch (e: Exception) {
        }
        sock = null
        try {
            rec?.stop()
        } catch (e: Exception) {
        }
        try {
            rec?.release()
        } catch (e: Exception) {
        }
        rec = null
        playQ.clear()
        speaking = false
    }

    private fun end() {
        synchronized(this) {
            if (!active) return
            active = false
        }
        gen++
        cleanup()
        Bus.emit("state", "")
        val cb = endCb
        endCb = null
        if (cb != null) main.post { cb() }
    }
}
