package com.vinit.mahi

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var fromWake = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        )
        fromWake = intent.getBooleanExtra("wake", false)

        web = WebView(this)
        setContentView(web)
        web.setBackgroundColor(Color.parseColor("#d1d1db"))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                Bus.replay()
            }
        }
        Bus.ui = { t, v ->
            if (t == "idle") {
                runOnUiThread {
                    if (fromWake && Bus.last["shield"] != "on") moveTaskToBack(true)
                }
            } else {
                runOnUiThread {
                    web.evaluateJavascript(
                        "window.mahiNative && window.mahiNative(" + JSONObject.quote(t) + "," + JSONObject.quote(v) + ")",
                        null
                    )
                }
            }
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        fromWake = intent?.getBooleanExtra("wake", false) ?: false
    }

    override fun onResume() {
        super.onResume()
        Bus.visible(true)
    }

    override fun onPause() {
        Bus.visible(false)
        super.onPause()
    }

    override fun onBackPressed() {
        moveTaskToBack(true)
    }

    override fun onDestroy() {
        Bus.ui = null
        try {
            web.destroy()
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

    inner class Bridge {
        @JavascriptInterface
        fun manualListen() {
            val i = Intent(this@MainActivity, WakeService::class.java).setAction(WakeService.ACT_LISTEN)
            if (Build.VERSION.SDK_INT >= 26) this@MainActivity.startForegroundService(i) else this@MainActivity.startService(i)
        }

        @JavascriptInterface
        fun setMode(m: String) {
            Store.mode = if (m == "family") "family" else "sid"
        }

        @JavascriptInterface
        fun getMode(): String = Store.mode

        @JavascriptInterface
        fun openSetup() {
            this@MainActivity.startActivity(Intent(this@MainActivity, SetupActivity::class.java).putExtra("force", true))
        }
    }
}
