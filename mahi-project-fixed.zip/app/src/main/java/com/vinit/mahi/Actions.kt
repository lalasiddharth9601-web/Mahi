package com.vinit.mahi

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.app.SearchManager
import android.app.admin.DevicePolicyManager
import android.bluetooth.BluetoothAdapter
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telephony.SmsManager
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min

object Actions {

    private fun nt(i: Intent): Intent {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return i
    }

    private fun granted(c: Context, p: String): Boolean =
        c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    /** Converts Devanagari and Hinglish text into a normalized phonetic Latin key for accurate matching. */
    fun phoneticKey(input: String): String {
        val s = input.lowercase().trim()
        if (s.isEmpty()) return ""
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val ch = s[i]
            val mapped: String? = when (ch) {
                'अ' -> "a"
                'आ', 'ा' -> "a"
                'इ', 'ई', 'ि', 'ी' -> "i"
                'उ', 'ऊ', 'ु', 'ू' -> "u"
                'ए', 'ऐ', 'े', 'ै' -> "e"
                'ओ', 'औ', 'ो', 'ौ' -> "o"
                'ऋ', 'ृ' -> "ri"
                'ं', 'ँ' -> "n"
                'ः' -> "h"
                '्', '़' -> ""
                'क' -> "k"
                'ख' -> "kh"
                'ग' -> "g"
                'घ' -> "gh"
                'ङ' -> "n"
                'च' -> "ch"
                'छ' -> "chh"
                'ज' -> "j"
                'झ' -> "jh"
                'ञ' -> "n"
                'ट', 'त' -> "t"
                'ठ', 'थ' -> "th"
                'ड', 'द', 'ड़' -> "d"
                'ढ', 'ध', 'ढ़' -> "dh"
                'ण', 'न' -> "n"
                'प' -> "p"
                'फ' -> "f"
                'ब' -> "b"
                'भ' -> "bh"
                'म' -> "m"
                'य' -> "y"
                'र' -> "r"
                'ल' -> "l"
                'व' -> "v"
                'श', 'ष' -> "sh"
                'स' -> "s"
                'ह' -> "h"
                'क्ष' -> "ksh"
                'ज्ञ' -> "gy"
                else -> null
            }
            if (mapped != null) {
                sb.append(mapped)
                // Add implicit 'a' between two Devanagari consonants when no matra/halant follows
                val isConsonant = ch in 'क'..'ह'
                if (isConsonant && i + 1 < s.length) {
                    val next = s[i + 1]
                    val nextIsMatraOrVirama = next in '\u093E'..'\u094D' || next == '\u0902' || next == '\u0901'
                    if (!nextIsMatraOrVirama && next in '\u0900'..'\u097F') {
                        sb.append('a')
                    }
                }
            } else if (ch.isLetterOrDigit() || ch == ' ') {
                sb.append(ch)
            } else {
                sb.append(' ')
            }
            i++
        }
        return sb.toString()
            .replace("aa", "a")
            .replace("ee", "i")
            .replace("oo", "u")
            .replace("ph", "f")
            .replace("w", "v")
            .replace("z", "j")
            .replace("q", "k")
            .replace(Regex("([a-z])\\1+"), "$1")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun cleanContactQuery(raw: String): String {
        return raw.trim()
            .replace(Regex("(?i)\\b(ji|jii|ko|se|par|pe|ka|ki|ke|mera|meri|mere|bhai|sir|madam)\\b"), " ")
            .replace(Regex("(जी|को|से|पर|पे|का|की|के|मेरा|मेरी|मेरे)"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .ifEmpty { raw.trim() }
    }

    private val kinshipAliases = mapOf(
        "mummy" to listOf("mummy", "mom", "maa", "ma", "mata", "ammi", "ammiji", "mummyji"),
        "papa" to listOf("papa", "dad", "daddy", "pitaji", "pita", "abbu", "baba", "papaji"),
        "bhaiya" to listOf("bhaiya", "bhayya", "bhai", "brother", "bro", "bade bhaiya"),
        "didi" to listOf("didi", "di", "sister", "sis", "baji")
    )

    private fun expandAliases(qKey: String): Set<String> {
        val out = LinkedHashSet<String>()
        out.add(qKey)
        for ((_, group) in kinshipAliases) {
            val normGroup = group.map { phoneticKey(it) }
            if (normGroup.contains(qKey)) {
                out.addAll(normGroup)
            }
        }
        return out
    }

    private fun editSimilarity(a: String, b: String): Double {
        if (a == b) return 1.0
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val temp = dp[j]
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                dp[j] = min(min(dp[j - 1] + 1, dp[j] + 1), prev + cost)
                prev = temp
            }
        }
        val maxLen = max(a.length, b.length).toDouble()
        return (maxLen - dp[b.length]) / maxLen
    }

    fun contactNames(c: Context): List<String> {
        val out = LinkedHashSet<String>()
        if (!granted(c, Manifest.permission.READ_CONTACTS)) return emptyList()
        try {
            val cur = c.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME),
                null, null, null
            )
            cur?.use {
                while (it.moveToNext() && out.size < 400) {
                    val n = it.getString(0)?.trim()
                    if (!n.isNullOrBlank()) out.add(n)
                }
            }
        } catch (e: Exception) {
        }
        return out.toList()
    }

    fun contactNamesWithHints(c: Context): List<String> {
        return contactNames(c).take(250)
    }

    /**
     * High-precision contact number lookup:
     * Scores all contacts using exact, phonetic (Devanagari <-> Latin), token, and fuzzy similarity
     * so Mahi NEVER messages or calls the wrong person.
     */
    fun findNumber(c: Context, who: String): String? {
        val wRaw = who.trim()
        if (wRaw.isEmpty()) return null
        if (wRaw.none { it.isLetter() } && wRaw.count { it.isDigit() } >= 5) {
            return wRaw.filter { it.isDigit() || it == '+' }
        }
        if (!granted(c, Manifest.permission.READ_CONTACTS)) return null

        val cleaned = cleanContactQuery(wRaw)
        val qKey = phoneticKey(cleaned).ifEmpty { phoneticKey(wRaw) }
        if (qKey.isEmpty()) return null
        val qTokens = qKey.split(" ").filter { it.isNotEmpty() }
        val aliasKeys = expandAliases(qKey)

        var bestNum: String? = null
        var bestScore = 0

        try {
            val cur = c.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null, null, null
            )
            cur?.use {
                while (it.moveToNext()) {
                    val name = it.getString(0)?.trim() ?: continue
                    val num = it.getString(1)?.trim() ?: continue
                    if (name.isEmpty() || num.isEmpty()) continue

                    val nClean = cleanContactQuery(name)
                    val nKey = phoneticKey(nClean).ifEmpty { phoneticKey(name) }
                    if (nKey.isEmpty()) continue
                    val nTokens = nKey.split(" ").filter { it.isNotEmpty() }

                    var score = 0
                    // 1. Exact case-insensitive match
                    if (name.equals(wRaw, ignoreCase = true) || name.equals(cleaned, ignoreCase = true)) {
                        score = 1000
                    }
                    // 2. Exact phonetic full-name or kinship alias match
                    else if (aliasKeys.contains(nKey)) {
                        score = 960
                    }
                    // 3. Exact first-name or word-token match (e.g. "Rahul" matches "Rahul Sharma")
                    else if (nTokens.any { aliasKeys.contains(it) }) {
                        score = if (nTokens.first() in aliasKeys) 890 else 850
                    }
                    // 4. All query tokens present in contact tokens
                    else if (qTokens.isNotEmpty() && qTokens.all { qt -> nTokens.any { nt -> nt == qt || (qt.length >= 3 && nt.startsWith(qt)) } }) {
                        score = 810
                    }
                    // 5. Prefix match on first token (minimum 3 characters to prevent short-name false matches!)
                    else if (qKey.length >= 3 && nKey.startsWith(qKey)) {
                        score = 740
                    }
                    // 6. High phonetic edit similarity (>= 0.80) on full name or primary token
                    else {
                        val fullSim = editSimilarity(qKey, nKey)
                        val firstSim = if (nTokens.isNotEmpty() && qTokens.isNotEmpty()) editSimilarity(qTokens[0], nTokens[0]) else 0.0
                        val bestSim = max(fullSim, firstSim)
                        if (bestSim >= 0.80 && qKey.length >= 3) {
                            score = (bestSim * 700).toInt()
                        }
                    }

                    if (score > bestScore) {
                        bestScore = score
                        bestNum = num
                    }
                }
            }
        } catch (e: Exception) {
        }

        // Require a confident score (>= 560) so we never message a random person
        return if (bestScore >= 560) bestNum else null
    }

    private fun on(a: JSONObject): Boolean {
        val v = a.s("on").lowercase().trim()
        return !(v == "false" || v == "off" || v == "0" || v == "no" || v == "band")
    }

    private fun pct(a: JSONObject, key: String, def: Int): Int =
        (a.s(key).toDoubleOrNull() ?: def.toDouble()).toInt().coerceIn(0, 100)

    /** Runs a phone action. Returns an error text, or null when it worked. */
    fun run(c: Context, action: String, a: JSONObject): String? {
        try {
            return when (action.lowercase().trim()) {
                "call" -> call(c, a)
                "sms" -> sms(c, a)
                "whatsapp" -> whatsapp(c, a)
                "youtube" -> youtube(c, a)
                "open_app" -> openApp(c, a)
                "brightness" -> brightness(c, a)
                "volume" -> volume(c, a)
                "wifi" -> {
                    try {
                        val w = c.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                        @Suppress("DEPRECATION")
                        w.isWifiEnabled = on(a)
                    } catch (e: Exception) {
                        c.startActivity(nt(Intent(Settings.ACTION_WIFI_SETTINGS)))
                    }
                    null
                }
                "bluetooth" -> {
                    val b = BluetoothAdapter.getDefaultAdapter() ?: return "Phone mein Bluetooth nahi mila"
                    if (on(a)) b.enable() else b.disable()
                    null
                }
                "flashlight" -> flashlight(c, a)
                "alarm" -> alarm(c, a)
                "timer" -> {
                    val i = Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, (a.s("seconds").toDoubleOrNull() ?: 60.0).toInt())
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    c.startActivity(nt(i))
                    null
                }
                "navigate" -> navigate(c, a)
                "search" -> {
                    val q = a.s("query").ifBlank { a.s("text") }
                    val i = Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q)
                    c.startActivity(nt(i))
                    null
                }
                "home" -> global(AccessibilityService.GLOBAL_ACTION_HOME)
                "back" -> global(AccessibilityService.GLOBAL_ACTION_BACK)
                "recents" -> global(AccessibilityService.GLOBAL_ACTION_RECENTS)
                "notifications" -> global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
                "lock" -> lock(c)
                "shield_on" -> {
                    Bus.emit("shield", "on")
                    null
                }
                else -> null
            }
        } catch (e: Throwable) {
            return "Action error: " + (e.message ?: e.javaClass.simpleName)
        }
    }

    private fun call(c: Context, a: JSONObject): String? {
        val who = a.s("to").ifBlank { a.s("name") }.trim()
        if (who.isEmpty()) return "Kisko call karna hai, naam batao Sid"
        val num = findNumber(c, who) ?: return "Contacts mein '$who' naam nahi mila Sid"
        val uri = Uri.parse("tel:" + Uri.encode(num))
        val i = if (granted(c, Manifest.permission.CALL_PHONE)) Intent(Intent.ACTION_CALL, uri) else Intent(Intent.ACTION_DIAL, uri)
        c.startActivity(nt(i))
        return null
    }

    private fun cleanMessageBody(raw: String): String {
        return raw.trim()
            .removePrefix("ki ")
            .removePrefix("कि ")
            .removePrefix("that ")
            .trim()
            .ifEmpty { "Hi" }
    }

    private fun sms(c: Context, a: JSONObject): String? {
        if (!granted(c, Manifest.permission.SEND_SMS)) return "SMS permission off hai, Setup mein on karo"
        val who = a.s("to").ifBlank { a.s("name") }.trim()
        if (who.isEmpty()) return "Kisko SMS bhejna hai, naam batao"
        val num = findNumber(c, who) ?: return "Contacts mein '$who' naam nahi mila Sid"
        val body = cleanMessageBody(a.s("text").ifBlank { a.s("message") })
        @Suppress("DEPRECATION")
        val sm = SmsManager.getDefault()
        sm.sendMultipartTextMessage(num, null, sm.divideMessage(body), null, null)
        return null
    }

    private fun whatsapp(c: Context, a: JSONObject): String? {
        val who = a.s("to").ifBlank { a.s("name") }.trim()
        val body = cleanMessageBody(a.s("text").ifBlank { a.s("message") })
        if (who.isEmpty()) return "WhatsApp par kisko message bhejna hai, naam batao"
        val num = findNumber(c, who) ?: return "Contacts mein '$who' naam nahi mila Sid, pura naam bolo"
        var n = num.filter { it.isDigit() }
        if (n.length == 10) n = "91$n"
        else if (n.length == 11 && n.startsWith("0")) n = "91" + n.substring(1)

        val url = "https://wa.me/$n?text=" + Uri.encode(body)
        MahiAccess.waSendUntil = System.currentTimeMillis() + 28000
        var opened = false
        for (p in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            try {
                c.startActivity(nt(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(p)))
                opened = true
                break
            } catch (e: Exception) {
            }
        }
        if (!opened) c.startActivity(nt(Intent(Intent.ACTION_VIEW, Uri.parse(url))))
        val acc = MahiAccess.inst ?: return null
        acc.armWhatsApp()
        return null
    }

    private fun cleanYoutubeQuery(raw: String): String {
        val cleaned = raw
            .replace(Regex("(?i)\\b(mahi|maahi|youtube|par|pe|mein|me|play|song|gaana|gana|video|chala|chalao|chala do|laga|lagao|laga do|suna|sunao|please|plz)\\b"), " ")
            .replace(Regex("(माही|यूट्यूब|पर|पे|में|गाना|गाने|वीडियो|चला|चलाओ|चला दो|लगा|लगाओ|लगा दो|सुनाओ|प्लीज)"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        return cleaned.ifEmpty { raw.trim().ifEmpty { "trending songs" } }
    }

    private fun youtube(c: Context, a: JSONObject): String? {
        val rawQ = a.s("query").ifBlank { a.s("name").ifBlank { a.s("text") } }
        val q = cleanYoutubeQuery(rawQ)
        val url = "https://www.youtube.com/results?search_query=" + Uri.encode(q)
        MahiAccess.ytQuery = q
        MahiAccess.ytPlayUntil = System.currentTimeMillis() + 25000
        try {
            c.startActivity(
                nt(
                    Intent(Intent.ACTION_VIEW, Uri.parse(url))
                        .setPackage("com.google.android.youtube")
                        .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                )
            )
        } catch (e: Exception) {
            c.startActivity(nt(Intent(Intent.ACTION_VIEW, Uri.parse(url))))
        }
        MahiAccess.inst?.armYouTube()
        return null
    }

    private val appKnownPackages = mapOf(
        "whatsapp" to listOf("com.whatsapp", "com.whatsapp.w4b"),
        "youtube" to listOf("com.google.android.youtube"),
        "instagram" to listOf("com.instagram.android", "com.instagram.lite"),
        "insta" to listOf("com.instagram.android", "com.instagram.lite"),
        "facebook" to listOf("com.facebook.katana", "com.facebook.lite"),
        "chrome" to listOf("com.android.chrome", "com.quetta.browser"),
        "browser" to listOf("com.quetta.browser", "com.android.chrome"),
        "quetta" to listOf("com.quetta.browser"),
        "telegram" to listOf("org.telegram.messenger", "org.telegram.messenger.web"),
        "capcut" to listOf("com.lemon.lvoverseas"),
        "maps" to listOf("com.google.android.apps.maps"),
        "gmail" to listOf("com.google.android.gm"),
        "playstore" to listOf("com.android.vending"),
        "play store" to listOf("com.android.vending"),
        "files" to listOf("com.google.android.apps.nbu.files", "com.android.fileexplorer"),
        "calculator" to listOf("com.google.android.calculator", "com.android.bbkcalculator", "com.android.calculator2"),
        "clock" to listOf("com.google.android.deskclock", "com.android.BBKClock", "com.android.deskclock"),
        "calendar" to listOf("com.google.android.calendar", "com.bbk.calendar", "com.android.calendar"),
        "gallery" to listOf("com.vivo.gallery", "com.google.android.apps.photos", "com.android.gallery3d"),
        "photos" to listOf("com.google.android.apps.photos", "com.vivo.gallery")
    )

    private val hindiAppSynonyms = mapOf(
        "व्हाट्सएप" to "whatsapp",
        "वॉट्सऐप" to "whatsapp",
        "वाट्सएप" to "whatsapp",
        "यूट्यूब" to "youtube",
        "इंस्टाग्राम" to "instagram",
        "इंस्टा" to "instagram",
        "फेसबुक" to "facebook",
        "क्रोम" to "chrome",
        "ब्राउज़र" to "browser",
        "क्वेटा" to "quetta",
        "टेलीग्राम" to "telegram",
        "कैपकट" to "capcut",
        "मैप" to "maps",
        "मैप्स" to "maps",
        "जीमेल" to "gmail",
        "प्ले स्टोर" to "play store",
        "कैलकुलेटर" to "calculator",
        "कैमरा" to "camera",
        "गैलरी" to "gallery",
        "फोटो" to "photos",
        "सेटिंग" to "settings",
        "सेटिंग्स" to "settings",
        "घड़ी" to "clock",
        "अलार्म" to "clock"
    )

    private fun openApp(c: Context, a: JSONObject): String? {
        var raw = a.s("name").ifBlank { a.s("query").ifBlank { a.s("app") } }.lowercase().trim()
        raw = raw.replace(Regex("(?i)\\b(app|application|open|kholo|khol|chala|chalao|karo|kar do|mahi)\\b"), " ")
            .replace(Regex("(ऐप|खोलो|खोल|चलाओ|चला|करो|माही)"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        if (raw.isEmpty()) return "Kaunsa app kholna hai Sid?"

        for ((hi, en) in hindiAppSynonyms) {
            if (raw.contains(hi)) {
                raw = en
                break
            }
        }
        val qPhonetic = phoneticKey(raw)

        // Direct system intents for Camera & Settings
        if (raw == "camera" || qPhonetic == "kamera" || qPhonetic == "camera") {
            try {
                c.startActivity(nt(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)))
                return null
            } catch (e: Exception) {
            }
        }
        if (raw == "settings" || raw == "setting" || qPhonetic == "setings" || qPhonetic == "seting") {
            c.startActivity(nt(Intent(Settings.ACTION_SETTINGS)))
            return null
        }

        val pm = c.packageManager
        // Check known popular app packages first
        for ((key, pkgs) in appKnownPackages) {
            if (raw == key || qPhonetic == phoneticKey(key) || raw.contains(key)) {
                for (pkg in pkgs) {
                    val launch = pm.getLaunchIntentForPackage(pkg)
                    if (launch != null) {
                        c.startActivity(nt(launch))
                        return null
                    }
                }
            }
        }

        // Ranked search across all installed launcher activities
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        var bestPkg: String? = null
        var bestScore = 0
        for (ri in list) {
            val label = ri.loadLabel(pm).toString().lowercase().trim()
            val pkg = ri.activityInfo.packageName.lowercase()
            val lKey = phoneticKey(label)
            var score = 0
            if (label == raw || lKey == qPhonetic) {
                score = 1000
            } else if (label.startsWith(raw) || (qPhonetic.length >= 3 && lKey.startsWith(qPhonetic))) {
                score = 850
            } else if (raw.length >= 3 && (label.contains(raw) || lKey.contains(qPhonetic) || pkg.contains(raw))) {
                score = 700
            } else if (qPhonetic.length >= 3) {
                val sim = editSimilarity(qPhonetic, lKey)
                if (sim >= 0.78) score = (sim * 650).toInt()
            }
            if (score > bestScore) {
                bestScore = score
                bestPkg = ri.activityInfo.packageName
            }
        }
        val targetPkg = bestPkg ?: return "Phone mein '$raw' app nahi mila Sid"
        val launchIntent = pm.getLaunchIntentForPackage(targetPkg) ?: return "'$raw' open nahi ho paya"
        c.startActivity(nt(launchIntent))
        return null
    }

    private fun brightness(c: Context, a: JSONObject): String? {
        if (!Settings.System.canWrite(c)) return "Setup mein 'Allow system settings' on karo"
        val p = pct(a, "percent", 50).coerceAtLeast(1)
        Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS, p * 255 / 100)
        return null
    }

    private fun volume(c: Context, a: JSONObject): String? {
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val p = pct(a, "percent", 50)
        am.setStreamVolume(
            AudioManager.STREAM_MUSIC,
            am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) * p / 100,
            AudioManager.FLAG_SHOW_UI
        )
        return null
    }

    private fun flashlight(c: Context, a: JSONObject): String? {
        val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        for (id in cm.cameraIdList) {
            val ch = cm.getCameraCharacteristics(id)
            if (ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true) {
                cm.setTorchMode(id, on(a))
                return null
            }
        }
        return "Flashlight nahi mili"
    }

    private fun alarm(c: Context, a: JSONObject): String? {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, (a.s("hour").toDoubleOrNull() ?: 7.0).toInt())
            .putExtra(AlarmClock.EXTRA_MINUTES, (a.s("minute").toDoubleOrNull() ?: 0.0).toInt())
            .putExtra(AlarmClock.EXTRA_MESSAGE, a.s("label").ifBlank { "Mahi Alarm" })
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        c.startActivity(nt(i))
        return null
    }

    private fun navigate(c: Context, a: JSONObject): String? {
        val place = Uri.encode(a.s("place").ifBlank { a.s("query") })
        try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=$place")).setPackage("com.google.android.apps.maps")
            c.startActivity(nt(i))
        } catch (e: Exception) {
            c.startActivity(nt(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$place"))))
        }
        return null
    }

    private fun global(code: Int): String? {
        val s = MahiAccess.inst ?: return "Setup mein Accessibility on karo"
        s.performGlobalAction(code)
        return null
    }

    private fun lock(c: Context): String? {
        val dpm = c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        if (!dpm.isAdminActive(ComponentName(c, AdminReceiver::class.java))) return "Setup mein Device Admin on karo"
        dpm.lockNow()
        return null
    }
}
