package com.vinit.mahi

import android.Manifest
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SetupActivity : Activity() {

    private class Row(val label: TextView, val title: String, val ok: () -> Boolean)

    private val rows = ArrayList<Row>()
    private lateinit var col: LinearLayout
    private lateinit var keyBox: EditText
    private lateinit var voiceStatus: TextView

    private val perms = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CALL_PHONE,
        Manifest.permission.SEND_SMS,
        Manifest.permission.READ_CONTACTS
    )

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        window.statusBarColor = Color.parseColor("#050B18")
        val sv = ScrollView(this)
        sv.setBackgroundColor(Color.parseColor("#050B18"))
        col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(28), dp(18), dp(40))
        sv.addView(col)
        setContentView(sv)

        text("MAHI // AI CORE SETUP", 24f, "#00F6FF", true)
        text("Complete the one-time setup steps below. Each item turns green when active.", 13.5f, "#9FB3C8", false)

        // 1. API key
        val t1 = text("", 16f, "#FFFFFF", true)
        rows.add(Row(t1, "1. Gemini API Key", { Store.apiKey.isNotEmpty() }))
        keyBox = EditText(this)
        keyBox.hint = "Paste your Gemini API key here (starts with AIza...)"
        keyBox.setText(Store.apiKey)
        keyBox.setTextColor(Color.WHITE)
        keyBox.setHintTextColor(Color.parseColor("#6B7F95"))
        keyBox.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        keyBox.setSingleLine(true)
        col.addView(keyBox)
        button("Save API Key") {
            Store.apiKey = keyBox.text.toString()
            Toast.makeText(this, "API Key saved!", Toast.LENGTH_SHORT).show()
            refresh()
        }

        // 2. Permissions
        step("2. Core Permissions", "Microphone, Calls, SMS, and Contacts access.", { allPerms() }, "Allow Permissions") {
            requestPermissions(perms, 11)
        }

        // 3. Accessibility
        step(
            "3. Accessibility Automation",
            "Lets Mahi press Send in WhatsApp, auto-play YouTube videos, and control Home/Back.",
            { MahiAccess.inst != null }, "Open Accessibility Settings"
        ) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        // 4. Write settings
        step(
            "4. System Settings Control",
            "Lets Mahi adjust screen brightness by voice.",
            { Settings.System.canWrite(this) }, "Allow Modify System Settings"
        ) {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        }

        // 5. Device admin
        step("5. Device Admin Lock", "Lets Mahi lock the phone screen on command.", { adminOn() }, "Activate Device Admin") {
            val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this, AdminReceiver::class.java))
            i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Mahi needs this to lock your phone when you ask.")
            startActivity(i)
        }

        // 6. Battery
        step(
            "6. Background Keep-Alive",
            "Prevents Android from stopping Mahi in the background.",
            { batteryOk() }, "Allow Background Running"
        ) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        button("Open App Settings (Vivo Autostart)") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }

        // 7. Floating AI Core Orb & Neon Edge Overlay
        step(
            "7. Every-Screen Futuristic AI Orb & Neon Overlay",
            "Displays the glowing AI Core Orb and full-screen Neon Edge Lights over any app.",
            { Settings.canDrawOverlays(this) }, "Allow Overlay Permission"
        ) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }

        // Natural Voice switch
        val sw = Switch(this)
        sw.text = "Ultra-Natural Human Voice (Gemini + Neural Hindi)"
        sw.setTextColor(Color.WHITE)
        sw.isChecked = Store.naturalVoice
        sw.setOnCheckedChangeListener { _, v -> Store.naturalVoice = v }
        sw.setPadding(0, dp(18), 0, dp(6))
        col.addView(sw)

        // Proactive Silence Companion switch
        val prSw = Switch(this)
        prSw.text = "Proactive Nova Mode (Mahi speaks & recommends on her own when you stay silent)"
        prSw.setTextColor(Color.WHITE)
        prSw.isChecked = Store.proactiveMode
        prSw.setOnCheckedChangeListener { _, v ->
            Store.proactiveMode = v
            if (WakeService.running) {
                startForegroundService(Intent(this, WakeService::class.java).setAction(WakeService.ACT_APPLY))
            }
        }
        prSw.setPadding(0, dp(10), 0, dp(6))
        col.addView(prSw)

        // Hands-free switch
        val hf = Switch(this)
        hf.text = "Hands-Free Wake Word: Always listen for \"Hello Mahi\""
        hf.setTextColor(Color.WHITE)
        hf.isChecked = Store.handsFree
        hf.setOnCheckedChangeListener { _, v ->
            Store.handsFree = v
            if (WakeService.running) {
                startForegroundService(Intent(this, WakeService::class.java).setAction(WakeService.ACT_APPLY))
            }
        }
        hf.setPadding(0, dp(10), 0, dp(6))
        col.addView(hf)

        // Voice test
        voiceStatus = text("", 13f, "#00F6FF", false)
        button("Test Mahi's Natural Voice") {
            Toast.makeText(this, "Testing Mahi's voice...", Toast.LENGTH_SHORT).show()
            Thread {
                try {
                    Speaker.speak(
                        this,
                        "Haan Sid! Ab meri aawaz bilkul natural hai, aur main har baat turant samajhungi!",
                        "हाँ Sid... अब मेरी आवाज़ बिल्कुल नेचुरल है, और मैं तुम्हारी हर बात तुरंत समझूँगी!"
                    )
                } catch (e: Throwable) {
                }
                runOnUiThread { refresh() }
            }.start()
        }

        // Launch Mahi HUD
        val go = button("LAUNCH MAHI AI CORE") {
            if (Store.apiKey.isEmpty()) {
                Toast.makeText(this, "Tip: Paste your Gemini API key above for full AI intelligence", Toast.LENGTH_LONG).show()
            }
            startForegroundService(Intent(this, WakeService::class.java))
            startActivity(Intent(this, MainActivity::class.java))
        }
        go.setBackgroundColor(Color.parseColor("#00B4D8"))
        go.setTextColor(Color.BLACK)

        button("Stop Mahi Service") {
            stopService(Intent(this, WakeService::class.java))
            Toast.makeText(this, "Mahi stopped", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    private fun allPerms(): Boolean = perms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun adminOn(): Boolean {
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return dpm.isAdminActive(ComponentName(this, AdminReceiver::class.java))
    }

    private fun batteryOk(): Boolean {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun refresh() {
        for (r in rows) r.label.text = (if (r.ok()) "✅  " else "⬜  ") + r.title
        val ve = Store.lastTtsErr
        voiceStatus.text = "Voice Engine Status: " + (if (ve.isEmpty()) "Ready (Natural Neural + Gemini)" else ve)
    }

    private fun text(s: String, size: Float, color: String, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(Color.parseColor(color))
        if (bold) t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
        t.setPadding(0, dp(14), 0, dp(4))
        col.addView(t)
        return t
    }

    private fun button(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.gravity = Gravity.CENTER
        b.setOnClickListener { onClick() }
        col.addView(b)
        return b
    }

    private fun step(title: String, hint: String, ok: () -> Boolean, btn: String, onClick: () -> Unit) {
        val t = text("", 16f, "#FFFFFF", true)
        rows.add(Row(t, title, ok))
        text(hint, 13f, "#9FB3C8", false)
        button(btn, onClick)
    }
}
