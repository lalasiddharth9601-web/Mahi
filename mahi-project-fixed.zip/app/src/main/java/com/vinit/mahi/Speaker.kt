package com.vinit.mahi

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

object Speaker {
    private var tts: TextToSpeech? = null

    @Volatile
    private var ready = false

    @Volatile
    private var voiceConfigured = false

    fun init(c: Context) {
        if (tts != null) return
        val app = c.applicationContext
        tts = TextToSpeech(app) { st ->
            if (st == TextToSpeech.SUCCESS) {
                 tts?.let { configureBestVoiceOnce(it) }
                ready = true
            }
        }
    }

    private fun ensureLoudEnough(c: Context) {
        try {
            val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.mode = AudioManager.MODE_NORMAL
            try {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
            } catch (e: Exception) {
            }
            val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            if (max > 0 && cur < (max * 25) / 100) {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, (max * 45) / 100, 0)
            }
            @Suppress("DEPRECATION")
            am.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
        } catch (e: Exception) {
        }
    }

    private fun releaseFocus(c: Context) {
        try {
            val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            @Suppress("DEPRECATION")
            am.abandonAudioFocus(null)
        } catch (e: Exception) {
        }
    }

    /**
     * 3-Tier Natural Speech Pipeline:
     * 1. Gemini 2.5 Flash Natural TTS (if enabled and within fast window)
     * 2. Instant Google Neural Hindi Voice Stream (<350ms latency, human-like, no API quota limit)
     * 3. Pre-warmed Android local Hindi TTS fallback (if completely offline)
     */
    fun speak(c: Context, text: String, voiceText: String = text, onStart: () -> Unit = {}) {
        init(c)
        ensureLoudEnough(c)
        val cleanVoiceText = voiceText.replace(Regex("\\s+"), " ").trim().ifEmpty { text }
        var startedCalled = false
        val safeStart = {
            if (!startedCalled) {
                startedCalled = true
                onStart()
            }
        }

        try {
            var ok = false
            // Tier 1: Gemini Natural Voice
            if (Store.naturalVoice && Store.apiKey.isNotEmpty()) {
                ok = try {
                    val pcm = Brain.ttsPcm(cleanVoiceText)
                    if (pcm != null && pcm.size > 1600) {
                        safeStart()
                        playStreamPcm(pcm)
                        true
                    } else false
                } catch (e: Throwable) {
                    false
                }
            }

            // Tier 2: Fast Google Neural Hindi Stream (Natural Female Voice, <350ms latency)
            if (!ok) {
                ok = try {
                    if (playNeuralHindiStream(c, cleanVoiceText, safeStart)) {
                        Store.lastTtsErr = "OK (Fast Neural Hindi Voice)"
                        true
                    } else false
                } catch (e: Throwable) {
                    false
                }
            }

            // Tier 3: Offline Phone TTS backup
            if (!ok) {
                Bus.emit("heard", "voice: offline backup")
                phoneSpeak(cleanVoiceText, safeStart)
            }
        } finally {
            releaseFocus(c)
        }
    }

    /** Streams natural Google Hindi neural female voice in chunks and plays via MediaPlayer. */
    private fun playNeuralHindiStream(c: Context, text: String, onStart: () -> Unit): Boolean {
        val chunks = splitChunks(text, 175)
        if (chunks.isEmpty()) return false
        val audioFiles = ArrayList<File>()
        try {
            for ((idx, chunk) in chunks.withIndex()) {
                val q = URLEncoder.encode(chunk, "UTF-8")
                val url = "https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=hi&ttsspeed=1.0&q=$q"
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.requestMethod = "GET"
                conn.connectTimeout = 3000
                conn.readTimeout = 4500
                conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36")
                if (conn.responseCode !in 200..299) return false
                val bytes = conn.inputStream.use { it.readBytes() }
                if (bytes.size < 400) return false
                val f = File(c.cacheDir, "mahi_neural_$idx.mp3")
                FileOutputStream(f).use { it.write(bytes) }
                audioFiles.add(f)
            }

            for ((idx, f) in audioFiles.withIndex()) {
                val latch = CountDownLatch(1)
                val mp = MediaPlayer()
                try {
                    mp.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    mp.setDataSource(f.absolutePath)
                    mp.setOnCompletionListener { latch.countDown() }
                    mp.setOnErrorListener { _, _, _ ->
                        latch.countDown()
                        true
                    }
                    mp.prepare()
                    if (idx == 0) onStart()
                    mp.start()
                    latch.await(20, TimeUnit.SECONDS)
                } finally {
                    try {
                        mp. stop()
                    } catch (e: Exception) {
                    }
                    try {
                        mp.release()
                    } catch (e: Exception) {
                    }
                }
            }
            return true
        } catch (e: Throwable) {
            return false
        } finally {
            for (f in audioFiles) {
                try {
                    f.delete()
                } catch (e: Exception) {
                }
            }
        }
    }

    private fun splitChunks(text: String, maxLen: Int): List<String> {
        val clean = text.trim()
        if (clean.length <= maxLen) return listOf(clean)
        val out = ArrayList<String>()
        val parts = clean.split(Regex("(?<=[।.!?\\n,])\\s+"))
        var cur = StringBuilder()
        for (p in parts) {
            if (cur.length + p.length + 1 <= maxLen) {
                if (cur.isNotEmpty()) cur.append(" ")
                cur.append(p)
            } else {
                if (cur.isNotEmpty()) {
                    out.add(cur.toString())
                    cur = StringBuilder()
                }
                if (p.length <= maxLen) {
                    cur.append(p)
                } else {
                    var start = 0
                    while (start < p.length) {
                        val end = minOf(start + maxLen, p.length)
                        out.add(p.substring(start, end))
                        start = end
                    }
                }
            }
        }
        if (cur.isNotEmpty()) out.add(cur.toString())
        return out
    }

    private fun configureBestVoiceOnce(t: TextToSpeech) {
        if (voiceConfigured) return
        try {
            t.setLanguage(Locale("hi", "IN"))
            var best: Voice? = null
            var bestScore = -1
            val vs = t.voices
            if (vs != null) {
                for (v in vs) {
                    val lang = v.locale?.language?.lowercase() ?: ""
                    if (lang != "hi") continue
                    val f = v.features
                    if (f != null && f.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)) continue
                    val n = v.name.lowercase()
                    var score = v.quality
                    // Prefer female / high-quality local voices
                    if (n.contains("hed") || n.contains("hia") || n.contains("hic") || n.contains("female") || n.contains("local")) {
                        score += 200
                    }
                    if (!v.isNetworkConnectionRequired) score += 50
                    if (score > bestScore) {
                        bestScore = score
                        best = v
                    }
                }
            }
            if (best != null) {
                t.voice = best
            }
            t.setPitch(1.04f)
            t.setSpeechRate(0.98f)
            voiceConfigured = true
        } catch (e: Exception) {
        }
    }

    fun speakPhone(c: Context, text: String, started: () -> Unit = {}) {
        init(c)
        ensureLoudEnough(c)
        try {
            if (!playNeuralHindiStream(c, text, started)) {
                phoneSpeak(text, started)
            }
        } finally {
            releaseFocus(c)
        }
    }

    fun playPcm(pcm: ByteArray) {
        playStreamPcm(pcm)
    }

    /** Plays 24kHz 16-bit mono PCM reliably using MODE_STREAM (never fails on large buffers on Android 8.1). */
    private fun playStreamPcm(pcm: ByteArray) {
        val rate = 24000
        val evenSize = pcm.size and 1.inv()
        if (evenSize <= 0) return
        val minBuf = AudioTrack.getMinBufferSize(
            rate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(4096)

        val track = AudioTrack(
            AudioManager.STREAM_MUSIC,
            rate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            minBuf * 2,
            AudioTrack.MODE_STREAM
        )
        try {
            if (track.state != AudioTrack.STATE_INITIALIZED) return
            track.play()
            var offset = 0
            val chunk = 4096
            while (offset < evenSize) {
                val toWrite = minOf(chunk, evenSize - offset)
                val written = track.write(pcm, offset, toWrite)
                if (written <= 0) break
                offset += written
            }
            val totalFrames = evenSize / 2
            var guard = 0
            while (track.playbackHeadPosition < totalFrames && guard < 400) {
                Thread.sleep(25)
                guard++
            }
        } catch (e: Exception) {
        } finally {
            try {
                track.stop()
            } catch (e: Exception) {
            }
            try {
                track.release()
            } catch (e: Exception) {
            }
        }
    }

    private fun phoneSpeak(text: String, started: () -> Unit) {
        var n = 0
        while (!ready && n < 25) {
            Thread.sleep(80)
            n++
        }
        val t = tts ?: run {
            started()
            return
        }
        configureBestVoiceOnce(t)
        val latch = CountDownLatch(1)
        val uid = "mahi_" + System.currentTimeMillis()
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                started()
            }

            override fun onDone(utteranceId: String?) {
                latch.countDown()
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                started()
                latch.countDown()
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                started()
                latch.countDown()
            }
        })
        val res = t.speak(text, TextToSpeech.QUEUE_FLUSH, null, uid)
        if (res == TextToSpeech.ERROR) {
            started()
            return
        }
        latch.await(20, TimeUnit.SECONDS)
    }
}
