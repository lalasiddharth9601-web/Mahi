package com.vinit.mahi

import org.json.JSONObject

/**
 * Offline & fallback command parser.
 * Handles WhatsApp, SMS, Call, YouTube, Open App, Torch, Volume, Brightness, Lock, etc. accurately.
 */
object LocalCmd {
    class Cmd(val action: String, val args: JSONObject, val say: String, val spoken: String)

    private fun stripPolite(s: String): String =
        s.replace(Regex("(?i)\\b(mahi|maahi|hello|hey|oye|suno|please|plz|zara|ek kaam karo)\\b"), " ")
            .replace(Regex("(माही|माहि|हेलो|अरे|सुनो|प्लीज|ज़रा|एक काम करो)"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun stripTrailingVerbs(s: String): String =
        s.replace(Regex("(?i)\\b(karo|kar do|kardo|lagao|laga do|chalao|chala do|kholo|khol do|bhejo|bhej do|open|play)\\b"), " ")
            .replace(Regex("(करो|कर दो|लगाओ|लगा दो|चलाओ|चला दो|खोलो|खोल दो|भेजो|भेज दो)"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    fun parse(text: String): Cmd? {
        val cleaned = stripPolite(text)
        val low = cleaned.lowercase().trim()
        if (low.isEmpty()) return null
        val num = Regex("\\d+").find(low)?.value

        // 1. Flashlight / Torch
        if (low.contains("torch") || low.contains("flashlight") || low.contains("टॉर्च") || low.contains("फ्लैशलाइट") || low.contains("फ्लैश")) {
            val off = low.contains("off") || low.contains("band") || low.contains("बंद") || low.contains("बन्द")
            return Cmd(
                "flashlight",
                JSONObject().put("on", !off),
                if (off) "Theek hai Sid, torch band kar rahi hoon." else "Theek hai Sid, torch on kar rahi hoon.",
                if (off) "ठीक है Sid, टॉर्च बंद कर रही हूँ।" else "ठीक है Sid, टॉर्च ऑन कर रही हूँ।"
            )
        }

        // 2. Brightness
        if ((low.contains("brightness") || low.contains("ब्राइटनेस")) && num != null) {
            return Cmd(
                "brightness",
                JSONObject().put("percent", num),
                "Brightness $num percent kar rahi hoon, Sid.",
                "ब्राइटनेस $num परसेंट कर रही हूँ, Sid."
            )
        }

        // 3. Volume / Sound
        if ((low.contains("volume") || low.contains("वॉल्यूम") || low.contains("आवाज़") || low.contains("awaz")) && num != null) {
            return Cmd(
                "volume",
                JSONObject().put("percent", num),
                "Volume $num percent kar rahi hoon, Sid.",
                "वॉल्यूम $num परसेंट कर रही हूँ, Sid."
            )
        }

        // 4. Lock / Security
        if (low.contains("phone lock") || low.contains("screen lock") || low.contains("लॉक कर") || low == "lock") {
            return Cmd("lock", JSONObject(), "Phone lock kar rahi hoon, Sid.", "फोन लॉक कर रही हूँ, Sid.")
        }

        // 5. WhatsApp / Message (e.g. "Rahul ko WhatsApp par hi bhejo" or "Mummy ko message karo ki main aa raha hoon")
        val isMsg = low.contains("whatsapp") || low.contains("व्हाट्सएप") || low.contains("वॉट्सऐप") ||
            low.contains("message") || low.contains("मैसेज") || low.contains("msg") || low.contains("sms")
        if (isMsg && (low.contains(" ko ") || low.contains(" को ") || low.contains("bhejo") || low.contains("भेजो") || low.contains("karo") || low.contains("करो"))) {
            val act = if (low.contains("sms")) "sms" else "whatsapp"
            val koMatch = Regex("(.+?)\\s+(?:ko|को)\\s+(.+)", RegexOption.IGNORE_CASE).find(cleaned)
            if (koMatch != null) {
                val who = koMatch.groupValues[1]
                    .replace(Regex("(?i)\\b(whatsapp|par|pe|mein|sms|message)\\b"), " ")
                    .replace(Regex("(व्हाट्सएप|वॉट्सऐप|पर|पे|में|मैसेज)"), " ")
                    .trim()
                var msgTxt = koMatch.groupValues[2]
                    .replace(Regex("(?i)^(whatsapp\\s+par|whatsapp\\s+pe|whatsapp|message|msg|sms)\\s*"), "")
                    .replace(Regex("^(व्हाट्सएप\\s+पर|व्हाट्सएप\\s+पे|व्हाट्सएप|मैसेज|एसएमएस)\\s*"), "")
                    .replace(Regex("(?i)\\s*(message|msg|whatsapp|sms)?\\s*(karo|kar do|kardo|bhejo|bhej do|bol do|bolo)\\s*$"), "")
                    .replace(Regex("\\s*(मैसेज|व्हाट्सएप)?\\s*(करो|कर दो|भेजो|भेज दो|बोल दो|बोलो)\\s*$"), "")
                    .replace(Regex("^(?:ki|कि)\\s+"), "")
                    .trim()
                if (msgTxt.isEmpty()) msgTxt = "Hi"
                if (who.isNotEmpty()) {
                    return Cmd(
                        act,
                        JSONObject().put("to", who).put("text", msgTxt),
                        "Theek hai Sid, $who ko '$msgTxt' bhej rahi hoon.",
                        "ठीक है Sid, $who को '$msgTxt' भेज रही हूँ।"
                    )
                }
            }
        }

        // 6. Call (e.g. "Mummy ko call karo" or "call Rahul")
        val callRe = Regex("(.+?)\\s+(?:ko|को)\\s+(?:call|phone|कॉल|फोन)", RegexOption.IGNORE_CASE).find(cleaned)
            ?: Regex("(?:call|कॉल)\\s+(.+)", RegexOption.IGNORE_CASE).find(cleaned)
        if (callRe != null) {
            val name = stripTrailingVerbs(callRe.groupValues[1])
            if (name.isNotEmpty()) {
                return Cmd(
                    "call",
                    JSONObject().put("to", name),
                    "Theek hai Sid, main $name ko call laga rahi hoon.",
                    "ठीक है Sid, मैं $name को कॉल लगा रही हूँ।"
                )
            }
        }

        // 7. Open App (e.g. "Instagram kholo", "open WhatsApp")
        val openRe = Regex("(?:open|kholo|खोलो|खोल)\\s+(.+)", RegexOption.IGNORE_CASE).find(cleaned)
            ?: Regex("(.+?)\\s+(?:app\\s+)?(?:kholo|khol do|खोलो|खोल दो|open karo|open)", RegexOption.IGNORE_CASE).find(cleaned)
        if (openRe != null && !low.contains("youtube par") && !low.contains("यूट्यूब पर")) {
            val appName = stripTrailingVerbs(openRe.groupValues[1])
            if (appName.isNotEmpty()) {
                return Cmd(
                    "open_app",
                    JSONObject().put("name", appName),
                    "Theek hai Sid, $appName khol rahi hoon.",
                    "ठीक है Sid, $appName खोल रही हूँ।"
                )
            }
        }

        // 8. YouTube / Play Song or Video
        if (low.contains("youtube") || low.contains("यूट्यूब") || low.contains("gaana") || low.contains("गाना") ||
            low.contains("गाने") || low.contains("song") || low.contains("chalao") || low.contains("chala do") ||
            low.contains("चलाओ") || low.contains("चला दो") || low.contains("play ")
        ) {
            var q = cleaned
            for (w in listOf("youtube", "यूट्यूब", "par", "पर", "pe", "पे", "gaana", "गाना", "गाने", "song", "video", "वीडियो", "play")) {
                q = q.replace(Regex("(?i)\\b$w\\b"), " ").replace(w, " ")
            }
            q = stripTrailingVerbs(q)
            if (q.isEmpty()) q = "trending hindi songs"
            return Cmd(
                "youtube",
                JSONObject().put("query", q),
                "Ye lo Sid, YouTube par $q chala rahi hoon.",
                "ये लो Sid, YouTube पर $q चला रही हूँ।"
            )
        }

        return null
    }
}
