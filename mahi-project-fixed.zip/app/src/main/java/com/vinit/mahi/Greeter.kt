package com.vinit.mahi

import android.content.Context
import java.io.File
import java.util.Random

/** Instant natural greetings when Mahi wakes up. */
object Greeter {
    private val sid = listOf(
        Pair("Haan Sid, bolo!", "हाँ Sid, बोलो!"),
        Pair("Haan Sid... main sun rahi hoon, batao?", "हाँ Sid... मैं सुन रही हूँ, बताओ?"),
        Pair("Bolo Sid, abhi kya karna hai?", "बोलो Sid, अभी क्या करना है?"),
        Pair("Haan jaanu, bolo main yahi hoon!", "हाँ जानू, बोलो मैं यहीं हूँ!")
    )
    private val fam = listOf(
        Pair("Ji, boliye?", "जी, बोलिए?"),
        Pair("Namaste ji, bataiye main kya madad karoon?", "नमस्ते जी, बताइए मैं क्या मदद करूँ?")
    )

    private val rnd = Random()

    private fun file(c: Context, mode: String, i: Int) = File(c.cacheDir, "greet2_" + mode + "_" + i + ".pcm")

    /** Speaks greeting naturally and immediately invokes onStart with the display subtitle. */
    fun greet(c: Context, mode: String, onStart: (String) -> Unit) {
        val m = if (mode == "family") "family" else "sid"
        val list = if (m == "family") fam else sid
        val i = rnd.nextInt(list.size)
        val f = file(c, m, i)
        if (Store.naturalVoice && f.exists() && f.length() > 2000) {
            onStart(list[i].first)
            Speaker.playPcm(f.readBytes())
        } else {
            Speaker.speak(c, list[i].first, list[i].second) {
                onStart(list[i].first)
            }
        }
    }
}
