package com.vinit.mahi

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Full-screen futuristic Nova-style Neon Edge Aura + Corner Cyber Brackets + Bottom Soundwave HUD.
 * Touch-through overlay that lights up around every screen when Mahi listens, thinks, or speaks.
 */
class NeonView(c: Context) : View(c) {
    private var phase = 0f
    private var modeState = "listen" // "listen", "think", "speak", "tap"
    private val d = c.resources.displayMetrics.density
    private val edgeThick = 42f * d
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val rect = RectF()
    private val cornerPath = Path()
    private var anim: ValueAnimator? = null

    fun setState(s: String) {
        modeState = s.ifEmpty { "listen" }
        invalidate()
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val baseHue = when (modeState) {
            "speak" -> (310f + sin(phase * 2f) * 25f + 360f) % 360f
            "think" -> (265f + phase * 60f) % 360f
            else -> (182f + sin(phase * 2f) * 20f + 360f) % 360f
        }
        val secHue = (baseHue + 115f) % 360f
        val pulse = (0.72f + 0.28f * sin(phase * 4.2f)).coerceIn(0.4f, 1f)

        val cPrimary = Color.HSVToColor((235 * pulse).toInt(), floatArrayOf(baseHue, 0.92f, 1f))
        val cSecondary = Color.HSVToColor((235 * pulse).toInt(), floatArrayOf(secHue, 0.92f, 1f))
        val cTrans = Color.HSVToColor(0, floatArrayOf(baseHue, 0.92f, 1f))

        // 1. Soft inward neon glow along all 4 screen borders
        fillPaint.shader = LinearGradient(0f, 0f, 0f, edgeThick, cPrimary, cTrans, Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w, edgeThick, fillPaint)

        fillPaint.shader = LinearGradient(0f, h, 0f, h - edgeThick, cSecondary, cTrans, Shader.TileMode.CLAMP)
        cv.drawRect(0f, h - edgeThick, w, h, fillPaint)

        fillPaint.shader = LinearGradient(0f, 0f, edgeThick, 0f, cSecondary, cTrans, Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, edgeThick, h, fillPaint)

        fillPaint.shader = LinearGradient(w, 0f, w - edgeThick, 0f, cPrimary, cTrans, Shader.TileMode.CLAMP)
        cv.drawRect(w - edgeThick, 0f, w, h, fillPaint)

        // 2. Crisp glowing neon outer frame
        val pad = 3f * d
        rect.set(pad, pad, w - pad, h - pad)
        strokePaint.shader = LinearGradient(0f, 0f, w, h, cPrimary, cSecondary, Shader.TileMode.MIRROR)
        strokePaint.strokeWidth = 3.2f * d
        val cornerR = 22f * d
        cv.drawRoundRect(rect, cornerR, cornerR, strokePaint)

        // 3. Futuristic HUD corner brackets
        val len = 34f * d
        val m = 10f * d
        strokePaint.shader = null
        strokePaint.color = Color.WHITE
        strokePaint.alpha = (210 * pulse).toInt()
        strokePaint.strokeWidth = 2.2f * d
        cornerPath.reset()
        // Top-Left
        cornerPath.moveTo(m, m + len)
        cornerPath.lineTo(m, m)
        cornerPath.lineTo(m + len, m)
        // Top-Right
        cornerPath.moveTo(w - m - len, m)
        cornerPath.lineTo(w - m, m)
        cornerPath.lineTo(w - m, m + len)
        // Bottom-Left
        cornerPath.moveTo(m, h - m - len)
        cornerPath.lineTo(m, h - m)
        cornerPath.lineTo(m + len, h - m)
        // Bottom-Right
        cornerPath.moveTo(w - m - len, h - m)
        cornerPath.lineTo(w - m, h - m)
        cornerPath.lineTo(w - m, h - m - len)
        cv.drawPath(cornerPath, strokePaint)

        // 4. Bottom futuristic equalizer wave bars
        val bars = 13
        val barW = 4.5f * d
        val gap = 6.5f * d
        val totalW = bars * barW + (bars - 1) * gap
        val startX = (w - totalW) / 2f
        val baseY = h - 68f * d
        for (i in 0 until bars) {
            val distCenter = 1f - kotlin.math.abs(i - bars / 2f) / (bars / 2f + 1f)
            val wave = kotlin.math.abs(sin(phase * 6.5f + i * 0.65f))
            val maxH = if (modeState == "speak") 34f * d else 24f * d
            val bh = (6f * d + maxH * wave * distCenter)
            barPaint.color = if (i % 2 == 0) cPrimary else cSecondary
            val x = startX + i * (barW + gap)
            cv.drawRoundRect(x, baseY - bh / 2f, x + barW, baseY + bh / 2f, barW / 2f, barW / 2f, barPaint)
        }
    }

    fun start() {
        if (anim != null) return
        val an = ValueAnimator.ofFloat(0f, (Math.PI * 2.0).toFloat())
        an.duration = 2600
        an.repeatCount = ValueAnimator.INFINITE
        an.interpolator = LinearInterpolator()
        an.addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
        an.start()
        anim = an
    }

    fun stop() {
        anim?.cancel()
        anim = null
    }
}

/**
 * Floating Futuristic AI Core Orb View (replaces the old static photo bubble on every screen).
 * Renders a living holographic Nova/Jarvis AI sphere with rotating neon rings and reactive core.
 */
class AiOrbView(c: Context) : View(c) {
    private var angle = 0f
    private var state = "" // "", "listen", "think", "speak"
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val arcRect = RectF()
    private var anim: ValueAnimator? = null

    init {
        startAnim()
    }

    fun setOrbState(s: String) {
        state = s
        invalidate()
    }

    fun startAnim() {
        if (anim != null) return
        val a = ValueAnimator.ofFloat(0f, 360f)
        a.duration = 4000
        a.repeatCount = ValueAnimator.INFINITE
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            angle = it.animatedValue as Float
            invalidate()
        }
        a.start()
        anim = a
    }

    fun stopAnim() {
        anim?.cancel()
        anim = null
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val cx = w / 2f
        val cy = h / 2f
        val r = min(w, h) / 2f - 4f

        val cMain = when (state) {
            "speak" -> Color.parseColor("#FF2BD6")
            "think" -> Color.parseColor("#A855F7")
            "listen" -> Color.parseColor("#00FFCC")
            else -> Color.parseColor("#00F6FF")
        }
        val cAccent = when (state) {
            "speak" -> Color.parseColor("#00F6FF")
            "think" -> Color.parseColor("#00F6FF")
            else -> Color.parseColor("#7C3AED")
        }

        // 1. Deep cyber-glass circular base
        paint.shader = RadialGradient(
            cx, cy, r,
            intArrayOf(Color.parseColor("#111C35"), Color.parseColor("#050914"), Color.parseColor("#02040A")),
            floatArrayOf(0f, 0.72f, 1f),
            Shader.TileMode.CLAMP
        )
        cv.drawCircle(cx, cy, r, paint)

        // 2. Outer glowing neon ring
        ringPaint.shader = null
        ringPaint.color = cMain
        ringPaint.alpha = 220
        ringPaint.strokeWidth = r * 0.09f
        cv.drawCircle(cx, cy, r * 0.92f, ringPaint)

        // 3. Counter-rotating segmented holographic tech arcs
        val rOuterArc = r * 0.74f
        arcRect.set(cx - rOuterArc, cy - rOuterArc, cx + rOuterArc, cy + rOuterArc)
        ringPaint.color = cAccent
        ringPaint.alpha = 230
        ringPaint.strokeWidth = r * 0.08f
        cv.drawArc(arcRect, angle, 75f, false, ringPaint)
        cv.drawArc(arcRect, angle + 120f, 65f, false, ringPaint)
        cv.drawArc(arcRect, angle + 240f, 75f, false, ringPaint)

        val rInnerArc = r * 0.54f
        arcRect.set(cx - rInnerArc, cy - rInnerArc, cx + rInnerArc, cy + rInnerArc)
        ringPaint.color = cMain
        ringPaint.alpha = 240
        ringPaint.strokeWidth = r * 0.07f
        val rev = -angle * 1.4f
        cv.drawArc(arcRect, rev, 95f, false, ringPaint)
        cv.drawArc(arcRect, rev + 180f, 95f, false, ringPaint)

        // 4. Pulsing AI plasma nucleus core
        val rads = Math.toRadians((angle * 3f).toDouble())
        val pulse = 0.85f + 0.15f * sin(rads).toFloat()
        val coreR = r * 0.34f * (if (state.isNotEmpty()) pulse * 1.15f else pulse)
        paint.shader = RadialGradient(
            cx, cy, coreR.coerceAtLeast(2f),
            intArrayOf(Color.WHITE, cMain, Color.TRANSPARENT),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        cv.drawCircle(cx, cy, coreR, paint)
    }
}
