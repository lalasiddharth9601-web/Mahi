package com.vinit.mahi

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class MahiAccess : AccessibilityService() {

    companion object {
        @Volatile
        var inst: MahiAccess? = null

        @Volatile
        var waSendUntil = 0L

        @Volatile
        var ytPlayUntil = 0L

        @Volatile
        var ytQuery = ""
    }

    private val hh = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            var again = false
            try {
                if (now < waSendUntil) {
                    if (!trySend()) again = true
                }
                if (now < ytPlayUntil) {
                    if (!tryPlay()) again = true
                }
            } catch (e: Exception) {
                again = true
            }
            if (again && (now < waSendUntil || now < ytPlayUntil)) {
                hh.postDelayed(this, 650)
            }
        }
    }

    fun arm() {
        hh.removeCallbacks(tick)
        hh.postDelayed(tick, 1400)
    }

    fun armWhatsApp() {
        hh.removeCallbacks(tick)
        hh.postDelayed(tick, 1200)
    }

    /** Wait 2.2 seconds for YouTube search results page to load so we never click an old home/miniplayer video. */
    fun armYouTube() {
        hh.removeCallbacks(tick)
        hh.postDelayed(tick, 2200)
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        inst = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        inst = null
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}

    private fun collectNodes(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
        if (n == null) return
        out.add(n)
        for (i in 0 until n.childCount) {
            collectNodes(n.getChild(i), out)
        }
    }

    private fun clickNode(n0: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = n0
        var depth = 0
        while (n != null && depth < 6) {
            if (n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            n = n.parent
            depth++
        }
        return false
    }

    private fun tapAt(x: Float, y: Float): Boolean {
        return try {
            val path = Path()
            path.moveTo(x, y)
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0L, 65L))
                .build()
            dispatchGesture(g, null, null)
        } catch (e: Exception) {
            false
        }
    }

    private fun trySend(): Boolean {
        val root = rootInActiveWindow ?: return false
        val pkg = root.packageName?.toString() ?: ""
        if (!pkg.startsWith("com.whatsapp")) return false
        var found: AccessibilityNodeInfo? = null
        for (id in listOf("$pkg:id/send", "com.whatsapp:id/send", "com.whatsapp.w4b:id/send")) {
            val l = root.findAccessibilityNodeInfosByViewId(id)
            if (l != null && l.isNotEmpty()) {
                found = l[0]
                break
            }
        }
        if (found == null) {
            val all = ArrayList<AccessibilityNodeInfo>()
            collectNodes(root, all)
            found = all.firstOrNull {
                val d = it.contentDescription?.toString()?.lowercase()?.trim() ?: ""
                d == "send" || d == "भेजें"
            }
        }
        val node = found ?: return false
        var ok = clickNode(node)
        if (!ok) {
            val r = Rect()
            node.getBoundsInScreen(r)
            if (!r.isEmpty) ok = tapAt(r.exactCenterX(), r.exactCenterY())
        }
        if (ok) waSendUntil = 0L
        return ok
    }

    /**
     * Accurately selects the first genuine YouTube search result video item in the middle of the screen,
     * ignoring top search bars, filter chips, ads, and bottom miniplayer controls.
     */
    private fun tryPlay(): Boolean {
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() != "com.google.android.youtube") return false

        val dm = resources.displayMetrics
        val screenH = dm.heightPixels
        val minY = (screenH * 0.18f).toInt()
        val maxY = (screenH * 0.80f).toInt()

        val all = ArrayList<AccessibilityNodeInfo>()
        collectNodes(root, all)

        val qWords = Actions.phoneticKey(ytQuery).split(" ").filter { it.length >= 3 }
        var bestNode: AccessibilityNodeInfo? = null
        var bestScore = 0

        for (node in all) {
            val desc = (node.contentDescription?.toString() ?: "") + " " + (node.text?.toString() ?: "")
            val low = desc.lowercase().trim()
            if (low.length < 12) continue
            // Skip ads, search bar, filter chips, miniplayer, and navigation tabs
            if (low.contains("search youtube") || low.contains("voice search") || low.contains("sponsored") ||
                low.contains("minimized") || low.contains("close miniplayer") || low == "play video"
            ) continue

            val r = Rect()
            node.getBoundsInScreen(r)
            if (r.top < minY || r.bottom > maxY || r.height() < (48 * dm.density).toInt()) continue

            val looksLikeVideo = low.contains("minute") || low.contains("second") || low.contains("views") ||
                low.contains("ago") || low.contains("मिनट") || low.contains("सेकंड") || low.contains("व्यू") ||
                low.contains("play video")
            if (!looksLikeVideo && qWords.isEmpty()) continue

            var score = if (looksLikeVideo) 100 else 30
            val dKey = Actions.phoneticKey(low)
            for (qw in qWords) {
                if (dKey.contains(qw)) score += 80
            }
            // Prefer the top-most matching result in the search list
            score += ((maxY - r.top) / 20).coerceAtLeast(0)

            if (score > bestScore) {
                bestScore = score
                bestNode = node
            }
        }

        val target = bestNode ?: return false
        var ok = clickNode(target)
        if (!ok) {
            val r = Rect()
            target.getBoundsInScreen(r)
            if (!r.isEmpty) ok = tapAt(r.exactCenterX(), r.exactCenterY())
        }
        if (ok) ytPlayUntil = 0L
        return ok
    }
}
