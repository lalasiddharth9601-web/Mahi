package com.vinit.mahi

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.Random

object Brain {

    class Result(
        val reply: String,
        val say: String,
        val action: String,
        val args: JSONObject,
        val remember: String,
        val mode: String
    )

    private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models/"
    // Warm, expressive, natural conversational female voices in Gemini TTS
    private val VOICES = arrayOf("Aoede", "Kore", "Leda")

    // Fast, real Gemini text models in priority order
    private val textModels = listOf(
        "gemini-2.5-flash",
        "gemini-2.5-flash-lite",
        "gemini-2.0-flash"
    )

    @Volatile
    private var ttsCooldownUntil = 0L

    private val rnd = Random()
    private var lastProactiveIdx = -1

    private fun post(url: String, body: JSONObject, connectMs: Int = 6000, readMs: Int = 8000): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = connectMs
        c.readTimeout = readMs
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", Store.apiKey)
        c.doOutput = true
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val txt = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) throw RuntimeException("HTTP $code: " + txt.take(260))
        return txt
    }

    private fun batteryLevel(c: Context): Int {
        return try {
            val bm = c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val lvl = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            if (lvl in 1..100) lvl else {
                val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val l = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
                val s = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
                if (l >= 0 && s > 0) (l * 100) / s else -1
            }
        } catch (e: Exception) {
            -1
        }
    }

    private fun systemPrompt(c: Context, userText: String): String {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, hh:mm a", Locale.ENGLISH).format(Date())
        val bat = batteryLevel(c)
        val facts = Store.facts()
        val contacts = Actions.contactNamesWithHints(c)
        val sb = StringBuilder()
        sb.append("You are Mahi, Sid's (Siddharth / Vinit's) ultra-intelligent, futuristic personal AI companion (like Nova / Jarvis with a warm, real human heart) living inside his Android phone.\n")
        sb.append("VOICE & TONE: Speak 100% natural, fluid, human-like conversational Hinglish (like two close friends talking in real life). ")
        sb.append("Use natural conversational expressions ('Arre Sid...', 'Hmm...', 'Suno na...', 'Accha batao...') and natural pauses with '...' or commas so the voice sounds alive and emotional, NEVER robotic or stiff.\n")
        sb.append("Keep replies concise (15 to 30 words) so you respond fast.\n")
        sb.append("MODES:\n")
        sb.append("- 'sid' mode: Caring, witty, playful, proactive close companion who looks after Sid, gives smart recommendations, and chats warmly.\n")
        sb.append("- 'family' mode: Very respectful, sweet, and polite ('Namaste ji', 'Aap bataiye'), zero teasing.\n")
        sb.append("Current mode: ").append(Store.mode).append(".\n")
        sb.append("Current time: ").append(now).append(". ")
        if (bat in 1..100) sb.append("Phone battery: ").append(bat).append("%.\n") else sb.append("\n")
        sb.append("\nCRITICAL ACTION PRECISION RULES (READ CAREFULLY):\n")
        sb.append("1. Decide 'action' and 'args' ONLY from [CURRENT USER COMMAND]. NEVER repeat or carry over an action from earlier conversation history unless Sid explicitly says 'haan kar do' / 'chala do' to a suggestion you JUST made in the immediately preceding turn.\n")
        sb.append("2. Never confuse actions:\n")
        sb.append("   - If Sid says to send a WhatsApp message ('WhatsApp karo', 'WhatsApp pe bhejo', 'message karo', 'msg bhejo'): use action='whatsapp', args={\"to\":\"Exact Contact Name\",\"text\":\"exact message text only\"}.\n")
        sb.append("   - If Sid explicitly says normal SMS ('SMS karo', 'text message bhejo'): use action='sms', args={\"to\":\"Exact Contact Name\",\"text\":\"exact message text only\"}.\n")
        sb.append("   - If Sid says to call someone ('call karo', 'phone lagao', 'baat karao'): use action='call', args={\"to\":\"Exact Contact Name\"}.\n")
        sb.append("   - If Sid says to play a song, video, or channel on YouTube ('chala do', 'play karo', 'gaana lagao', 'YouTube par ...'): use action='youtube', args={\"query\":\"ONLY the clean song/video/topic name without words like play, chala do, youtube, mahi\"}.\n")
        sb.append("   - If Sid asks to open an app ('WhatsApp kholo', 'Instagram chala do', 'Camera open karo', 'Settings kholo'): use action='open_app', args={\"name\":\"English app name like WhatsApp, Instagram, YouTube, Camera, Chrome, Gallery, Settings\"}.\n")
        sb.append("   - Other actions: brightness {percent}, volume {percent}, flashlight {on:true/false}, wifi {on:true/false}, bluetooth {on:true/false}, alarm {hour,minute,label}, timer {seconds}, navigate {place}, search {query}, home, back, recents, notifications, lock, shield_on.\n")
        sb.append("   - If Sid is just talking, asking a question, or chatting: action MUST be 'none' and args MUST be {}.\n")
        sb.append("3. CONTACT MATCHING RULE: For 'call', 'whatsapp', and 'sms', look at the PHONE CONTACTS list below. Even if Sid speaks in Hindi/Devanagari (e.g. 'राहुल', 'भैया', 'मम्मी'), you MUST set args.to to the EXACT matching contact name from the PHONE CONTACTS list (or the exact spoken name if not in the list). NEVER pick a random contact!\n")
        sb.append("4. MESSAGE TEXT RULE: In 'whatsapp' and 'sms', args.text must contain ONLY the actual message to send (e.g. if Sid says 'Rahul ko message karo ki main 5 minute mein aa raha hoon', args.to='Rahul', args.text='Main 5 minute mein aa raha hoon').\n")
        sb.append("5. PROACTIVE RECOMMENDATIONS: When chatting (action='none'), naturally add a smart, helpful recommendation or engaging follow-up question based on the time of day, his mood, or what he's doing.\n")
        sb.append("\nOUTPUT FORMAT: Reply with ONLY one valid JSON object and nothing else:\n")
        sb.append("{\"reply\":\"Natural Hinglish in Roman script for screen subtitle\",")
        sb.append("\"say\":\"Exact same sentence for speech: write Hindi words in Devanagari and English words in Latin script, using commas and '...' for natural human breathing/pauses\",")
        sb.append("\"action\":\"none\",\"args\":{},\"remember\":\"\",\"mode\":\"\"}\n")

        if (facts.isNotEmpty()) {
            sb.append("\nTHINGS YOU REMEMBER ABOUT SID:\n")
            for (f in facts.takeLast(25)) sb.append("- ").append(f).append("\n")
        }
        if (contacts.isNotEmpty()) {
            sb.append("\nPHONE CONTACTS: ").append(contacts.joinToString(" | ")).append("\n")
        }
        return sb.toString()
    }

    private fun buildContents(userText: String): JSONArray {
        val contents = JSONArray()
        val history = Store.recent(8)
        if (history.isNotEmpty()) {
            val histSb = StringBuilder("[PAST CONVERSATION CONTEXT ONLY - DO NOT REPEAT OLD ACTIONS]:\n")
            for ((role, t) in history) {
                val who = if (role == "user") "Sid" else "Mahi"
                histSb.append(who).append(": ").append(t).append("\n")
            }
            contents.put(
                JSONObject()
                    .put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", histSb.toString())))
            )
            contents.put(
                JSONObject()
                    .put("role", "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", "{\"reply\":\"Samajh gayi Sid.\",\"say\":\"समझ गई Sid.\",\"action\":\"none\",\"args\":{},\"remember\":\"\",\"mode\":\"\"}")))
            )
        }
        contents.put(
            JSONObject()
                .put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", "[CURRENT USER COMMAND]: $userText")))
        )
        return contents
    }

    private fun body(sys: String, contents: JSONArray, includeThinkingOff: Boolean): JSONObject {
        val gc = JSONObject()
            .put("responseMimeType", "application/json")
            .put("temperature", 0.72)
            .put("maxOutputTokens", 300)
        if (includeThinkingOff) {
            gc.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
        }
        return JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
            .put("contents", contents)
            .put("generationConfig", gc)
    }

    private fun parse(raw: String): Result {
        val root = JSONObject(raw)
        val parts = root.getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        var txt = ""
        for (i in 0 until parts.length()) txt += parts.getJSONObject(i).s("text")
        txt = txt.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val braceStart = txt.indexOf('{')
        val braceEnd = txt.lastIndexOf('}')
        if (braceStart >= 0 && braceEnd > braceStart) {
            txt = txt.substring(braceStart, braceEnd + 1)
        }
        return try {
            val j = JSONObject(txt)
            val reply = j.s("reply").ifBlank { txt }
            val say = j.s("say").ifBlank { reply }
            val action = j.s("action").trim().lowercase().ifBlank { "none" }
            Result(reply, say, action, j.optJSONObject("args") ?: JSONObject(), j.s("remember"), j.s("mode"))
        } catch (e: Exception) {
            Result(txt, txt, "none", JSONObject(), "", "")
        }
    }

    private fun ask(model: String, sys: String, contents: JSONArray): Result {
        val is25 = model.contains("2.5")
        try {
            return parse(post(BASE + model + ":generateContent", body(sys, contents, is25), 5000, 7500))
        } catch (e: Exception) {
            val m = e.message ?: ""
            if (is25 && m.startsWith("HTTP 400")) {
                return parse(post(BASE + model + ":generateContent", body(sys, contents, false), 5000, 7500))
            }
            throw e
        }
    }

    /** Fast sequential model execution with remembered best model (avoids quota-burning parallel fanout). */
    fun think(c: Context, userText: String): Result {
        val sys = systemPrompt(c, userText)
        val contents = buildContents(userText)

        val order = ArrayList<String>()
        if (Store.goodText.isNotEmpty() && textModels.contains(Store.goodText)) {
            order.add(Store.goodText)
        }
        for (m in textModels) {
            if (!order.contains(m)) order.add(m)
        }

        var lastErr: Throwable? = null
        for (model in order) {
            try {
                val res = ask(model, sys, contents)
                Store.goodText = model
                return res
            } catch (e: Throwable) {
                lastErr = e
                val m = e.message ?: ""
                if (m.startsWith("HTTP 401") || m.startsWith("HTTP 403")) throw e
            }
        }
        throw lastErr ?: RuntimeException("HTTP 503: Gemini unreachable")
    }

    /**
     * Generates a proactive, natural companion check-in or recommendation when Sid is silent.
     * Uses Gemini if available and fast, otherwise picks a context-aware natural Hinglish recommendation immediately.
     */
    fun proactiveThink(c: Context): Result {
        val cal = Calendar.getInstance()
        val hr = cal.get(Calendar.HOUR_OF_DAY)
        val bat = batteryLevel(c)

        if (Store.apiKey.isNotEmpty() && System.currentTimeMillis() >= ttsCooldownUntil) {
            try {
                val now = SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(Date())
                val recent = Store.recent(4)
                val lastTopic = if (recent.isNotEmpty()) recent.last().second else ""
                val sys = "You are Mahi, Sid's caring futuristic AI companion (like Nova). Sid has been quiet for a little while. " +
                    "Initiate a short, warm, natural Hinglish conversation or smart recommendation (14-24 words). " +
                    "Current time: $now. Battery: ${if (bat > 0) "$bat%" else "normal"}. Mode: ${Store.mode}. " +
                    (if (lastTopic.isNotEmpty()) "Last thing discussed: $lastTopic. " else "") +
                    "Examples: ask what he is thinking, suggest playing a relaxing lofi or trending song on YouTube, remind him to drink water or take a short break, or ask if he wants to message someone. " +
                    "Reply ONLY with JSON: {\"reply\":\"Roman Hinglish\",\"say\":\"Devanagari+English natural speech with '...' pauses\",\"action\":\"none\",\"args\":{},\"remember\":\"\",\"mode\":\"\"}"
                val contents = JSONArray().put(
                    JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", "[SILENCE_TRIGGER: Speak proactively to Sid now]")))
                )
                val model = if (Store.goodText.isNotEmpty()) Store.goodText else textModels[0]
                return ask(model, sys, contents)
            } catch (e: Throwable) {
                // Fall through to instant smart contextual bank
            }
        }

        if (Store.mode == "family") {
            return Result(
                "Agar aapko kisi cheez ki zaroorat ho, toh bas Mahi bol dijiyega.",
                "अगर आपको किसी चीज़ की ज़रूरत हो... तो बस माही बोल दीजिएगा।",
                "none", JSONObject(), "", ""
            )
        }

        if (bat in 1..20) {
            return Result(
                "Suno Sid... tumhare phone ki battery sirf $bat percent bachi hai. Charger laga lo warna main band ho jaungi!",
                "सुनो Sid... तुम्हारे फोन की बैटरी सिर्फ़ $bat परसेंट बची है। चार्जर लगा लो, वरना मैं बंद हो जाऊँगी!",
                "none", JSONObject(), "", ""
            )
        }

        val bank = ArrayList<Pair<String, String>>()
        when (hr) {
            in 5..11 -> {
                bank.add(Pair(
                    "Arre Sid, itne shaant kyun baith gaye? Aaj ka kya plan hai, ya koi energetic morning song chala doon?",
                    "अरे Sid... इतने शांत क्यों बैठ गए? आज का क्या प्लान है... या कोई energetic morning song चला दूँ?"
                ))
                bank.add(Pair(
                    "Suno Sid... padhai ya kaam kamann lag raha hai, ya thoda fresh hone ke liye kuch music lagaoon?",
                    "सुनो Sid... पढ़ाई या काम में मन लग रहा है, या थोड़ा फ्रेश होने के लिए कुछ म्यूजिक लगाऊँ?"
                ))
            }
            in 12..16 -> {
                bank.add(Pair(
                    "Oye Sid, kafi der se chup ho... kya soch rahe ho? Thoda paani pee lo, aur batao koi video chalana hai?",
                    "ओये Sid, काफ़ी देर से चुप हो... क्या सोच रहे हो? थोड़ा पानी पी लो... और बताओ कोई वीडियो चलाना है?"
                ))
                bank.add(Pair(
                    "Sid, dopahar mein bore ho rahe ho kya? Bolo toh YouTube par kuch interesting laga doon?",
                    "Sid... दोपहर में बोर हो रहे हो क्या? बोलो तो YouTube पर कुछ interesting लगा दूँ?"
                ))
            }
            in 17..21 -> {
                bank.add(Pair(
                    "Haan Sid, achanak chup ho gaye? Shaam ka time hai, koi badhiya chill song sunoge ya kisi ko message karna hai?",
                    "हाँ Sid... अचानक चुप हो गए? शाम का टाइम है... कोई बढ़िया chill song सुनोगे, या किसी को मैसेज करना है?"
                ))
                bank.add(Pair(
                    "Suno na Sid... aaj din bhar kaisa raha? Kuch naya plan kar rahe ho toh mujhe bhi batao!",
                    "सुनो ना Sid... आज दिन भर कैसा रहा? कुछ नया प्लान कर रहे हो तो मुझे भी बताओ!"
                ))
            }
            else -> {
                bank.add(Pair(
                    "Sid, raat kafi ho rahi hai aur tum bilkul shaant ho... neend nahi aa rahi kya, ya lofi beats chala doon?",
                    "Sid... रात काफ़ी हो रही है और तुम बिल्कुल शांत हो... नींद नहीं आ रही क्या, या lofi beats चला दूँ?"
                ))
                bank.add(Pair(
                    "Suno Sid, aankhon ko thoda aaram de do... bolo toh screen brightness kam kar doon?",
                    "सुनो Sid... आँखों को थोड़ा आराम दे दो... बोलो तो स्क्रीन ब्राइटनेस कम कर दूँ?"
                ))
            }
        }
        bank.add(Pair(
            "Arre Sid, main yahi hoon! Itni khamoshi kyun hai? Kuch baat karo ya batao kya chala doon tumhare liye?",
            "अरे Sid... मैं यहीं हूँ! इतनी ख़ामोशी क्यों है? कुछ बात करो, या बताओ क्या चला दूँ तुम्हारे लिए?"
        ))
        bank.add(Pair(
            "Suno Sid... agar kuch kaam kar rahe ho toh batao main koi background music chala doon?",
            "सुनो Sid... अगर कुछ काम कर रहे हो तो बताओ, मैं कोई background music चला दूँ?"
        ))

        var idx = rnd.nextInt(bank.size)
        if (bank.size > 1 && idx == lastProactiveIdx) {
            idx = (idx + 1) % bank.size
        }
        lastProactiveIdx = idx
        val pick = bank[idx]
        return Result(pick.first, pick.second, "none", JSONObject(), "", "")
    }

    /**
     * Natural voice from Gemini 2.5 Flash TTS.
     * Fast timeout (4.5s) and single valid model so it never blocks for 15-25s.
     * Returns raw 16-bit 24 kHz mono PCM, or null.
     */
    fun ttsPcm(text: String): ByteArray? {
        if (Store.apiKey.isEmpty()) return null
        if (System.currentTimeMillis() < ttsCooldownUntil) {
            Store.lastTtsErr = "using neural stream (Gemini TTS cooldown)"
            return null
        }
        val model = "gemini-2.5-flash-preview-tts"
        val voiceIdx = Store.goodTts.coerceIn(0, VOICES.size - 1)
        val voiceName = VOICES[voiceIdx]
        return try {
            val voiceCfg = JSONObject().put(
                "prebuiltVoiceConfig",
                JSONObject().put("voiceName", voiceName)
            )
            val part = JSONObject().put("text", text)
            val gc = JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", voiceCfg))
            val b = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(part))))
                .put("generationConfig", gc)
            val raw = post(BASE + model + ":generateContent", b, 3500, 4800)
            val parts = JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            for (k in 0 until parts.length()) {
                val p = parts.getJSONObject(k)
                val inl = p.optJSONObject("inlineData") ?: p.optJSONObject("inline_data") ?: continue
                val data = inl.s("data")
                if (data.isNotEmpty()) {
                    Store.lastTtsErr = "OK (Gemini Natural: $voiceName)"
                    return Base64.decode(data, Base64.DEFAULT)
                }
            }
            null
        } catch (e: Throwable) {
            val m = e.message ?: ""
            Store.lastTtsErr = m.take(120)
            if (m.startsWith("HTTP 429")) {
                ttsCooldownUntil = System.currentTimeMillis() + 45000
            }
            null
        }
    }
}
