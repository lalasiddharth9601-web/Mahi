package com.vinit.mahi

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import java.util.concurrent.Executors

/**
 * Always-on foreground AI companion service.
 * phase 0 = waiting for "Hello Mahi" (and monitoring silence for proactive talk)
 * phase 1 = actively listening for user command
 * phase 2 = thinking / speaking
 */
class WakeService : Service() {

    companion object {
        const val ACT_LISTEN = "com.vinit.mahi.LISTEN"
        const val ACT_APPLY = "com.vinit.mahi.APPLY"
        const val ACT_TEXT = "com.vinit.mahi.TEXT"
        const val CH = "mahi_listen"

        @Volatile
        var running = false
    }

    private val h = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null
    private var phase = 0
    private var gen = 0
    private var wl: PowerManager.WakeLock? = null
    private val worker = Executors.newSingleThreadExecutor()
    private val mutedStreams = ArrayList<Int>()
    private val nameRe = Regex("(mahi|maahi|mahee|maahee|mahe|mehi|माही|माहि|महि|मही|माई|माहे|माहीं)", RegexOption.IGNORE_CASE)

    private val restartRun = Runnable { if (phase == 0 && Store.handsFree) listen(false) }
    private val unmuteRun = Runnable { unmute() }
    private val watchdogRun = Runnable { if (phase == 2) endToWake() }

    /** Proactive silence companion timer: initiates conversation when Sid stays silent. */
    private var proactiveCount = 0
    private val proactiveRun = Runnable { triggerProactiveIfSilent() }

    @Volatile
    private var lastSpoken = ""

    @Volatile
    private var okExchange = false

    @Volatile
    private var actionErr: String? = null

    private var bubble: View? = null
    private var orbView: AiOrbView? = null
    private var neon: NeonView? = null
    private var cap: TextView? = null
    private val capHide = Runnable { cap?.visibility = View.GONE }
    private var uiVisible = false
    private var wm: WindowManager? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        Store.init(this)
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "Mahi AI Core", NotificationManager.IMPORTANCE_LOW))
        val tap = Intent(this, WakeService::class.java).setAction(ACT_LISTEN).putExtra("launch", true)
        val pi = PendingIntent.getForegroundService(this, 1, tap, PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Mahi AI Core Active")
            .setContentText("Tap the glowing AI Orb on any screen or say 'Hello Mahi'")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        startForeground(1, n)
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "mahi:wake")
            wl?.setReferenceCounted(false)
            wl?.acquire()
        } catch (e: Exception) {
        }
        Speaker.init(this)
        try {
            val am0 = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            for (st in intArrayOf(AudioManager.STREAM_MUSIC, AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_SYSTEM)) {
                try {
                    am0.adjustStreamVolume(st, AudioManager.ADJUST_UNMUTE, 0)
                } catch (e: Exception) {
                }
            }
        } catch (e: Exception) {
        }
        showBubble()
        scheduleProactive()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val act = intent?.action
        when (act) {
            ACT_LISTEN -> {
                proactiveCount = 0
                h.post { startFromWake("", wakeNeedsScreen()) }
            }
            ACT_TEXT -> {
                val txt = intent.getStringExtra("text")?.trim() ?: ""
                if (txt.isNotEmpty()) {
                    proactiveCount = 0
                    h.post { submit(txt) }
                }
            }
            ACT_APPLY -> {
                h.post {
                    applyHandsFree()
                    scheduleProactive()
                }
            }
            else -> {
                h.post {
                    showBubble()
                    applyHandsFree()
                    scheduleProactive()
                }
            }
        }
        return START_STICKY
    }

    private fun applyHandsFree() {
        if (Store.handsFree) {
            if (phase == 0 && sr == null) listen(false)
        } else if (phase == 0) {
            gen++
            killSr()
            h.removeCallbacks(restartRun)
        }
    }

    override fun onDestroy() {
        running = false
        gen++
        h.removeCallbacksAndMessages(null)
        killSr()
        unmute()
        try {
            wl?.release()
        } catch (e: Exception) {
        }
        hideBubble()
        worker.shutdownNow()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- Proactive Silence Engine

    private fun scheduleProactive() {
        h.removeCallbacks(proactiveRun)
        if (!Store.proactiveMode) return
        if (proactiveCount >= 2) return // Wait for user interaction after 2 unanswered check-ins
        val delayMs = (Store.silenceSec.coerceIn(15, 90) * 1000L)
        h.postDelayed(proactiveRun, delayMs)
    }

    private fun triggerProactiveIfSilent() {
        if (!Store.proactiveMode || phase != 0 || proactiveCount >= 2) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!pm.isInteractive || km.isKeyguardLocked) {
            scheduleProactive()
            return
        }
        proactiveCount++
        gen++
        killSr()
        phase = 2
        Bus.emit("state", "think")
        worker.execute {
            try {
                val r = Brain.proactiveThink(this)
                Store.addMsg("model", r.reply)
                talk(r.reply, r.say)
                okExchange = true
            } catch (e: Throwable) {
                okExchange = false
            }
            h.post { afterTalk() }
        }
    }

    // ---------------------------------------------------------------- Speech Recognition

    private fun first(b: Bundle?): List<String> =
        b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: emptyList()

    private fun killSr() {
        try {
            sr?.cancel()
            sr?.destroy()
        } catch (e: Exception) {
        }
        sr = null
    }

    private fun listen(command: Boolean) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Bus.emit("say", "Google Speech service nahi mili.")
            return
        }
        killSr()
        val my = ++gen
        val rec = SpeechRecognizer.createSpeechRecognizer(this)
        rec.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {
                if (command) h.removeCallbacks(proactiveRun)
            }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                if (my != gen) return
                val pl = first(partialResults)
                if (pl.isNotEmpty()) Bus.emit("heard", pl[0])
                if (!command) checkWake(pl, false)
            }

            override fun onResults(results: Bundle?) {
                if (my != gen) return
                scheduleUnmute()
                val list = first(results)
                if (list.isNotEmpty()) Bus.emit("heard", "OK: " + list[0])
                if (!command) {
                    if (!checkWake(list, true)) restartWake(250)
                } else {
                    val tt = list.firstOrNull() ?: ""
                    if (tt.isBlank() || isEcho(tt)) {
                        endToWake()
                    } else {
                        proactiveCount = 0
                        submit(tt)
                    }
                }
            }

            override fun onError(error: Int) {
                if (my != gen) return
                scheduleUnmute()
                if (error != 7 && error != 6) Bus.emit("heard", "mic status $error")
                if (!command) {
                    if (error == 9) {
                        Bus.emit("say", "Microphone permission on karo.")
                        return
                    }
                    restartWake(if (error == 8) 1200L else 350L)
                } else {
                    endToWake()
                }
            }
        })
        sr = rec
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        if (command) {
            i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 850L)
            i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 600L)
        }
        rec.startListening(i)
    }

    private fun restartWake(delay: Long) {
        h.removeCallbacks(restartRun)
        h.postDelayed(restartRun, delay)
    }

    private fun checkWake(cands: List<String>, final: Boolean): Boolean {
        for (t in cands) {
            val m = nameRe.find(t) ?: continue
            val rest = t.substring(m.range.last + 1).trim(' ', ',', '.', '!', '?', '।')
            if (rest.length > 2 && !final) return false
            proactiveCount = 0
            startFromWake(rest, wakeNeedsScreen())
            return true
        }
        return false
    }

    /** True only when phone is locked or overlay is unavailable. Otherwise Mahi works over any screen! */
    private fun wakeNeedsScreen(): Boolean {
        return try {
            val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val ok = Settings.canDrawOverlays(this) && neon != null && pm.isInteractive && !km.isKeyguardLocked
            !ok
        } catch (e: Exception) {
            true
        }
    }

    private fun startFromWake(rest: String, launch: Boolean) {
        gen++
        killSr()
        h.removeCallbacksAndMessages(null)
        phase = 2
        if (launch) launchUi()
        Bus.emit("state", "listen")
        unmute()
        if (rest.length > 2) {
            submit(rest)
        } else {
            worker.execute {
                try {
                    Greeter.greet(this, Store.mode) { t ->
                        Bus.emit("say", t)
                        Bus.emit("state", "speak")
                    }
                } catch (e: Throwable) {
                }
                h.post {
                    phase = 1
                    Bus.emit("state", "listen")
                    listen(true)
                }
            }
        }
    }

    private fun endToWake() {
        gen++
        killSr()
        phase = 0
        Bus.emit("state", "")
        val stamp = SystemClock.elapsedRealtime()
        h.postDelayed({
            if (phase == 0 && SystemClock.elapsedRealtime() - stamp >= 5000) Bus.emit("idle", "")
        }, 6000)
        if (Store.handsFree) restartWake(300)
        scheduleProactive()
    }

    // ---------------------------------------------------------------- Thinking + Talking

    private fun submit(text: String) {
        gen++
        killSr()
        phase = 2
        okExchange = false
        h.removeCallbacks(unmuteRun)
        h.removeCallbacks(proactiveRun)
        unmute()
        h.removeCallbacks(watchdogRun)
        h.postDelayed(watchdogRun, 35000)
        Bus.emit("state", "think")
        worker.execute {
            try {
                converse(text)
            } catch (e: Throwable) {
                val m = e.message ?: e.javaClass.simpleName
                val busy = m.startsWith("HTTP 503") || m.startsWith("HTTP 429") || m.contains("unreachable")
                val keyBad = m.startsWith("HTTP 400") || m.startsWith("HTTP 401") || m.startsWith("HTTP 403")
                val friendly = if (busy) "Sid, abhi server thoda busy hai, ek second baad bolo."
                else if (keyBad) "Sid, API key check karo, Setup mein key dobara save kar do."
                else "Sid, internet connection thoda weak lag raha hai."
                val friendlyHi = if (busy) "Sid, अभी सर्वर थोड़ा बिज़ी है, एक सेकंड बाद बोलो।"
                else if (keyBad) "Sid, API key चेक करो, Setup में key दोबारा सेव कर दो।"
                else "Sid, इंटरनेट कनेक्शन थोड़ा वीक लग रहा है।"
                Bus.emit("say", friendly)
                Bus.emit("state", "speak")
                try {
                    Speaker.speakPhone(this, friendlyHi)
                } catch (e2: Throwable) {
                }
            }
            h.post { afterTalk() }
        }
    }

    private fun converse(text: String) {
        val low = text.lowercase()
        if (low.contains("2507") || low.contains("पच्चीस जीरो सात") || low.contains("twenty five zero seven")) {
            Bus.emit("shield", "off")
            okExchange = true
            talk("Pehchaan liya Sid! Security Shield unlock ho gaya, bolo ab kya karna hai?", "पहचान लिया Sid! सिक्योरिटी शील्ड अनलॉक हो गया... बोलो अब क्या करना है?")
            return
        }

        // Fast local command check for unambiguous instant device controls, or AI think with local fallback
        val r = try {
            if (Store.apiKey.isNotEmpty()) {
                Brain.think(this, text)
            } else {
                val lc = LocalCmd.parse(text) ?: Brain.Result(
                    "Sid, Setup mein apni Gemini API key daal do taaki main har baat samajh sakoon!",
                    "Sid, Setup में अपनी Gemini API key डाल दो ताकि मैं हर बात समझ सकूँ!",
                    "none", org.json.JSONObject(), "", ""
                )
                if (lc is LocalCmd.Cmd) Brain.Result(lc.say, lc.spoken, lc.action, lc.args, "", "")
                else lc as Brain.Result
            }
        } catch (e: Throwable) {
            val lc = LocalCmd.parse(text) ?: throw e
            Brain.Result(lc.say, lc.spoken, lc.action, lc.args, "", "")
        }

        okExchange = true
        if (r.mode == "sid" || r.mode == "family") {
            Store.mode = r.mode
            Bus.emit("mode", r.mode)
        }
        if (r.remember.isNotBlank()) Store.addFact(r.remember)
        Store.addMsg("user", text)
        Store.addMsg("model", r.reply)

        val hasAction = r.action != "none" && r.action.isNotEmpty()
        val late = r.action == "call" || r.action == "lock" || r.action == "shield_on"
        actionErr = null
        talk(r.reply, r.say) {
            if (hasAction && !late) {
                Thread { actionErr = Actions.run(this, r.action, r.args) }.start()
            }
        }
        if (hasAction && late) actionErr = Actions.run(this, r.action, r.args)
        val err = actionErr
        if (err != null) {
            Bus.emit("say", err)
            Speaker.speakPhone(this, err)
        }
    }

    private fun talk(display: String, spoken: String, onAudioStart: () -> Unit = {}) {
        lastSpoken = (display + " " + spoken).lowercase()
        Speaker.speak(this, display, spoken) {
            Bus.emit("say", display)
            Bus.emit("state", "speak")
            onAudioStart()
        }
    }

    private fun afterTalk() {
        h.removeCallbacks(watchdogRun)
        if (!okExchange) {
            endToWake()
            return
        }
        phase = 2
        h.postDelayed({
            phase = 1
            Bus.emit("state", "listen")
            listen(true)
        }, 500)
    }

    private fun isEcho(t: String): Boolean {
        val w = t.lowercase().split(" ").filter { it.length > 2 }
        if (w.size < 3 || lastSpoken.isEmpty()) return false
        val hit = w.count { lastSpoken.contains(it) }
        return hit * 2 >= w.size
    }

    // ---------------------------------------------------------------- Futuristic Floating AI Core Overlay

    private fun showBubble() {
        if (bubble != null) return
        if (!Settings.canDrawOverlays(this)) return
        try {
            val w = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            wm = w
            val d = resources.displayMetrics.density
            val size = (62 * d).toInt()

            val orb = AiOrbView(this)
            orbView = orb
            val ring = FrameLayout(this)
            ring.elevation = 12 * d
            ring.addView(orb, FrameLayout.LayoutParams(size, size))

            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            val screenW = resources.displayMetrics.widthPixels
            val screenH = resources.displayMetrics.heightPixels
            lp.x = screenW - size - (6 * d).toInt()
            lp.y = (screenH * 0.38f).toInt()

            val down = IntArray(4)
            var downTime = 0L
            var dragging = false
            ring.setOnTouchListener { _, ev ->
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> {
                        down[0] = ev.rawX.toInt()
                        down[1] = ev.rawY.toInt()
                        down[2] = lp.x
                        down[3] = lp.y
                        downTime = SystemClock.elapsedRealtime()
                        dragging = false
                        // Instant neon flash feedback on touch
                        neon?.setState("listen")
                        neon?.visibility = View.VISIBLE
                        neon?.start()
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = ev.rawX.toInt() - down[0]
                        val dy = ev.rawY.toInt() - down[1]
                        if (kotlin.math.abs(dx) > 12 || kotlin.math.abs(dy) > 12) dragging = true
                        if (dragging) {
                            lp.x = down[2] + dx
                            lp.y = down[3] + dy
                            try {
                                w.updateViewLayout(ring, lp)
                            } catch (e: Exception) {
                            }
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        val heldMs = SystemClock.elapsedRealtime() - downTime
                        if (dragging) {
                            lp.x = if (lp.x + size / 2 < screenW / 2) (4 * d).toInt() else screenW - size - (4 * d).toInt()
                            try {
                                w.updateViewLayout(ring, lp)
                            } catch (e: Exception) {
                            }
                            if (phase == 0) {
                                neon?.stop()
                                neon?.visibility = View.GONE
                            }
                        } else if (heldMs > 650L) {
                            // Long press opens full-screen Futuristic AI Core HUD
                            launchUi()
                        } else {
                            proactiveCount = 0
                            if (phase != 2) startFromWake("", wakeNeedsScreen())
                        }
                    }
                }
                true
            }

            Bus.bubble = { t, v ->
                h.post {
                    if (t == "say") {
                        val cv = cap
                        if (cv != null) {
                            h.removeCallbacks(capHide)
                            cv.text = v
                            cv.visibility = if (uiVisible) View.GONE else View.VISIBLE
                        }
                    } else if (t == "state") {
                        h.removeCallbacks(capHide)
                        if (v.isEmpty()) h.postDelayed(capHide, 2800)
                        orbView?.setOrbState(v)
                        val nv = neon
                        if (nv != null) {
                            nv.setState(v)
                            if (v.isNotEmpty() && !uiVisible) {
                                nv.visibility = View.VISIBLE
                                nv.start()
                            } else {
                                nv.stop()
                                nv.visibility = View.GONE
                            }
                        }
                    } else if (t == "visible") {
                        uiVisible = (v == "1")
                        ring.visibility = if (v == "1") View.GONE else View.VISIBLE
                        if (v == "1") {
                            neon?.stop()
                            neon?.visibility = View.GONE
                            cap?.visibility = View.GONE
                        }
                    }
                }
            }

            try {
                val nv = NeonView(this)
                nv.visibility = View.GONE
                val nlp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
                )
                w.addView(nv, nlp)
                neon = nv
            } catch (e: Exception) {
                neon = null
            }

            try {
                val tv = TextView(this)
                tv.setTextColor(Color.parseColor("#E2F8FF"))
                tv.textSize = 15f
                tv.gravity = Gravity.CENTER
                tv.setPadding((18 * d).toInt(), (12 * d).toInt(), (18 * d).toInt(), (12 * d).toInt())
                tv.maxWidth = (screenW * 0.88f).toInt()
                val tbg = GradientDrawable()
                tbg.cornerRadius = 24 * d
                tbg.setColor(Color.parseColor("#E6060D1F"))
                tbg.setStroke((1.5f * d).toInt(), Color.parseColor("#00F6FF"))
                tv.background = tbg
                tv.visibility = View.GONE
                val clp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT
                )
                clp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                clp.y = (108 * d).toInt()
                w.addView(tv, clp)
                cap = tv
            } catch (e: Exception) {
                cap = null
            }

            w.addView(ring, lp)
            bubble = ring
        } catch (e: Exception) {
            bubble = null
        }
    }

    private fun hideBubble() {
        Bus.bubble = null
        try {
            orbView?.stopAnim()
            val b = bubble
            if (b != null) wm?.removeView(b)
        } catch (e: Exception) {
        }
        try {
            val nv = neon
            if (nv != null) {
                nv.stop()
                wm?.removeView(nv)
            }
        } catch (e: Exception) {
        }
        try {
            val cv = cap
            if (cv != null) wm?.removeView(cv)
        } catch (e: Exception) {
        }
        cap = null
        neon = null
        orbView = null
        bubble = null
    }

    // ---------------------------------------------------------------- Helpers

    private fun launchUi() {
        try {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                    .putExtra("wake", true)
            )
        } catch (e: Exception) {
        }
    }

    private fun beep() {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
            tg.startTone(ToneGenerator.TONE_PROP_ACK, 150)
            h.postDelayed({ tg.release() }, 500)
        } catch (e: Exception) {
        }
    }

    private fun scheduleUnmute() {
        h.removeCallbacks(unmuteRun)
        h.postDelayed(unmuteRun, 600)
    }

    private fun unmute() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            for (s in mutedStreams) {
                try {
                    am.adjustStreamVolume(s, AudioManager.ADJUST_UNMUTE, 0)
                } catch (e2: Exception) {
                }
            }
        } catch (e: Exception) {
        }
        mutedStreams.clear()
    }
}
