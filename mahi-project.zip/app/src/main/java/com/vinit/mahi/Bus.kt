package com.vinit.mahi

import java.util.concurrent.ConcurrentHashMap

/** Tiny message bus: background service -> WebView screen. */
object Bus {
    @Volatile
    var ui: ((String, String) -> Unit)? = null
    val last = ConcurrentHashMap<String, String>()

    fun emit(type: String, value: String) {
        if (type == "state" || type == "shield" || type == "mode") last[type] = value
        ui?.invoke(type, value)
    }

    fun replay() {
        val u = ui ?: return
        u("mode", Store.mode)
        for ((k, v) in last) {
            if (k != "mode") u(k, v)
        }
    }
}
