package com.vinit.mahi

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.concurrent.Executors

/**
 * Always-on foreground service.
 * phase 0 = waiting for "Hello Mahi", 1 = listening for a command, 2 = busy (thinking / talking)
 */
class WakeService : Service() {

    companion object {
        const val ACT_LISTEN = "com.vinit.mahi.LISTEN"
        const val CH = "mahi_listen"

        @Volatile
        var running = false
    }

    private val h = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null
    private var phase = 0
    private var gen = 0
    private var wl: PowerManager.WakeLock? = null
    private val worker = Executors.newSingleThreadExecutor()
    private val mutedStreams = ArrayList<Int>()
    private val nameRe = Regex("(mahi|maahi|mahee|maahee|माही|माहि|महि|मही)", RegexOption.IGNORE_CASE)

    private val restartRun = Runnable { if (phase == 0) listen(false) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        Store.init(this)
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "Mahi", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), 0)
        val n = Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Mahi is listening")
            .setContentText("Say \"Hello Mahi\" anytime")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        startForeground(1, n)
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "mahi:wake")
            wl?.setReferenceCounted(false)
            wl?.acquire()
        } catch (e: Exception) {
        }
        Speaker.init(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACT_LISTEN) {
            h.post { startFromWake("", false) }
        } else {
            h.post { if (phase == 0 && sr == null) listen(false) }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        gen++
        h.removeCallbacksAndMessages(null)
        killSr()
        unmute()
        try {
            wl?.release()
        } catch (e: Exception) {
        }
        worker.shutdownNow()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- listening

    private fun first(b: Bundle?): List<String> =
        b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: emptyList()

    private fun killSr() {
        try {
            sr?.cancel()
            sr?.destroy()
        } catch (e: Exception) {
        }
        sr = null
    }

    private fun listen(command: Boolean) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Bus.emit("say", "Speech service not found. Install or update the Google app.")
            return
        }
        killSr()
        val my = ++gen
        val rec = SpeechRecognizer.createSpeechRecognizer(this)
        rec.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                if (my != gen) return
                if (!command) checkWake(first(partialResults), false)
            }

            override fun onResults(results: Bundle?) {
                if (my != gen) return
                val list = first(results)
                if (!command) {
                    if (!checkWake(list, true)) restartWake(250)
                } else {
                    val t = list.firstOrNull()
                    if (t.isNullOrBlank()) endToWake() else submit(t)
                }
            }

            override fun onError(error: Int) {
                if (my != gen) return
                if (!command) {
                    if (error == 9) {
                        Bus.emit("say", "Microphone permission is missing.")
                        return
                    }
                    restartWake(if (error == 8) 1500L else 350L)
                } else {
                    endToWake()
                }
            }
        })
        sr = rec
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        if (command) {
            // finish quickly after you stop talking
            i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
            i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 800L)
        }
        muteBeep()
        rec.startListening(i)
    }

    private fun restartWake(delay: Long) {
        h.removeCallbacks(restartRun)
        h.postDelayed(restartRun, delay)
    }

    private fun checkWake(cands: List<String>, final: Boolean): Boolean {
        for (t in cands) {
            val m = nameRe.find(t) ?: continue
            val rest = t.substring(m.range.last + 1).trim(' ', ',', '.', '!', '?', '।')
            if (rest.length > 2 && !final) return false   // wait for the whole sentence
            startFromWake(rest, true)
            return true
        }
        return false
    }

    private fun startFromWake(rest: String, launch: Boolean) {
        gen++
        killSr()
        h.removeCallbacksAndMessages(null)
        phase = 2
        if (launch) launchUi()
        Bus.emit("state", "listen")
        beep()
        if (rest.length > 2) {
            submit(rest)
        } else {
            h.postDelayed({
                phase = 1
                listen(true)
            }, 400)
        }
    }

    private fun endToWake() {
        gen++
        killSr()
        phase = 0
        Bus.emit("state", "")
        val stamp = SystemClock.elapsedRealtime()
        h.postDelayed({
            if (phase == 0 && SystemClock.elapsedRealtime() - stamp >= 5000) Bus.emit("idle", "")
        }, 6000)
        restartWake(300)
    }

    // ---------------------------------------------------------------- thinking + talking

    private fun submit(text: String) {
        gen++
        killSr()
        phase = 2
        Bus.emit("state", "think")
        worker.execute {
            try {
                converse(text)
            } catch (e: Throwable) {
                val m = e.message ?: e.javaClass.simpleName
                val short = if (m.length > 90) m.substring(0, 90) else m
                Bus.emit("say", "Sid, kuch gadbad ho gayi: $short")
                Bus.emit("state", "speak")
                try {
                    Speaker.speak(this, "Sid, mujhe internet ya API key mein kuch dikkat lag rahi hai.", "Sid, मुझे इंटरनेट या API key में कुछ दिक्कत लग रही है।")
                } catch (e2: Throwable) {
                }
            }
            h.post { afterTalk() }
        }
    }

    private fun converse(text: String) {
        val low = text.lowercase()
        if (low.contains("2507") || low.contains("पच्चीस जीरो सात") || low.contains("twenty five zero seven")) {
            Bus.emit("shield", "off")
            talk("Pehchaan liya Sid! Phone unlock ho gaya, bolo kya karna hai?", "पहचान लिया Sid! फोन अनलॉक हो गया, बोलो क्या करना है?")
            return
        }
        val r = Brain.think(this, text)
        if (r.mode == "sid" || r.mode == "family") {
            Store.mode = r.mode
            Bus.emit("mode", r.mode)
        }
        if (r.remember.isNotBlank()) Store.addFact(r.remember)
        Store.addMsg("user", text)
        Store.addMsg("model", r.reply)
        talk(r.reply, r.say)
        if (r.action != "none") {
            val err = Actions.run(this, r.action, r.args)
            if (err != null) {
                Bus.emit("say", err)
                Speaker.speak(this, "Sid, ye nahi ho paya. $err")
            }
        }
    }

    private fun talk(display: String, spoken: String) {
        Bus.emit("say", display)
        Bus.emit("state", "speak")
        Speaker.speak(this, display, spoken)
    }

    /** After a reply, stay in listening mode for a follow-up (no need to say "Hello Mahi" again). */
    private fun afterTalk() {
        phase = 1
        Bus.emit("state", "listen")
        listen(true)
    }

    // ---------------------------------------------------------------- helpers

    private fun launchUi() {
        try {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                    .putExtra("wake", true)
            )
        } catch (e: Exception) {
        }
    }

    private fun beep() {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
            tg.startTone(ToneGenerator.TONE_PROP_ACK, 150)
            h.postDelayed({ tg.release() }, 500)
        } catch (e: Exception) {
        }
    }

    /** Hides the recogniser's "ding" by muting for a moment (only when the phone is on normal ringer and no music plays). */
    private fun muteBeep() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (am.ringerMode != AudioManager.RINGER_MODE_NORMAL) return
            unmute()
            val streams = ArrayList<Int>()
            streams.add(AudioManager.STREAM_NOTIFICATION)
            streams.add(AudioManager.STREAM_SYSTEM)
            if (!am.isMusicActive) streams.add(AudioManager.STREAM_MUSIC)
            for (s in streams) {
                if (!am.isStreamMute(s)) {
                    am.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, 0)
                    mutedStreams.add(s)
                }
            }
            h.postDelayed({ unmute() }, 900)
        } catch (e: Exception) {
        }
    }

    private fun unmute() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            for (s in mutedStreams) am.adjustStreamVolume(s, AudioManager.ADJUST_UNMUTE, 0)
        } catch (e: Exception) {
        }
        mutedStreams.clear()
    }
}
