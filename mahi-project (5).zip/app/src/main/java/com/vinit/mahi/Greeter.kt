package com.vinit.mahi

import android.content.Context
import java.io.File
import java.util.Random

/** Instant "Haan Sid, bolo!" replies. Natural clips are made once and cached, so she answers at once. */
object Greeter {
    private val sid = listOf(
        Pair("Haan Sid, bolo!", "हाँ Sid, बोलो!"),
        Pair("Ji Sid, main sun rahi hoon.", "जी Sid, मैं सुन रही हूँ।"),
        Pair("Bolo jaanu, kya karna hai?", "बोलो जानू, क्या करना है?"),
        Pair("Haan Sid?", "हाँ Sid?")
    )
    private val fam = listOf(
        Pair("Ji, boliye?", "जी, बोलिए?"),
        Pair("Namaste, boliye, main kya madad karoon?", "नमस्ते, बोलिए, मैं क्या मदद करूँ?")
    )

    @Volatile
    private var busy = false
    private val rnd = Random()

    private fun file(c: Context, mode: String, i: Int) = File(c.cacheDir, "greet_" + mode + "_" + i + ".pcm")

    /** Blocking. onStart gets the written text the moment the voice starts. */
    fun greet(c: Context, mode: String, onStart: (String) -> Unit) {
        val m = if (mode == "family") "family" else "sid"
        val list = if (m == "family") fam else sid
        val i = rnd.nextInt(list.size)
        val f = file(c, m, i)
        if (Store.naturalVoice && f.exists() && f.length() > 2000) {
            onStart(list[i].first)
            Speaker.playPcm(f.readBytes())
        } else {
            Speaker.speakPhone(c, list[i].second) { onStart(list[i].first) }
        }
    }

    /** Makes the missing natural clips in the background (stops quietly if Gemini is busy). */
    fun prepare(c: Context) {
        if (busy || !Store.naturalVoice || Store.apiKey.isEmpty()) return
        busy = true
        val app = c.applicationContext
        Thread {
            try {
                for (m in listOf("sid", "family")) {
                    val list = if (m == "family") fam else sid
                    for (i in list.indices) {
                        val f = file(app, m, i)
                        if (f.exists() && f.length() > 2000) continue
                        val pcm = Brain.ttsPcm(list[i].second)
                        if (pcm != null && pcm.size > 2000) f.writeBytes(pcm) else return@Thread
                    }
                }
            } catch (e: Throwable) {
            } finally {
                busy = false
            }
        }.start()
    }
}
