package com.vinit.mahi

import android.content.Context
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

object Speaker {
    private var tts: TextToSpeech? = null

    @Volatile
    private var ready = false

    fun init(c: Context) {
        if (tts != null) return
        tts = TextToSpeech(c.applicationContext) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.setLanguage(Locale("en", "IN"))
                ready = true
            }
        }
    }

    /** Blocking. Natural Gemini voice first, phone voice as backup. */
    fun speak(c: Context, text: String, voiceText: String = text, onStart: () -> Unit = {}) {
        init(c)
        var ok = false
        if (Store.naturalVoice && Store.apiKey.isNotEmpty()) {
            ok = try {
                val pcm = Brain.ttsPcm(voiceText)
                if (pcm != null && pcm.size > 2000) {
                    onStart()
                    play(pcm)
                    true
                } else false
            } catch (e: Throwable) {
                false
            }
        }
        if (!ok) {
            Bus.emit("heard", "voice: phone (" + Store.lastTtsErr.take(70) + ")")
            phoneSpeak(voiceText, onStart)
        }
    }

    private fun pickHindi(t: TextToSpeech) {
        try {
            var best: Voice? = null
            val vs = t.voices
            if (vs != null) {
                for (v in vs) {
                    if (v.locale.language != "hi") continue
                    val f = v.features
                    if (f != null && f.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)) continue
                    val b = best
                    if (b == null || v.quality > b.quality) best = v
                }
            }
            val pick = best
            if (pick != null) {
                t.setVoice(pick)
                return
            }
        } catch (e: Exception) {
        }
        try {
            t.setLanguage(Locale("hi", "IN"))
        } catch (e: Exception) {
        }
    }

    fun speakPhone(c: Context, text: String, started: () -> Unit = {}) {
        init(c)
        phoneSpeak(text, started)
    }

    fun playPcm(pcm: ByteArray) {
        play(pcm)
    }

    private fun play(pcm: ByteArray) {
        val rate = 24000
        val track = AudioTrack(
            AudioManager.STREAM_MUSIC, rate, AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT, pcm.size, AudioTrack.MODE_STATIC
        )
        track.write(pcm, 0, pcm.size)
        track.play()
        val frames = pcm.size / 2
        var guard = 0
        while (track.playbackHeadPosition < frames && guard < 700) {
            Thread.sleep(50)
            guard++
        }
        try {
            track.stop()
        } catch (e: Exception) {
        }
        track.release()
    }

    private fun phoneSpeak(text: String, started: () -> Unit) {
        var n = 0
        while (!ready && n < 30) {
            Thread.sleep(100)
            n++
        }
        val t = tts ?: return
        val latch = CountDownLatch(1)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                started()
            }
            override fun onDone(utteranceId: String?) {
                latch.countDown()
            }

            override fun onError(utteranceId: String?) {
                latch.countDown()
            }
        })
        pickHindi(t)
        t.setPitch(1.1f)
        t.setSpeechRate(0.92f)
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mahi1")
        latch.await(25, TimeUnit.SECONDS)
    }
}
