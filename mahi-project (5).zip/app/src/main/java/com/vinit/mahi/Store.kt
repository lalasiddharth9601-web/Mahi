package com.vinit.mahi

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONObject

/** Safe string read from a JSONObject (JSON null becomes an empty string). */
fun JSONObject.s(k: String): String {
    val v = opt(k)
    return if (v == null || v == JSONObject.NULL) "" else v.toString()
}

object Store {
    private lateinit var app: Context

    fun init(c: Context) {
        if (!::app.isInitialized) app = c.applicationContext
    }

    private val prefs get() = app.getSharedPreferences("mahi", Context.MODE_PRIVATE)

    var apiKey: String
        get() = prefs.getString("key", "") ?: ""
        set(v) { prefs.edit().putString("key", v.trim()).apply() }

    var mode: String
        get() = prefs.getString("mode", "sid") ?: "sid"
        set(v) { prefs.edit().putString("mode", v).apply() }

    var naturalVoice: Boolean
        get() = prefs.getBoolean("natural", true)
        set(v) { prefs.edit().putBoolean("natural", v).apply() }

    var handsFree: Boolean
        get() = prefs.getBoolean("hands", false)
        set(v) { prefs.edit().putBoolean("hands", v).apply() }

    var lastTtsErr: String
        get() = prefs.getString("ttsErr", "") ?: ""
        set(v) { prefs.edit().putString("ttsErr", v).apply() }

    var goodText: String
        get() = prefs.getString("goodText", "") ?: ""
        set(v) { prefs.edit().putString("goodText", v).apply() }

    var goodTts: Int
        get() = prefs.getInt("goodTts", -1)
        set(v) { prefs.edit().putInt("goodTts", v).apply() }

    private class Db(c: Context) : SQLiteOpenHelper(c, "mahi.db", null, 1) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL("CREATE TABLE msgs(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, role TEXT, text TEXT)")
            db.execSQL("CREATE TABLE facts(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, fact TEXT)")
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    }

    private val db: SQLiteDatabase by lazy { Db(app).writableDatabase }

    fun addMsg(role: String, text: String) {
        val cv = ContentValues()
        cv.put("ts", System.currentTimeMillis())
        cv.put("role", role)
        cv.put("text", text)
        db.insert("msgs", null, cv)
    }

    /** Last n messages, oldest first, always starting with a "user" message. */
    fun recent(n: Int): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        db.rawQuery("SELECT role, text FROM msgs ORDER BY id DESC LIMIT $n", null).use { c ->
            while (c.moveToNext()) out.add(Pair(c.getString(0), c.getString(1)))
        }
        out.reverse()
        while (out.isNotEmpty() && out[0].first != "user") out.removeAt(0)
        return out
    }

    fun addFact(f: String) {
        val fact = f.trim()
        if (fact.isEmpty()) return
        var exists = false
        db.rawQuery("SELECT 1 FROM facts WHERE fact = ?", arrayOf(fact)).use { c ->
            exists = c.moveToFirst()
        }
        if (exists) return
        val cv = ContentValues()
        cv.put("ts", System.currentTimeMillis())
        cv.put("fact", fact)
        db.insert("facts", null, cv)
    }

    fun facts(): List<String> {
        val out = ArrayList<String>()
        db.rawQuery("SELECT fact FROM facts ORDER BY id DESC LIMIT 80", null).use { c ->
            while (c.moveToNext()) out.add(c.getString(0))
        }
        out.reverse()
        return out
    }
}
