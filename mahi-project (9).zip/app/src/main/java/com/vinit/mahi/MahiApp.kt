package com.vinit.mahi

import android.app.Application
import android.os.Looper

class MahiApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        // A crash in any background thread would kill the whole app and make Android switch Accessibility off.
        // So background errors are swallowed; only a real crash of the main thread is allowed through.
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            if (t === Looper.getMainLooper().thread) {
                old?.uncaughtException(t, e)
            }
        }
    }
}
