package com.vinit.mahi

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.provider.ContactsContract
import android.telecom.TelecomManager

/** Helpers for answering and ending phone calls for Siddharth. */
object CallScreen {
    @Volatile
    var pendingGoal = ""

    @Volatile
    var pendingName = ""

    @Volatile
    var pendingUntil = 0L

    fun nameFor(c: Context, number: String): String {
        if (number.isBlank()) return ""
        if (c.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return number
        try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            val cur = c.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
            if (cur != null) {
                cur.use {
                    if (it.moveToFirst()) {
                        val n = it.getString(0)
                        if (!n.isNullOrBlank()) return n
                    }
                }
            }
        } catch (e: Exception) {
        }
        return number
    }

    fun accept(c: Context): Boolean {
        if (c.checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) return false
        return try {
            val tm = c.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            tm.acceptRingingCall()
            true
        } catch (e: Throwable) {
            false
        }
    }

    fun endCall(c: Context): Boolean {
        try {
            val tm = c.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            val m = tm.javaClass.getMethod("endCall")
            m.invoke(tm)
            return true
        } catch (e: Throwable) {
        }
        val acc = MahiAccess.inst ?: return false
        return acc.tapText("end call") || acc.tapText("कॉल समाप्त")
    }

    fun speaker(c: Context, on: Boolean) {
        try {
            val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.isSpeakerphoneOn = on
        } catch (e: Exception) {
        }
    }
}
