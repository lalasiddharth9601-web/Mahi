package com.vinit.mahi

import org.json.JSONObject

/** Simple offline command reader, used only when Gemini is busy or unreachable. */
object LocalCmd {
    class Cmd(val action: String, val args: JSONObject, val say: String, val spoken: String)

    private fun clean(s: String): String =
        s.replace(Regex("(?i)\\b(karo|kar do|kardo|please|plz|lagao|laga do|chalao|chala do)\\b"), " ")
            .replace("करो", " ").replace("कर दो", " ").replace("प्लीज", " ")
            .replace(Regex("\\s+"), " ").trim()

    fun parse(text: String): Cmd? {
        val low = text.lowercase().trim()
        val num = Regex("\\d+").find(low)?.value

        if (low.contains("torch") || low.contains("flashlight") || low.contains("टॉर्च") || low.contains("फ्लैश")) {
            val off = low.contains(" off") || low.contains("band") || low.contains("बंद") || low.contains("बन्द")
            return Cmd("flashlight", JSONObject().put("on", !off),
                if (off) "Torch band kar rahi hoon." else "Torch on kar rahi hoon.",
                if (off) "टॉर्च बंद कर रही हूँ।" else "टॉर्च ऑन कर रही हूँ।")
        }
        if ((low.contains("brightness") || low.contains("ब्राइटनेस")) && num != null) {
            return Cmd("brightness", JSONObject().put("percent", num), "Brightness $num percent kar rahi hoon.", "ब्राइटनेस $num परसेंट कर रही हूँ।")
        }
        if ((low.contains("volume") || low.contains("वॉल्यूम")) && num != null) {
            return Cmd("volume", JSONObject().put("percent", num), "Volume $num percent kar rahi hoon.", "वॉल्यूम $num परसेंट कर रही हूँ।")
        }
        if (low.contains("lock") || low.contains("लॉक")) {
            return Cmd("lock", JSONObject(), "Phone lock kar rahi hoon.", "फोन लॉक कर रही हूँ।")
        }
        if (low.contains("youtube") || low.contains("यूट्यूब") || low.contains("gaana") || low.contains("गाना") || low.contains("गाने") || low.contains("song")) {
            var q = low
            for (w in listOf("youtube", "यूट्यूब", "par", "पर", "gaana", "गाना", "गाने", "song", "play", "mahi", "माही", "hello", "हेलो")) q = q.replace(w, " ")
            q = clean(q)
            if (q.isEmpty()) q = "lofi songs"
            return Cmd("youtube", JSONObject().put("query", q), "Ye lo, YouTube par $q laga rahi hoon.", "ये लो, YouTube पर $q लगा रही हूँ।")
        }
        val callRe = Regex("(?:call|कॉल)\\s+(.+)").find(low) ?: Regex("(.+?)\\s+(?:ko|को)\\s+(?:call|कॉल)").find(low)
        if (callRe != null) {
            val name = clean(callRe.groupValues[1].replace("mahi", " ").replace("माही", " "))
            if (name.isNotEmpty()) {
                return Cmd("call", JSONObject().put("to", name), "Theek hai, main $name ko call kar rahi hoon.", "ठीक है, मैं $name को कॉल कर रही हूँ।")
            }
        }
        val openRe = Regex("(?:open|kholo|खोलो|खोल)\\s+(.+)").find(low) ?: Regex("(.+?)\\s+(?:kholo|खोलो|open)").find(low)
        if (openRe != null) {
            val name = clean(openRe.groupValues[1].replace("mahi", " ").replace("माही", " "))
            if (name.isNotEmpty()) {
                return Cmd("open_app", JSONObject().put("name", name), "Theek hai, $name khol rahi hoon.", "ठीक है, $name खोल रही हूँ।")
            }
        }
        return null
    }
}
