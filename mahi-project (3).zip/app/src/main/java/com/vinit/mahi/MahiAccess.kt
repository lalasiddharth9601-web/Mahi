package com.vinit.mahi

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class MahiAccess : AccessibilityService() {

    companion object {
        @Volatile
        var inst: MahiAccess? = null

        @Volatile
        var waSendUntil = 0L

        @Volatile
        var ytPlayUntil = 0L
    }

    private val hh = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            var again = false
            try {
                if (now < waSendUntil) {
                    if (!trySend()) again = true
                }
                if (now < ytPlayUntil) {
                    if (!tryPlay()) again = true
                }
            } catch (e: Exception) {
                again = true
            }
            if (again && (now < waSendUntil || now < ytPlayUntil)) hh.postDelayed(this, 700)
        }
    }

    /** Start watching for the WhatsApp Send button / first YouTube result. */
    fun arm() {
        hh.removeCallbacks(tick)
        hh.postDelayed(tick, 1500)
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        inst = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        inst = null
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}

    private fun find(n: AccessibilityNodeInfo?, pred: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (n == null) return null
        if (pred(n)) return n
        for (i in 0 until n.childCount) {
            val r = find(n.getChild(i), pred)
            if (r != null) return r
        }
        return null
    }

    private fun clickNode(n0: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = n0
        var depth = 0
        while (n != null && depth < 6) {
            if (n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            n = n.parent
            depth++
        }
        return false
    }

    private fun tapAt(x: Float, y: Float): Boolean {
        return try {
            val path = Path()
            path.moveTo(x, y)
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0L, 60L))
                .build()
            dispatchGesture(g, null, null)
        } catch (e: Exception) {
            false
        }
    }

    private fun trySend(): Boolean {
        val root = rootInActiveWindow ?: return false
        val pkg = root.packageName?.toString() ?: ""
        if (!pkg.startsWith("com.whatsapp")) return false
        var found: AccessibilityNodeInfo? = null
        for (id in listOf(pkg + ":id/send", "com.whatsapp:id/send", "com.whatsapp.w4b:id/send")) {
            val l = root.findAccessibilityNodeInfosByViewId(id)
            if (l != null && l.isNotEmpty()) {
                found = l[0]
                break
            }
        }
        if (found == null) {
            found = find(root) {
                val d = it.contentDescription?.toString()?.lowercase() ?: ""
                d == "send" || d == "भेजें"
            }
        }
        val node = found ?: return false
        var ok = clickNode(node)
        if (!ok) {
            val r = Rect()
            node.getBoundsInScreen(r)
            ok = tapAt(r.exactCenterX(), r.exactCenterY())
        }
        if (ok) waSendUntil = 0L
        return ok
    }

    private fun tryPlay(): Boolean {
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() != "com.google.android.youtube") return false
        val node = find(root) {
            val d = it.contentDescription?.toString()?.lowercase() ?: ""
            d.contains("play video")
        } ?: return false
        val ok = clickNode(node)
        if (ok) ytPlayUntil = 0L
        return ok
    }
}
