package com.vinit.mahi

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Store.init(c)
        val micOk = c.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (Store.apiKey.isNotEmpty() && micOk) {
            try {
                c.startForegroundService(Intent(c, WakeService::class.java))
            } catch (e: Exception) {
            }
        }
    }
}
