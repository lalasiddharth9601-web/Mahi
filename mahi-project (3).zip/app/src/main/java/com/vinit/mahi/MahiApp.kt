package com.vinit.mahi

import android.app.Application

class MahiApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
    }
}
