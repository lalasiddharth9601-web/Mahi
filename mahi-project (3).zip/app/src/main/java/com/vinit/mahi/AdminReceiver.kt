package com.vinit.mahi

import android.app.admin.DeviceAdminReceiver

class AdminReceiver : DeviceAdminReceiver()
