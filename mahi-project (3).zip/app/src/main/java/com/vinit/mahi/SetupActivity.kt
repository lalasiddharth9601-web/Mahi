package com.vinit.mahi

import android.Manifest
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SetupActivity : Activity() {

    private class Row(val label: TextView, val title: String, val ok: () -> Boolean)

    private val rows = ArrayList<Row>()
    private lateinit var col: LinearLayout
    private lateinit var keyBox: EditText

    private val perms = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CALL_PHONE,
        Manifest.permission.SEND_SMS,
        Manifest.permission.READ_CONTACTS
    )

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        val sv = ScrollView(this)
        sv.setBackgroundColor(Color.parseColor("#0f1b2d"))
        col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(32), dp(18), dp(40))
        sv.addView(col)
        setContentView(sv)

        text("Mahi Setup", 26f, "#ffffff", true)
        text("Do the steps below one time. Every step turns green when done.", 14f, "#9fb3c8", false)

        // 1. API key
        val t1 = text("", 16f, "#ffffff", true)
        rows.add(Row(t1, "1. Gemini API key", { Store.apiKey.isNotEmpty() }))
        keyBox = EditText(this)
        keyBox.hint = "Paste your Gemini API key here (starts with AIza)"
        keyBox.setText(Store.apiKey)
        keyBox.setTextColor(Color.WHITE)
        keyBox.setHintTextColor(Color.parseColor("#6b7f95"))
        keyBox.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        keyBox.setSingleLine(true)
        col.addView(keyBox)
        button("Save key") {
            Store.apiKey = keyBox.text.toString()
            Toast.makeText(this, "Key saved", Toast.LENGTH_SHORT).show()
            refresh()
        }

        // 2. Permissions
        step("2. Permissions", "Microphone, calls, SMS and contacts.", { allPerms() }, "Allow permissions") {
            requestPermissions(perms, 11)
        }

        // 3. Accessibility
        step(
            "3. Accessibility",
            "Lets Mahi press Send in WhatsApp, tap YouTube results, and use Home/Back. Find Mahi in the list and switch it on.",
            { MahiAccess.inst != null }, "Open Accessibility settings"
        ) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        // 4. Write settings
        step("4. System settings", "Lets Mahi change brightness. Switch on \"Allow modify system settings\".",
            { Settings.System.canWrite(this) }, "Allow system settings") {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        }

        // 5. Device admin
        step("5. Device admin", "Lets Mahi lock the phone screen when you ask.", { adminOn() }, "Activate device admin") {
            val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this, AdminReceiver::class.java))
            i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Mahi needs this to lock your phone when you ask.")
            startActivity(i)
        }

        // 6. Battery
        step(
            "6. Keep Mahi alive",
            "Choose \"Allow\" so the phone does not kill Mahi in the background. On Vivo also open App settings and allow Autostart and High background power use.",
            { batteryOk() }, "Allow background running"
        ) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        button("Open App settings (Autostart)") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }

        // 7. Floating bubble
        step(
            "7. Floating Mahi bubble",
            "A small round Mahi that stays on top of every app. Tap it and Mahi appears instantly. Switch on \"Display over other apps\".",
            { Settings.canDrawOverlays(this) }, "Allow floating bubble"
        ) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }

        // Voice switch
        val sw = Switch(this)
        sw.text = "Natural voice (Gemini)"
        sw.setTextColor(Color.WHITE)
        sw.isChecked = Store.naturalVoice
        sw.setOnCheckedChangeListener { _, v -> Store.naturalVoice = v }
        sw.setPadding(0, dp(18), 0, dp(6))
        col.addView(sw)

        // Start / stop
        val go = button("START MAHI") {
            if (Store.apiKey.isEmpty()) {
                Toast.makeText(this, "Paste and save your Gemini key first", Toast.LENGTH_LONG).show()
            } else {
                startForegroundService(Intent(this, WakeService::class.java))
                startActivity(Intent(this, MainActivity::class.java))
            }
        }
        go.setBackgroundColor(Color.parseColor("#0f8f86"))
        go.setTextColor(Color.WHITE)
        button("Stop Mahi") {
            stopService(Intent(this, WakeService::class.java))
            Toast.makeText(this, "Mahi stopped", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    // ------------------------------------------------------------ helpers

    private fun allPerms(): Boolean = perms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun adminOn(): Boolean {
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return dpm.isAdminActive(ComponentName(this, AdminReceiver::class.java))
    }

    private fun batteryOk(): Boolean {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun refresh() {
        for (r in rows) r.label.text = (if (r.ok()) "✅  " else "⬜  ") + r.title
    }

    private fun text(s: String, size: Float, color: String, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(Color.parseColor(color))
        if (bold) t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
        t.setPadding(0, dp(14), 0, dp(4))
        col.addView(t)
        return t
    }

    private fun button(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.gravity = Gravity.CENTER
        b.setOnClickListener { onClick() }
        col.addView(b)
        return b
    }

    private fun step(title: String, hint: String, ok: () -> Boolean, btn: String, onClick: () -> Unit) {
        val t = text("", 16f, "#ffffff", true)
        rows.add(Row(t, title, ok))
        text(hint, 13f, "#9fb3c8", false)
        button(btn, onClick)
    }
}
