package com.vinit.mahi

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator

/** Colour-cycling neon glow along all four screen edges. Drawn as a full-screen touch-through overlay. */
class NeonView(c: Context) : View(c) {
    private var hue = 180f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thick = 36f * c.resources.displayMetrics.density
    private var anim: ValueAnimator? = null

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val a = Color.HSVToColor(235, floatArrayOf(hue, 0.85f, 1f))
        val b = Color.HSVToColor(235, floatArrayOf((hue + 120f) % 360f, 0.85f, 1f))
        val z = Color.HSVToColor(0, floatArrayOf(hue, 0.85f, 1f))

        p.shader = LinearGradient(0f, 0f, 0f, thick, a, z, Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w, thick, p)
        p.shader = LinearGradient(0f, h, 0f, h - thick, b, z, Shader.TileMode.CLAMP)
        cv.drawRect(0f, h - thick, w, h, p)
        p.shader = LinearGradient(0f, 0f, thick, 0f, b, z, Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, thick, h, p)
        p.shader = LinearGradient(w, 0f, w - thick, 0f, a, z, Shader.TileMode.CLAMP)
        cv.drawRect(w - thick, 0f, w, h, p)
    }

    fun start() {
        if (anim != null) return
        val an = ValueAnimator.ofFloat(0f, 360f)
        an.duration = 3500
        an.repeatCount = ValueAnimator.INFINITE
        an.interpolator = LinearInterpolator()
        an.addUpdateListener {
            hue = it.animatedValue as Float
            invalidate()
        }
        an.start()
        anim = an
    }

    fun stop() {
        anim?.cancel()
        anim = null
    }
}
