package com.vinit.mahi

import android.Manifest
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SetupActivity : Activity() {

    private class Row(val label: TextView, val title: String, val ok: () -> Boolean)

    private val rows = ArrayList<Row>()
    private lateinit var col: LinearLayout
    private lateinit var keyBox: EditText
    private lateinit var voiceStatus: TextView

    private val perms = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CALL_PHONE,
        Manifest.permission.SEND_SMS,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.READ_PHONE_STATE,
        Manifest.permission.ANSWER_PHONE_CALLS,
        Manifest.permission.READ_CALL_LOG
    )

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        if (Store.setupDone && !Store.alwaysSetup && !intent.getBooleanExtra("force", false)) {
            // Already set up: go straight to Mahi and keep her running in the background.
            try {
                startForegroundService(Intent(this, WakeService::class.java))
            } catch (e: Exception) {
            }
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }
        val sv = ScrollView(this)
        sv.setBackgroundColor(Color.parseColor("#0f1b2d"))
        col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(32), dp(18), dp(40))
        sv.addView(col)
        setContentView(sv)

        text("Mahi Setup", 26f, "#ffffff", true)
        text("Do the steps below one time. Every step turns green when done.", 14f, "#9fb3c8", false)

        // 1. API key
        val t1 = text("", 16f, "#ffffff", true)
        rows.add(Row(t1, "1. Gemini API key", { Store.apiKey.isNotEmpty() }))
        keyBox = EditText(this)
        keyBox.hint = "Paste your Gemini API key here (starts with AIza)"
        keyBox.setText(Store.apiKey)
        keyBox.setTextColor(Color.WHITE)
        keyBox.setHintTextColor(Color.parseColor("#6b7f95"))
        keyBox.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        keyBox.setSingleLine(true)
        col.addView(keyBox)
        button("Save key") {
            Store.apiKey = keyBox.text.toString()
            Toast.makeText(this, "Key saved", Toast.LENGTH_SHORT).show()
            refresh()
        }

        // 2. Permissions
        step("2. Permissions", "Microphone, calls, SMS and contacts.", { allPerms() }, "Allow permissions") {
            requestPermissions(perms, 11)
        }

        // 3. Accessibility
        step(
            "3. Accessibility",
            "Lets Mahi press Send in WhatsApp, tap YouTube results, and use Home/Back. Find Mahi in the list and switch it on.",
            { MahiAccess.inst != null }, "Open Accessibility settings"
        ) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        text("Permanent fix (one time, needs a computer or a second phone with USB-OTG + ADB): run  adb shell pm grant com.vinit.mahi android.permission.WRITE_SECURE_SETTINGS  . After that Mahi switches Accessibility back on by herself whenever the phone turns it off.", 11f, "#7f93a8", false)

        // 4. Write settings
        step("4. System settings", "Lets Mahi change brightness. Switch on \"Allow modify system settings\".",
            { Settings.System.canWrite(this) }, "Allow system settings") {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        }

        // 5. Device admin
        step("5. Device admin", "Lets Mahi lock the phone screen when you ask.", { adminOn() }, "Activate device admin") {
            val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this, AdminReceiver::class.java))
            i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Mahi needs this to lock your phone when you ask.")
            startActivity(i)
        }

        // 6. Battery
        step(
            "6. Keep Mahi alive",
            "Choose \"Allow\" so the phone does not kill Mahi in the background. On Vivo also open App settings and allow Autostart and High background power use.",
            { batteryOk() }, "Allow background running"
        ) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        button("Open Vivo background settings") {
            val tries = listOf(
                ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"),
                ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager"),
                ComponentName("com.vivo.abe", "com.vivo.applicationbehaviorengine.ui.ExcessivePowerManagerActivity")
            )
            var opened = false
            for (cn in tries) {
                if (opened) break
                try {
                    startActivity(Intent().setComponent(cn))
                    opened = true
                } catch (e: Exception) {
                }
            }
            if (!opened) startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
        text("Tip: if Accessibility keeps switching itself off, allow Mahi in Autostart and High background power use, and lock Mahi in the recent apps screen (pull the Mahi card down or tap its lock icon).", 12f, "#9fb3c8", false)

        // 7. Floating bubble
        step(
            "7. Floating Mahi bubble",
            "A small round Mahi that stays on top of every app. Tap it and Mahi appears instantly. Switch on \"Display over other apps\".",
            { Settings.canDrawOverlays(this) }, "Allow floating bubble"
        ) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }

        // Voice switch
        val sw = Switch(this)
        sw.text = "Natural voice (Gemini)"
        sw.setTextColor(Color.WHITE)
        sw.isChecked = Store.naturalVoice
        sw.setOnCheckedChangeListener { _, v -> Store.naturalVoice = v }
        sw.setPadding(0, dp(18), 0, dp(6))
        col.addView(sw)

        // 8. Notification access
        step(
            "8. Notification access",
            "Lets Mahi read your notifications and tell you which are important. Find Mahi in the list and switch it on.",
            { notifOn() }, "Open Notification access"
        ) {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }

        // Far / near microphone
        val fm = Switch(this)
        fm.text = "Hear me from far away (louder mic, but it also hears people around)"
        fm.setTextColor(Color.WHITE)
        fm.isChecked = Store.farMic
        fm.setOnCheckedChangeListener { _, v -> Store.farMic = v }
        fm.setPadding(0, dp(10), 0, dp(6))
        col.addView(fm)

        // Live voice switch
        val lv = Switch(this)
        lv.text = "Live voice (fast, natural, understands better) - recommended"
        lv.setTextColor(Color.WHITE)
        lv.isChecked = Store.liveMode
        lv.setOnCheckedChangeListener { _, v -> Store.liveMode = v }
        lv.setPadding(0, dp(10), 0, dp(6))
        col.addView(lv)

        // Contact confirmation switch
        val cc = Switch(this)
        cc.text = "Always ask me to confirm the contact before calling or messaging"
        cc.setTextColor(Color.WHITE)
        cc.isChecked = Store.confirmContacts
        cc.setOnCheckedChangeListener { _, v -> Store.confirmContacts = v }
        cc.setPadding(0, dp(10), 0, dp(6))
        col.addView(cc)

        // Show setup every time?
        val sa2 = Switch(this)
        sa2.text = "Show this setup page every time the app opens"
        sa2.setTextColor(Color.WHITE)
        sa2.isChecked = Store.alwaysSetup
        sa2.setOnCheckedChangeListener { _, v -> Store.alwaysSetup = v }
        sa2.setPadding(0, dp(10), 0, dp(6))
        col.addView(sa2)

        // Shake to wake
        val shakeBtn = Button(this)
        shakeBtn.isAllCaps = false
        shakeBtn.text = shakeLabel()
        shakeBtn.setOnClickListener {
            Store.shakeMode = (Store.shakeMode + 1) % 3
            shakeBtn.text = shakeLabel()
            if (WakeService.running) {
                startForegroundService(Intent(this, WakeService::class.java).setAction(WakeService.ACT_APPLY))
            }
        }
        col.addView(shakeBtn)
        text("Shake the phone side to side 5 times to wake Mahi (works on the lock screen too when the screen is on). Walking or running will not trigger it. Tap the button to change.", 12f, "#9fb3c8", false)

        // Hands-free switch
        val hf = Switch(this)
        hf.text = "Hands-free: always listen for \"Hello Mahi\" (mic stays awake and may beep)"
        hf.setTextColor(Color.WHITE)
        hf.isChecked = Store.handsFree
        hf.setOnCheckedChangeListener { _, v ->
            Store.handsFree = v
            if (WakeService.running) {
                startForegroundService(Intent(this, WakeService::class.java).setAction(WakeService.ACT_APPLY))
            }
        }
        hf.setPadding(0, dp(10), 0, dp(6))
        col.addView(hf)

        // Voice test
        voiceStatus = text("", 13f, "#9fb3c8", false)
        button("Test Mahi's voice") {
            Toast.makeText(this, "Testing voice...", Toast.LENGTH_SHORT).show()
            Thread {
                var pcm: ByteArray? = null
                try {
                    pcm = Brain.ttsPcm("हाँ Sid, मैं Mahi हूँ। अब मेरी आवाज़ कैसी लग रही है?")
                } catch (e: Throwable) {
                }
                runOnUiThread { refresh() }
                try {
                    if (pcm != null) Speaker.playPcm(pcm) else Speaker.speakPhone(this, "हाँ Sid, मैं Mahi हूँ। अब मेरी आवाज़ कैसी लग रही है?")
                } catch (e: Throwable) {
                }
            }.start()
        }

        // Start / stop
        val go = button("START MAHI") {
            if (Store.apiKey.isEmpty()) {
                Toast.makeText(this, "Paste and save your Gemini key first", Toast.LENGTH_LONG).show()
            } else {
                Store.setupDone = true
                startForegroundService(Intent(this, WakeService::class.java))
                startActivity(Intent(this, MainActivity::class.java))
            }
        }
        go.setBackgroundColor(Color.parseColor("#0f8f86"))
        go.setTextColor(Color.WHITE)
        button("Stop Mahi") {
            stopService(Intent(this, WakeService::class.java))
            Toast.makeText(this, "Mahi stopped", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    // ------------------------------------------------------------ helpers

    private fun allPerms(): Boolean = perms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun shakeLabel(): String = when (Store.shakeMode) {
        0 -> "Shake to wake Mahi: OFF"
        1 -> "Shake to wake Mahi: only when screen is on (saves battery)"
        else -> "Shake to wake Mahi: always, even screen off (more battery)"
    }

    private fun notifOn(): Boolean {
        val l = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return l.contains(packageName)
    }

    private fun adminOn(): Boolean {
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return dpm.isAdminActive(ComponentName(this, AdminReceiver::class.java))
    }

    private fun batteryOk(): Boolean {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun refresh() {
        if (!::voiceStatus.isInitialized) return
        for (r in rows) r.label.text = (if (r.ok()) "✅  " else "⬜  ") + r.title
        val ve = Store.lastTtsErr
        val ls = Store.liveStatus
        voiceStatus.text = "Live status: " + (if (ls.isEmpty()) "not used yet" else ls) + "\nVoice (classic) status: " + (if (ve.isEmpty()) "not tested yet" else ve)
    }

    private fun text(s: String, size: Float, color: String, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(Color.parseColor(color))
        if (bold) t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
        t.setPadding(0, dp(14), 0, dp(4))
        col.addView(t)
        return t
    }

    private fun button(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.gravity = Gravity.CENTER
        b.setOnClickListener { onClick() }
        col.addView(b)
        return b
    }

    private fun step(title: String, hint: String, ok: () -> Boolean, btn: String, onClick: () -> Unit) {
        val t = text("", 16f, "#ffffff", true)
        rows.add(Row(t, title, ok))
        text(hint, 13f, "#9fb3c8", false)
        button(btn, onClick)
    }
}
