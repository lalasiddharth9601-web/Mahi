package com.vinit.mahi

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class MahiAccess : AccessibilityService() {

    companion object {
        @Volatile
        var inst: MahiAccess? = null

        @Volatile
        var waSendUntil = 0L

        @Volatile
        var ytPlayUntil = 0L

        @Volatile
        var waCallUntil = 0L

        @Volatile
        var waCallVideo = false

        @Volatile
        var waCallStage = 0

        @Volatile
        var waCallStageAt = 0L

        @Volatile
        var camAt = 0L

        @Volatile
        var camUntil = 0L

        @Volatile
        var installUntil = 0L
    }

    private val hh = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            var again = false
            try {
                if (now < waSendUntil) {
                    if (!trySend()) again = true
                }
                if (now < ytPlayUntil) {
                    if (!tryPlay()) again = true
                }
                if (now < waCallUntil) {
                    if (!tryWaCall()) again = true
                }
                if (now < camUntil) {
                    if (!tryCamera()) again = true
                }
                if (now < installUntil) {
                    if (!tryInstall()) again = true
                }
            } catch (e: Throwable) {
                again = true
            }
            if (again && (now < waSendUntil || now < ytPlayUntil || now < waCallUntil || now < camUntil || now < installUntil)) hh.postDelayed(this, 700)
        }
    }

    /** Start watching for the WhatsApp Send / Call button or the first YouTube result. */
    fun arm() {
        hh.removeCallbacks(tick)
        hh.postDelayed(tick, 1500)
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        inst = this
        try {
            Store.init(this)
            Store.accSeen = true
        } catch (e: Exception) {
        }
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        inst = null
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}

    // ------------------------------------------------------------ helpers

    private fun find(n: AccessibilityNodeInfo?, pred: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (n == null) return null
        if (pred(n)) return n
        for (i in 0 until n.childCount) {
            val r = find(n.getChild(i), pred)
            if (r != null) return r
        }
        return null
    }

    private fun clickNode(n0: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = n0
        var depth = 0
        while (n != null && depth < 6) {
            if (n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            n = n.parent
            depth++
        }
        return false
    }

    private fun tapAt(x: Float, y: Float): Boolean {
        return try {
            val path = Path()
            path.moveTo(x, y)
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0L, 60L))
                .build()
            dispatchGesture(g, null, null)
        } catch (e: Exception) {
            false
        }
    }

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float): Boolean {
        return try {
            val path = Path()
            path.moveTo(x1, y1)
            path.lineTo(x2, y2)
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0L, 320L))
                .build()
            dispatchGesture(g, null, null)
        } catch (e: Exception) {
            false
        }
    }

    private fun label(n: AccessibilityNodeInfo): String {
        val t = n.text?.toString() ?: ""
        val d = n.contentDescription?.toString() ?: ""
        return (t + " " + d).trim().lowercase()
    }

    private fun clickOrTap(node: AccessibilityNodeInfo): Boolean {
        var ok = clickNode(node)
        if (!ok) {
            val r = Rect()
            node.getBoundsInScreen(r)
            ok = tapAt(r.exactCenterX(), r.exactCenterY())
        }
        return ok
    }

    // ------------------------------------------------------------ screen control used by Mahi

    /** True once the call screen shows a running timer (= the other person answered). */
    fun callAnswered(): Boolean {
        val root = rootInActiveWindow ?: return false
        val pkg = (root.packageName?.toString() ?: "").lowercase()
        if (!(pkg.contains("incall") || pkg.contains("dialer") || pkg.contains("phone") || pkg.contains("telecom"))) return false
        var found = false
        val timer = Regex("^\\d{1,2}:\\d{2}(:\\d{2})?$")
        fun visit(n: AccessibilityNodeInfo?) {
            if (n == null || found) return
            val t = (n.text?.toString() ?: "").trim()
            if (t.isNotEmpty() && timer.matches(t)) found = true
            for (i in 0 until n.childCount) visit(n.getChild(i))
        }
        visit(root)
        return found
    }

    fun currentPackage(): String = rootInActiveWindow?.packageName?.toString() ?: ""

    /** What is on the screen right now ("*" = tappable). */
    fun dump(): String {
        val root = rootInActiveWindow ?: return "screen not readable"
        val sb = StringBuilder("app=" + (root.packageName ?: "?") + "\n")
        var count = 0
        fun visit(n: AccessibilityNodeInfo?) {
            if (n == null || count >= 80) return
            val t = (n.text?.toString() ?: n.contentDescription?.toString() ?: "").trim()
            if (t.isNotEmpty() && n.isVisibleToUser) {
                val tappable = n.isClickable || (n.parent?.isClickable == true)
                sb.append(if (tappable) "* " else "- ").append(t.take(40)).append("\n")
                count++
            }
            for (i in 0 until n.childCount) visit(n.getChild(i))
        }
        visit(root)
        return sb.toString()
    }

    fun tapText(q: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val low = q.lowercase().trim()
        if (low.isEmpty()) return false
        var exact: AccessibilityNodeInfo? = null
        var partial: AccessibilityNodeInfo? = null
        fun visit(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val t = (n.text?.toString() ?: "").lowercase().trim()
            val d = (n.contentDescription?.toString() ?: "").lowercase().trim()
            if (exact == null && (t == low || d == low)) exact = n
            if (partial == null && (t.contains(low) || d.contains(low))) partial = n
            for (i in 0 until n.childCount) visit(n.getChild(i))
        }
        visit(root)
        val target = exact ?: partial ?: return false
        return clickOrTap(target)
    }

    /** Swipe with the finger moving left / right / up / down (for example to change home-screen pages). */
    private fun findEditable(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (f != null && f.isEditable) return f
        return find(root) { it.isEditable }
    }

    /** Types each tag into the tags box (comma after each one) and then presses Done/Save. Reports back through onDone. */
    fun enterTags(tags: List<String>, onDone: (String) -> Unit) {
        Thread {
            try {
                Thread.sleep(900)
                var edit = findEditable()
                if (edit == null) {
                    if (!tapText("add tags")) tapText("tags")
                    Thread.sleep(1100)
                    edit = findEditable()
                }
                if (edit == null) {
                    onDone("Tags ka box nahi mila. YouTube mein video ka Edit page kholkar Add tags dabao.")
                    return@Thread
                }
                var count = 0
                for (t in tags) {
                    val e = findEditable() ?: break
                    val b = Bundle()
                    b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t + ",")
                    e.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
                    count++
                    Thread.sleep(650)
                }
                Thread.sleep(500)
                tapText("done")
                Thread.sleep(800)
                val saved = tapText("save")
                onDone(if (saved) "$count tags daal diye aur save kar diya." else "$count tags daal diye. Save ka button khud dabana.")
            } catch (e: Throwable) {
                onDone("Tags daalne mein dikkat aayi.")
            }
        }.start()
    }

    fun swipeDir(dir: String): Boolean {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val d = dir.lowercase()
        return if (d.startsWith("left")) swipe(w * 0.85f, h * 0.5f, w * 0.15f, h * 0.5f)
        else if (d.startsWith("right")) swipe(w * 0.15f, h * 0.5f, w * 0.85f, h * 0.5f)
        else if (d.startsWith("up")) swipe(w / 2, h * 0.75f, w / 2, h * 0.25f)
        else swipe(w / 2, h * 0.25f, w / 2, h * 0.75f)
    }

    fun tapPercent(xp: Float, yp: Float): Boolean {
        val dm = resources.displayMetrics
        return tapAt(dm.widthPixels * xp / 100f, dm.heightPixels * yp / 100f)
    }

    fun longPressText(q: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val low = q.lowercase().trim()
        if (low.isEmpty()) return false
        val node = find(root) { n ->
            val t = (n.text?.toString() ?: "").lowercase()
            val d = (n.contentDescription?.toString() ?: "").lowercase()
            t.contains(low) || d.contains(low)
        } ?: return false
        val r = Rect()
        node.getBoundsInScreen(r)
        return try {
            val path = Path()
            path.moveTo(r.exactCenterX(), r.exactCenterY())
            val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0L, 900L)).build()
            dispatchGesture(g, null, null)
        } catch (e: Exception) {
            false
        }
    }

    fun scrollScreen(dir: String): Boolean {
        val down = !(dir.lowercase().startsWith("up") || dir.lowercase().startsWith("back"))
        val root = rootInActiveWindow
        val node = if (root != null) find(root) { it.isScrollable } else null
        if (node != null) {
            val act = if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            if (node.performAction(act)) return true
        }
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        return if (down) swipe(w / 2, h * 0.72f, w / 2, h * 0.28f) else swipe(w / 2, h * 0.28f, w / 2, h * 0.72f)
    }

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        var node: AccessibilityNodeInfo? = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (node == null || !node.isEditable) node = find(root) { it.isEditable }
        val target = node ?: return false
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    // ------------------------------------------------------------ background watchers

    private fun trySend(): Boolean {
        val root = rootInActiveWindow ?: return false
        val pkg = root.packageName?.toString() ?: ""
        if (!pkg.startsWith("com.whatsapp")) return false
        var found: AccessibilityNodeInfo? = null
        for (id in listOf(pkg + ":id/send", "com.whatsapp:id/send", "com.whatsapp.w4b:id/send")) {
            val l = root.findAccessibilityNodeInfosByViewId(id)
            if (l != null && l.isNotEmpty()) {
                found = l[0]
                break
            }
        }
        if (found == null) {
            found = find(root) {
                val d = it.contentDescription?.toString()?.lowercase() ?: ""
                d == "send" || d == "भेजें"
            }
        }
        val node = found ?: return false
        val ok = clickOrTap(node)
        if (ok) waSendUntil = 0L
        return ok
    }

    private fun tryWaCall(): Boolean {
        val root = rootInActiveWindow ?: return false
        val pkg = root.packageName?.toString() ?: ""
        if (!pkg.startsWith("com.whatsapp")) return false
        val now = System.currentTimeMillis()
        if (waCallStage == 0) {
            val words = if (waCallVideo) listOf("video call", "वीडियो कॉल") else listOf("voice call", "audio call", "वॉइस कॉल", "वॉयस कॉल", "ऑडियो कॉल")
            val node = find(root) { n ->
                val d = (n.contentDescription?.toString() ?: "").lowercase()
                words.any { d.contains(it) }
            } ?: return false
            if (clickOrTap(node)) {
                waCallStage = 1
                waCallStageAt = now
            }
            return false
        }
        // stage 1: confirm the "Call ...?" dialog if WhatsApp shows one
        val btn = find(root) { n ->
            val t = (n.text?.toString() ?: "").lowercase().trim()
            t == "call" || t == "कॉल" || t == "कॉल करें" || t == "ok"
        }
        if (btn != null) {
            clickOrTap(btn)
            waCallUntil = 0L
            return true
        }
        if (now - waCallStageAt > 4000L) {
            waCallUntil = 0L
            return true
        }
        return false
    }

    private fun tryCamera(): Boolean {
        val now = System.currentTimeMillis()
        if (now < camAt) return false
        val root = rootInActiveWindow ?: return false
        val pkg = root.packageName?.toString() ?: ""
        if (!pkg.lowercase().contains("camera")) return false
        val node = find(root) { n ->
            val id = (n.viewIdResourceName ?: "").lowercase()
            val d = (n.contentDescription?.toString() ?: "").lowercase()
            id.contains("shutter") || id.contains("capture") || d.contains("shutter") || d.contains("take photo") || d.contains("take picture") || d.contains("capture")
        }
        var ok = false
        if (node != null) ok = clickOrTap(node)
        if (!ok) {
            val dm = resources.displayMetrics
            ok = tapAt(dm.widthPixels / 2f, dm.heightPixels * 0.9f)
        }
        if (ok) camUntil = 0L
        return ok
    }

    private fun tryInstall(): Boolean {
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() != "com.android.vending") return false
        val node = find(root) { n ->
            val t = (n.text?.toString() ?: "").lowercase().trim()
            t == "install" || t == "इंस्टॉल करें" || t == "इंस्टॉल"
        }
        if (node != null) {
            val ok = clickOrTap(node)
            if (ok) installUntil = 0L
            return ok
        }
        val opened = find(root) { n ->
            val t = (n.text?.toString() ?: "").lowercase().trim()
            t == "open" || t == "खोलें"
        }
        if (opened != null) {
            installUntil = 0L
            return true
        }
        return false
    }

    private fun tryPlay(): Boolean {
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() != "com.google.android.youtube") return false
        val node = find(root) {
            val d = it.contentDescription?.toString()?.lowercase() ?: ""
            d.contains("play video") || d.contains("वीडियो चलाएं") || d.contains("वीडियो चलाएँ")
        } ?: return false
        val ok = clickNode(node)
        if (ok) ytPlayUntil = 0L
        return ok
    }
}
