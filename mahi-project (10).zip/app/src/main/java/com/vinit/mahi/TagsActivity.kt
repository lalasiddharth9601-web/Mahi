package com.vinit.mahi

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** A small box where Siddharth types or pastes his YouTube tags separated by commas. Mahi then enters them one by one. */
class TagsActivity : Activity() {

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = applicationContext
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(18), dp(18), dp(14))

        val title = TextView(this)
        title.text = "YouTube tags"
        title.textSize = 20f
        col.addView(title)

        val hint = TextView(this)
        hint.text = "Type or paste your tags, separated by commas. Open the video in the YouTube app, tap Edit, then press OK here. Mahi will tap Add tags and type them."
        hint.textSize = 13f
        hint.setPadding(0, dp(6), 0, dp(8))
        col.addView(hint)

        val box = EditText(this)
        box.hint = "tag one, tag two, tag three"
        box.minLines = 4
        box.gravity = Gravity.TOP
        box.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        col.addView(box)

        val ok = Button(this)
        ok.text = "OK, add tags"
        ok.setOnClickListener {
            val tags = box.text.toString().split(",", "\n").map { it.trim() }.filter { it.isNotEmpty() }.distinct()
            if (tags.isEmpty()) {
                Toast.makeText(this, "Write at least one tag", Toast.LENGTH_SHORT).show()
            } else {
                val acc = MahiAccess.inst
                if (acc == null) {
                    Toast.makeText(this, "Turn on Mahi in Accessibility first", Toast.LENGTH_LONG).show()
                } else {
                    val main = Handler(Looper.getMainLooper())
                    acc.enterTags(tags) { msg -> main.post { Toast.makeText(app, msg, Toast.LENGTH_LONG).show() } }
                    finish()
                }
            }
        }
        col.addView(ok)

        val cancel = Button(this)
        cancel.text = "Cancel"
        cancel.setOnClickListener { finish() }
        col.addView(cancel)

        setContentView(col)
    }
}
