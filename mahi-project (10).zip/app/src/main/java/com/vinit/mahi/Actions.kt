package com.vinit.mahi

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.app.SearchManager
import android.app.admin.DevicePolicyManager
import android.bluetooth.BluetoothAdapter
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telephony.SmsManager
import org.json.JSONObject

object Actions {

    private fun nt(i: Intent): Intent {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return i
    }

    private fun granted(c: Context, p: String): Boolean =
        c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    fun contactNames(c: Context): List<String> = Contacts.names(c, 500)

    private class Resolved(val number: String?, val error: String?, val name: String = "")

    /** Finds the number; if the match is doubtful, asks for confirmation instead of guessing. */
    private fun resolve(c: Context, who: String, a: JSONObject): Resolved {
        val w = who.trim()
        if (w.isEmpty()) return Resolved(null, "kisko? naam batao")
        if (w.none { it.isLetter() } && w.count { it.isDigit() } >= 5) {
            return Resolved(w.filter { it.isDigit() || it == '+' }, null, w)
        }
        val m = Contacts.find(c, w) ?: return Resolved(null, "I could not find " + w + " in contacts")
        val confirmed = a.s("confirmed").lowercase() == "true"
        if (!confirmed && (Store.confirmContacts || m.score < 0.9 || m.alt.isNotEmpty())) {
            val opts = if (m.alt.isNotEmpty()) m.name + " ya " + m.alt else m.name
            val txt = a.s("text").ifEmpty { a.s("message") }
            val extra = if (txt.isNotEmpty()) " Message: " + txt + "." else ""
            return Resolved(null, "CONFIRM: Siddharth ne '" + w + "' bola, contact mila: " + opts + "." + extra + " Abhi kuch mat karo. Siddharth se naam bolkar poochho ki sahi hai (jaise: '" + m.name + " ko call karun?'). Jab woh haan bole tabhi wahi function confirmed=true ke saath dobara chalao.")
        }
        return Resolved(m.number, null, m.name)
    }

    fun findNumber(c: Context, who: String): String? {
        val w = who.trim()
        if (w.isEmpty()) return null
        if (w.none { it.isLetter() } && w.count { it.isDigit() } >= 5) {
            return w.filter { it.isDigit() || it == '+' }
        }
        return Contacts.find(c, w)?.number
    }

    private fun on(a: JSONObject): Boolean {
        val v = a.s("on").lowercase()
        return !(v == "false" || v == "off" || v == "0" || v == "no")
    }

    private fun pct(a: JSONObject, key: String, def: Int): Int =
        (a.s(key).toDoubleOrNull() ?: def.toDouble()).toInt().coerceIn(0, 100)

    /** Runs a phone action. Returns an error text, or null when it worked. */
    fun run(c: Context, action: String, a: JSONObject): String? {
        try {
            return when (action) {
                "call" -> call(c, a)
                "sms" -> sms(c, a)
                "whatsapp" -> whatsapp(c, a)
                "whatsapp_call" -> waCall(c, a)
                "open_url" -> {
                    c.startActivity(nt(Intent(Intent.ACTION_VIEW, Uri.parse(a.s("url")))))
                    null
                }
                "speakerphone" -> {
                    CallScreen.speaker(c, on(a))
                    null
                }
                "install_app" -> installApp(c, a)
                "call_and_talk" -> callAndTalk(c, a)
                "take_photo" -> takePhoto(c, a)
                "tap" -> {
                    val acc = MahiAccess.inst ?: return "Accessibility on nahi hai"
                    if (acc.tapText(a.s("text"))) null else "screen par " + a.s("text") + " nahi mila"
                }
                "swipe" -> {
                    val acc = MahiAccess.inst ?: return "Accessibility on nahi hai"
                    if (acc.swipeDir(a.s("direction"))) null else "swipe nahi ho paya"
                }
                "tap_xy" -> {
                    val acc = MahiAccess.inst ?: return "Accessibility on nahi hai"
                    val x = a.s("x").toFloatOrNull() ?: 50f
                    val y = a.s("y").toFloatOrNull() ?: 50f
                    if (acc.tapPercent(x, y)) null else "tap nahi ho paya"
                }
                "long_press" -> {
                    val acc = MahiAccess.inst ?: return "Accessibility on nahi hai"
                    if (acc.longPressText(a.s("text"))) null else "screen par " + a.s("text") + " nahi mila"
                }
                "scroll" -> {
                    val acc = MahiAccess.inst ?: return "Accessibility on nahi hai"
                    acc.scrollScreen(a.s("direction"))
                    null
                }
                "type" -> {
                    val acc = MahiAccess.inst ?: return "Accessibility on nahi hai"
                    if (acc.typeText(a.s("text"))) null else "text likhne ki jagah nahi mili"
                }
                "youtube" -> youtube(c, a)
                "open_app" -> openApp(c, a)
                "brightness" -> brightness(c, a)
                "volume" -> volume(c, a)
                "wifi" -> {
                    val w = c.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                    w.isWifiEnabled = on(a)
                    null
                }
                "bluetooth" -> {
                    val b = BluetoothAdapter.getDefaultAdapter() ?: return "no bluetooth on this phone"
                    if (on(a)) b.enable() else b.disable()
                    null
                }
                "flashlight" -> flashlight(c, a)
                "alarm" -> alarm(c, a)
                "timer" -> {
                    val i = Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, (a.s("seconds").toDoubleOrNull() ?: 60.0).toInt())
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    c.startActivity(nt(i))
                    null
                }
                "navigate" -> navigate(c, a)
                "search" -> {
                    val i = Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, a.s("query"))
                    c.startActivity(nt(i))
                    null
                }
                "home" -> global(AccessibilityService.GLOBAL_ACTION_HOME)
                "back" -> global(AccessibilityService.GLOBAL_ACTION_BACK)
                "recents" -> global(AccessibilityService.GLOBAL_ACTION_RECENTS)
                "notifications" -> global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
                "lock" -> lock(c)
                "shield_on" -> {
                    Bus.emit("shield", "on")
                    null
                }
                else -> null
            }
        } catch (e: Throwable) {
            return "action failed: " + (e.message ?: e.javaClass.simpleName)
        }
    }

    private fun call(c: Context, a: JSONObject): String? {
        val who = a.s("to").ifBlank { a.s("name") }
        val rs = resolve(c, who, a)
        val num = rs.number ?: return (rs.error ?: "contact nahi mila")
        val uri = Uri.parse("tel:" + Uri.encode(num))
        val i = if (granted(c, Manifest.permission.CALL_PHONE)) Intent(Intent.ACTION_CALL, uri) else Intent(Intent.ACTION_DIAL, uri)
        c.startActivity(nt(i))
        return null
    }

    private fun sms(c: Context, a: JSONObject): String? {
        if (!granted(c, Manifest.permission.SEND_SMS)) return "SMS permission is off"
        val who = a.s("to")
        val rs = resolve(c, who, a)
        val num = rs.number ?: return (rs.error ?: "contact nahi mila")
        val sm = SmsManager.getDefault()
        sm.sendMultipartTextMessage(num, null, sm.divideMessage(a.s("text")), null, null)
        return null
    }

    private fun whatsapp(c: Context, a: JSONObject): String? {
        val who = a.s("to")
        val rs = resolve(c, who, a)
        val num = rs.number ?: return (rs.error ?: "contact nahi mila")
        var n = num.filter { it.isDigit() }
        if (n.length == 10) n = "91$n"
        if (n.length == 11 && n.startsWith("0")) n = "91" + n.substring(1)
        val url = "https://wa.me/$n?text=" + Uri.encode(a.s("text"))
        MahiAccess.waSendUntil = System.currentTimeMillis() + 30000
        var opened = false
        for (p in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            try {
                c.startActivity(nt(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(p)))
                opened = true
                break
            } catch (e: Exception) {
            }
        }
        if (!opened) c.startActivity(nt(Intent(Intent.ACTION_VIEW, Uri.parse(url))))
        val acc = MahiAccess.inst ?: return "Accessibility on nahi hai, isliye message likh diya hai par bhej nahi paungi"
        acc.arm()
        return null
    }

    private fun firstVideoId(query: String): String? {
        return try {
            val u = java.net.URL("https://www.youtube.com/results?search_query=" + Uri.encode(query) + "&sp=EgIQAQ%3D%3D")
            val con = u.openConnection() as java.net.HttpURLConnection
            con.connectTimeout = 6000
            con.readTimeout = 7000
            con.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36")
            con.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
            val txt = con.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            Regex("\"videoId\":\"([A-Za-z0-9_-]{11})\"").find(txt)?.groupValues?.get(1)
        } catch (e: Exception) {
            null
        }
    }

    private fun youtube(c: Context, a: JSONObject): String? {
        val q = a.s("query")
        val id = firstVideoId(q)
        if (id != null) {
            val watch = Uri.parse("https://www.youtube.com/watch?v=$id")
            try {
                c.startActivity(nt(Intent(Intent.ACTION_VIEW, watch).setPackage("com.google.android.youtube")))
            } catch (e: Exception) {
                c.startActivity(nt(Intent(Intent.ACTION_VIEW, watch)))
            }
            return null
        }
        val url = "https://www.youtube.com/results?search_query=" + Uri.encode(q)
        MahiAccess.ytPlayUntil = System.currentTimeMillis() + 25000
        try {
            c.startActivity(nt(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.google.android.youtube")))
        } catch (e: Exception) {
            c.startActivity(nt(Intent(Intent.ACTION_VIEW, Uri.parse(url))))
        }
        MahiAccess.inst?.arm()
        return null
    }

    /** Checks a call/message request (contact + confirmation) without doing anything yet. */
    fun check(c: Context, action: String, a: JSONObject): String? {
        if (action == "call" || action == "call_and_talk") {
            return resolve(c, a.s("to").ifBlank { a.s("name") }, a).error
        }
        return null
    }

    private fun callAndTalk(c: Context, a: JSONObject): String? {
        val who = a.s("to").ifBlank { a.s("name") }
        val rs = resolve(c, who, a)
        val num = rs.number ?: return (rs.error ?: "contact nahi mila")
        if (!granted(c, Manifest.permission.CALL_PHONE)) return "Phone call ki permission nahi hai"
        val goal = a.s("message").ifBlank { a.s("text") }
        CallScreen.pendingGoal = if (goal.isBlank()) "Siddharth ne bola hai ki aap unse baat kar lijiye" else goal
        CallScreen.pendingName = rs.name.ifBlank { who }
        CallScreen.pendingUntil = System.currentTimeMillis() + 90000L
        c.startActivity(nt(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num)))))
        return null
    }

    private fun installApp(c: Context, a: JSONObject): String? {
        val pkg = a.s("package").trim()
        val name = a.s("name").trim()
        val uri = if (pkg.isNotEmpty()) "market://details?id=" + Uri.encode(pkg) else "market://search?q=" + Uri.encode(name) + "&c=apps"
        MahiAccess.installUntil = System.currentTimeMillis() + 45000
        try {
            c.startActivity(nt(Intent(Intent.ACTION_VIEW, Uri.parse(uri)).setPackage("com.android.vending")))
        } catch (e: Exception) {
            c.startActivity(nt(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/search?q=" + Uri.encode(name) + "&c=apps"))))
        }
        val acc = MahiAccess.inst ?: return "Accessibility on nahi hai, Play Store khol diya hai par Install nahi daba paungi"
        acc.arm()
        return null
    }

    private fun takePhoto(c: Context, a: JSONObject): String? {
        val acc = MahiAccess.inst ?: return "Accessibility on nahi hai, photo nahi kheench paungi"
        val delay = ((a.s("delay_seconds").toDoubleOrNull() ?: 3.0) * 1000.0).toLong().coerceIn(0L, 20000L)
        val now = System.currentTimeMillis()
        MahiAccess.camAt = now + delay
        MahiAccess.camUntil = now + delay + 15000
        if (!acc.currentPackage().lowercase().contains("camera")) {
            try {
                c.startActivity(nt(Intent("android.media.action.STILL_IMAGE_CAMERA")))
            } catch (e: Exception) {
                return "camera nahi khul paya"
            }
        }
        acc.arm()
        return null
    }

    private fun waCall(c: Context, a: JSONObject): String? {
        val who = a.s("to")
        val rs = resolve(c, who, a)
        val num = rs.number ?: return (rs.error ?: "contact nahi mila")
        var n = num.filter { it.isDigit() }
        if (n.length == 10) n = "91$n"
        if (n.length == 11 && n.startsWith("0")) n = "91" + n.substring(1)
        val acc = MahiAccess.inst ?: return "Accessibility on nahi hai, WhatsApp call nahi kar paungi"
        MahiAccess.waCallVideo = a.s("video").lowercase() == "true"
        MahiAccess.waCallStage = 0
        MahiAccess.waCallUntil = System.currentTimeMillis() + 30000
        val url = "https://wa.me/$n"
        var opened = false
        for (p in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            try {
                c.startActivity(nt(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(p)))
                opened = true
                break
            } catch (e: Exception) {
            }
        }
        if (!opened) return "WhatsApp nahi khul paya"
        acc.arm()
        return null
    }

    private fun openApp(c: Context, a: JSONObject): String? {
        val q = a.s("name").lowercase().trim()
        if (q.isEmpty()) return "which app?"
        val pm = c.packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        var best: String? = null
        for (ri in list) {
            val label = ri.loadLabel(pm).toString().lowercase()
            if (label == q) {
                best = ri.activityInfo.packageName
                break
            }
            if (best == null && label.isNotEmpty() && (label.contains(q) || q.contains(label))) {
                best = ri.activityInfo.packageName
            }
        }
        val pkg = best ?: return "I could not find the app $q"
        val i = pm.getLaunchIntentForPackage(pkg) ?: return "I cannot open $q"
        c.startActivity(nt(i))
        return null
    }

    private fun brightness(c: Context, a: JSONObject): String? {
        if (!Settings.System.canWrite(c)) return "allow Modify system settings in Mahi setup"
        val p = pct(a, "percent", 50).coerceAtLeast(1)
        Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS, p * 255 / 100)
        return null
    }

    private fun volume(c: Context, a: JSONObject): String? {
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val p = pct(a, "percent", 50)
        am.setStreamVolume(
            AudioManager.STREAM_MUSIC,
            am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) * p / 100,
            AudioManager.FLAG_SHOW_UI
        )
        return null
    }

    private fun flashlight(c: Context, a: JSONObject): String? {
        val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        for (id in cm.cameraIdList) {
            val ch = cm.getCameraCharacteristics(id)
            if (ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true) {
                cm.setTorchMode(id, on(a))
                return null
            }
        }
        return "no flashlight found"
    }

    private fun alarm(c: Context, a: JSONObject): String? {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, (a.s("hour").toDoubleOrNull() ?: 7.0).toInt())
            .putExtra(AlarmClock.EXTRA_MINUTES, (a.s("minute").toDoubleOrNull() ?: 0.0).toInt())
            .putExtra(AlarmClock.EXTRA_MESSAGE, a.s("label").ifBlank { "Mahi alarm" })
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        c.startActivity(nt(i))
        return null
    }

    private fun navigate(c: Context, a: JSONObject): String? {
        val place = Uri.encode(a.s("place"))
        try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=$place")).setPackage("com.google.android.apps.maps")
            c.startActivity(nt(i))
        } catch (e: Exception) {
            c.startActivity(nt(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$place"))))
        }
        return null
    }

    private fun global(code: Int): String? {
        val s = MahiAccess.inst ?: return "turn on Mahi in Accessibility settings first"
        s.performGlobalAction(code)
        return null
    }

    private fun lock(c: Context): String? {
        val dpm = c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        if (!dpm.isAdminActive(ComponentName(c, AdminReceiver::class.java))) return "turn on Device admin in Mahi setup to lock the phone"
        dpm.lockNow()
        return null
    }
}
