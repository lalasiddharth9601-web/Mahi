package com.vinit.mahi

import android.app.AlarmManager
import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.BroadcastReceiver
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Vibrator
import org.json.JSONObject
import android.Manifest
import android.content.pm.PackageManager
import android.telephony.SmsManager
import android.content.Intent
import android.content.IntentFilter
import android.telephony.TelephonyManager
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.concurrent.Executors

/**
 * Always-on foreground service.
 * phase 0 = waiting for "Hello Mahi", 1 = listening for a command, 2 = busy (thinking / talking)
 */
class WakeService : Service() {

    companion object {
        const val ACT_LISTEN = "com.vinit.mahi.LISTEN"
        const val ACT_APPLY = "com.vinit.mahi.APPLY"
        const val ACT_ANSWER = "com.vinit.mahi.ANSWER"
        const val ACT_REPORT = "com.vinit.mahi.REPORT"
        const val CH = "mahi_listen"

        @Volatile
        var running = false
    }

    private val h = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null
    private var phase = 0
    private var gen = 0
    private var wl: PowerManager.WakeLock? = null
    private val worker = Executors.newSingleThreadExecutor()
    private val mutedStreams = ArrayList<Int>()
    private val nameRe = Regex("(mahi|maahi|mahee|maahee|mahe|mehi|माही|माहि|महि|मही|माई|माहे|माहीं)", RegexOption.IGNORE_CASE)

    private val restartRun = Runnable { if (phase == 0 && Store.handsFree) listen(false) }
    private val unmuteRun = Runnable { unmute() }
    private val watchdogRun = Runnable { if (phase == 2) endToWake() }

    @Volatile
    private var lastSpoken = ""

    @Volatile
    private var okExchange = false

    @Volatile
    private var actionErr: String? = null

    @Volatile
    private var screening = false

    @Volatile
    private var forceLocal = false
    private var ringHandled = false
    private var lastRingNumber = ""
    private var noteId = 100

    private val phoneRx = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val st = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
            val num = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: ""
            if (st == TelephonyManager.EXTRA_STATE_RINGING) {
                if (num.isNotEmpty()) lastRingNumber = num
                onRinging()
            } else if (st == TelephonyManager.EXTRA_STATE_OFFHOOK) {
                onOffhook()
            } else if (st == TelephonyManager.EXTRA_STATE_IDLE) {
                onCallIdle()
            }
        }
    }

    private val hw = Handler(Looper.getMainLooper())
    private val accRun = object : Runnable {
        override fun run() {
            try {
                checkAccessibility()
            } catch (e: Throwable) {
            }
            hw.postDelayed(this, 300000)
        }
    }

    private fun accessibilityOn(): Boolean {
        val list = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return list.contains(packageName) && list.contains("MahiAccess")
    }

    private fun checkAccessibility() {
        if (!Store.accSeen) return
        if (accessibilityOn() && MahiAccess.inst != null) return
        // try to switch it back on ourselves (works only if the phone allowed it earlier)
        if (checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED) {
            try {
                val comp = packageName + "/" + MahiAccess::class.java.name
                val cur = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
                if (!cur.contains(comp)) {
                    Settings.Secure.putString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, if (cur.isEmpty()) comp else cur + ":" + comp)
                }
                Settings.Secure.putInt(contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
                return
            } catch (e: Exception) {
            }
        }
        val now = System.currentTimeMillis()
        if (now - Store.lastAccNote < 20L * 60L * 1000L) return
        Store.lastAccNote = now
        val pi = PendingIntent.getActivity(this, 2, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS), 0)
        val n = Notification.Builder(this, "mahi_notes")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("Mahi's Accessibility switched off")
            .setContentText("Tap here and switch Mahi on again (needed for WhatsApp, camera, Play Store).")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(77, n)
    }

    // ---------------------------------------------------------------- shake to wake
    private var shakeOn = false
    private var lastTrigger = 0L

    // Side-to-side shake only: 5 quick left-right swings. Walking or running moves the phone up and down, so it does not count.
    private var gx = 0f
    private var gy = 0f
    private var gz = 0f
    private var peaks = 0
    private var lastSign = 0
    private var firstPeakMs = 0L
    private var lastPeakMs = 0L

    private val shakeL = object : SensorEventListener {
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

        override fun onSensorChanged(e: SensorEvent?) {
            if (e == null) return
            val x = e.values[0]
            val y = e.values[1]
            val z = e.values[2]
            // remove gravity
            gx = 0.9f * gx + 0.1f * x
            gy = 0.9f * gy + 0.1f * y
            gz = 0.9f * gz + 0.1f * z
            val lx = x - gx
            val ly = y - gy
            val lz = z - gz
            val ms = e.timestamp / 1000000L
            if (peaks > 0 && ms - lastPeakMs > 700L) {
                peaks = 0
                lastSign = 0
            }
            val ax = Math.abs(lx)
            if (ax > 11f && ax > 1.6f * Math.max(Math.abs(ly), Math.abs(lz))) {
                val sign = if (lx > 0f) 1 else -1
                if (sign != lastSign && ms - lastPeakMs > 90L) {
                    peaks++
                    lastSign = sign
                    lastPeakMs = ms
                    if (peaks == 1) firstPeakMs = ms
                    if (ms - firstPeakMs > 3000L) {
                        peaks = 1
                        firstPeakMs = ms
                    }
                    if (peaks >= 5) {
                        peaks = 0
                        lastSign = 0
                        h.post { onShake() }
                    }
                }
            }
        }
    }

    private val screenRx = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            h.post { applyShake() }
        }
    }

    private fun onShake() {
        val now = System.currentTimeMillis()
        if (LiveAgent.active || phase == 2 || now - lastTrigger < 3000L) return
        lastTrigger = now
        try {
            (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).vibrate(70L)
        } catch (e: Exception) {
        }
        startConversation("", wakeNeedsScreen())
    }

    /** Mode 1 listens for shakes only while the screen is on (almost no battery); mode 2 also with the screen off. */
    private fun applyShake() {
        val mode = Store.shakeMode
        val screenOn = try {
            (getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive
        } catch (e: Exception) {
            true
        }
        val want = mode == 2 || (mode == 1 && screenOn)
        val m = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        if (shakeOn) {
            try {
                m.unregisterListener(shakeL)
            } catch (e: Exception) {
            }
            shakeOn = false
        }
        if (want) {
            try {
                val wakeUp = (mode == 2 && !screenOn)
                val s = m.getDefaultSensor(Sensor.TYPE_ACCELEROMETER, wakeUp) ?: m.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
                if (s != null) {
                    if (wakeUp) m.registerListener(shakeL, s, 100000, 1500000) else m.registerListener(shakeL, s, 50000)
                    shakeOn = true
                }
            } catch (e: Exception) {
            }
        }
    }

    private var bubble: View? = null
    private var neon: NeonView? = null
    private var cap: TextView? = null
    private val capHide = Runnable { cap?.visibility = View.GONE }
    private var uiVisible = false
    private var wm: WindowManager? = null

    override fun onBind(intent: Intent?): IBinder? = null

    /** If Mahi is swiped away from recent apps, start again by herself. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        try {
            val pi = PendingIntent.getForegroundService(this, 5, Intent(this, WakeService::class.java), PendingIntent.FLAG_ONE_SHOT)
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.set(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + 1500L, pi)
        } catch (e: Exception) {
        }
        super.onTaskRemoved(rootIntent)
    }

    override fun onCreate() {
        super.onCreate()
        running = true
        Store.init(this)
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "Mahi", NotificationManager.IMPORTANCE_LOW))
        val tap = Intent(this, WakeService::class.java).setAction(ACT_LISTEN).putExtra("launch", true)
        val pi = PendingIntent.getForegroundService(this, 1, tap, 0)
        val n = Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Mahi is ready")
            .setContentText("Tap here, or tap the round Mahi bubble, to talk")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        startForeground(1, n)
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "mahi:wake")
            wl?.setReferenceCounted(false)
        } catch (e: Exception) {
        }
        Speaker.init(this)
        try {
            val am0 = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            for (st in intArrayOf(AudioManager.STREAM_MUSIC, AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_SYSTEM)) {
                try {
                    am0.adjustStreamVolume(st, AudioManager.ADJUST_UNMUTE, 0)
                } catch (e: Exception) {
                }
            }
        } catch (e: Exception) {
        }
        showBubble()
        nm.createNotificationChannel(NotificationChannel("mahi_notes", "Mahi call notes", NotificationManager.IMPORTANCE_DEFAULT))
        hw.postDelayed(accRun, 20000)
        try {
            val f = IntentFilter()
            f.addAction(Intent.ACTION_SCREEN_ON)
            f.addAction(Intent.ACTION_SCREEN_OFF)
            registerReceiver(screenRx, f)
        } catch (e: Exception) {
        }
        applyShake()
        try {
            registerReceiver(phoneRx, IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED))
        } catch (e: Exception) {
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val act = intent?.action
        if (act == ACT_LISTEN) {
            h.post { startConversation("", wakeNeedsScreen()) }
        } else if (act == ACT_APPLY) {
            h.post {
                applyHandsFree()
                applyShake()
            }
        } else if (act == ACT_REPORT) {
            h.post { sendCallReport() }
        } else if (act == ACT_ANSWER) {
            val goal = intent?.getStringExtra("goal") ?: ""
            h.post {
                if (LiveAgent.active) LiveAgent.stop()
                h.postDelayed({ answerAndScreen(goal) }, 500)
            }
        } else {
            h.post {
                showBubble()
                applyHandsFree()
            }
        }
        return START_STICKY
    }

    /** Hands-free mode keeps the mic awake for "Hello Mahi". Otherwise the mic stays off until you tap. */
    private fun holdCpu(ms: Long) {
        try {
            wl?.acquire(ms)
        } catch (e: Exception) {
        }
    }

    private fun freeCpu() {
        try {
            if (wl?.isHeld == true && !Store.handsFree) wl?.release()
        } catch (e: Exception) {
        }
    }

    private fun applyHandsFree() {
        if (Store.handsFree) {
            try {
                wl?.acquire()
            } catch (e: Exception) {
            }
            if (phase == 0 && sr == null) listen(false)
        } else if (phase == 0) {
            try {
                if (wl?.isHeld == true) wl?.release()
            } catch (e: Exception) {
            }
            gen++
            killSr()
            h.removeCallbacks(restartRun)
        }
    }

    override fun onDestroy() {
        running = false
        gen++
        h.removeCallbacksAndMessages(null)
        killSr()
        unmute()
        try {
            wl?.release()
        } catch (e: Exception) {
        }
        hw.removeCallbacksAndMessages(null)
        try {
            (getSystemService(Context.SENSOR_SERVICE) as SensorManager).unregisterListener(shakeL)
            unregisterReceiver(screenRx)
        } catch (e: Exception) {
        }
        try {
            unregisterReceiver(phoneRx)
        } catch (e: Exception) {
        }
        hideBubble()
        LiveAgent.stop()
        worker.shutdownNow()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- listening

    private fun first(b: Bundle?): List<String> =
        b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: emptyList()

    private fun killSr() {
        try {
            sr?.cancel()
            sr?.destroy()
        } catch (e: Exception) {
        }
        sr = null
    }

    private fun listen(command: Boolean) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Bus.emit("say", "Speech service not found. Install or update the Google app.")
            return
        }
        killSr()
        val my = ++gen
        val rec = SpeechRecognizer.createSpeechRecognizer(this)
        rec.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                if (my != gen) return
                val pl = first(partialResults)
                if (pl.isNotEmpty()) Bus.emit("heard", pl[0])
                if (!command) checkWake(pl, false)
            }

            override fun onResults(results: Bundle?) {
                if (my != gen) return
                scheduleUnmute()
                val list = first(results)
                if (list.isNotEmpty()) Bus.emit("heard", "OK: " + list[0])
                if (!command) {
                    if (!checkWake(list, true)) restartWake(250)
                } else {
                    val tt = list.firstOrNull() ?: ""
                    if (tt.isBlank() || isEcho(tt)) endToWake() else submit(tt)
                }
            }

            override fun onError(error: Int) {
                if (my != gen) return
                scheduleUnmute()
                if (error != 7 && error != 6) Bus.emit("heard", "mic error " + error)
                if (!command) {
                    if (error == 9) {
                        Bus.emit("say", "Microphone permission is missing.")
                        return
                    }
                    restartWake(if (error == 8) 1500L else 350L)
                } else {
                    endToWake()
                }
            }
        })
        sr = rec
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        if (command) {
            // finish quickly after you stop talking
            i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 700L)
            i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 500L)
        }
        muteBeep()
        rec.startListening(i)
    }

    private fun restartWake(delay: Long) {
        h.removeCallbacks(restartRun)
        h.postDelayed(restartRun, delay)
    }

    private fun checkWake(cands: List<String>, final: Boolean): Boolean {
        for (t in cands) {
            val m = nameRe.find(t) ?: continue
            val rest = t.substring(m.range.last + 1).trim(' ', ',', '.', '!', '?', '।')
            if (rest.length > 2 && !final) return false   // wait for the whole sentence
            startConversation(rest, wakeNeedsScreen())
            return true
        }
        return false
    }

    /** True when Mahi must open her own screen (phone locked / screen off / no overlay permission). */
    private fun wakeNeedsScreen(): Boolean {
        return try {
            val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val ok = Settings.canDrawOverlays(this) && neon != null && pm.isInteractive && !km.isKeyguardLocked
            if (ok) false else true
        } catch (e: Exception) {
            true
        }
    }

    private fun onRinging() {
        if (ringHandled) return
        if (System.currentTimeMillis() < Store.screenUntil && !screening) {
            ringHandled = true
            if (Store.screenMode == "talk") {
                h.postDelayed({ answerAndScreen() }, 1500)
            } else {
                h.postDelayed({ rejectAndSms() }, 1300)
            }
        }
    }

    private fun onCallIdle() {
        ringHandled = false
        if (screening) {
            screening = false
            LiveAgent.stop()
            CallScreen.speaker(this, false)
        }
    }

    /** Reliable way: reject the call and send the caller a short SMS, then tell Siddharth. */
    private fun rejectAndSms() {
        val num = lastRingNumber
        val who = CallScreen.nameFor(this, num)
        CallScreen.endCall(this)
        val text = if (Store.screenText.isBlank()) "Namaste, Siddharth sir abhi busy hain. Jab free honge to aapko call kar lenge. - Mahi, unki assistant" else Store.screenText
        if (num.isNotBlank() && checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                val sm = SmsManager.getDefault()
                sm.sendMultipartTextMessage(num, null, sm.divideMessage(text), null, null)
            } catch (e: Exception) {
            }
        }
        Store.addNote(if (who.isBlank()) "unknown number" else who, "call aaya tha, maine SMS bhej diya ki aap busy hain")
        postLatestNote()
    }

    private fun answerAndScreen(goal: String = "") {
        if (!CallScreen.accept(this)) {
            Bus.emit("heard", "could not answer the call (permission?)")
            return
        }
        screening = true
        val who = CallScreen.nameFor(this, lastRingNumber)
        if (goal.isBlank()) {
            startCallSession("screen", who, 900L, "")
        } else {
            startCallSession("answer", who + "||" + goal, 900L, "The call is connected now. Speak first.")
        }
    }

    /** An outgoing call Mahi placed has connected: start talking to the other person. */
    private fun onOffhook() {
        if (screening) return
        val goal = CallScreen.pendingGoal
        if (goal.isEmpty() || System.currentTimeMillis() > CallScreen.pendingUntil) return
        val who = CallScreen.pendingName
        CallScreen.pendingGoal = ""
        screening = true
        if (LiveAgent.active) LiveAgent.stop()
        startCallSession("outbound", who + "||" + goal, 1300L)
    }

    private fun startCallSession(mode: String, extra: String, delayMs: Long, initial: String = "") {
        h.postDelayed({
            CallScreen.speaker(this, true)
            gen++
            killSr()
            h.removeCallbacksAndMessages(null)
            phase = 3
            holdCpu(6L * 60L * 1000L)
            LiveAgent.start(this, initial, mode, extra, {
                h.post {
                    phase = 0
                    freeCpu()
                    if (screening) {
                        screening = false
                        CallScreen.endCall(this)
                    }
                    CallScreen.speaker(this, false)
                    ringHandled = false
                    postLatestNote()
                    if (Store.handsFree) restartWake(800)
                }
            }, { why ->
                h.post {
                    phase = 0
                    Bus.emit("heard", "call assistant failed: " + why.take(100))
                    if (screening) {
                        screening = false
                        CallScreen.endCall(this)
                    }
                    CallScreen.speaker(this, false)
                }
            })
        }, delayMs)
    }

    /** After the call-handling time is over: send Siddharth a short summary of who called and what Mahi did. */
    private fun sendCallReport() {
        val to = Store.reportTo
        if (to.isBlank()) return
        Store.reportTo = ""
        val notes = Store.unreadNotes()
        val body = if (notes.isEmpty()) "Mahi report: is dauraan koi call nahi aaya." else "Mahi report:\n" + notes.joinToString("\n")
        worker.execute {
            try {
                val args = JSONObject().put("to", to).put("text", body).put("confirmed", "true")
                Actions.run(this, if (Store.reportVia == "whatsapp") "whatsapp" else "sms", args)
            } catch (e: Throwable) {
            }
        }
    }

    private fun postLatestNote() {
        try {
            val notes = Store.unreadNotes()
            if (notes.isEmpty()) return
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val n = Notification.Builder(this, "mahi_notes")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Mahi took a call message")
                .setContentText(notes[notes.size - 1])
                .setStyle(Notification.BigTextStyle().bigText(notes.joinToString("\n")))
                .setAutoCancel(true)
                .build()
            noteId++
            nm.notify(noteId, n)
        } catch (e: Exception) {
        }
    }

    private fun startConversation(rest: String, launch: Boolean) {
        if (Store.liveMode && Store.apiKey.isNotEmpty()) startLive(rest, launch) else startFromWake(rest, launch)
    }

    /** Real-time voice conversation (Gemini Live). The mic is open only until the conversation ends. */
    private fun startLive(rest: String, launch: Boolean) {
        gen++
        killSr()
        h.removeCallbacksAndMessages(null)
        phase = 3
        holdCpu(10L * 60L * 1000L)
        if (launch) launchUi()
        Bus.emit("state", "think")
        LiveAgent.start(this, rest, "chat", "", {
            h.post {
                phase = 0
                freeCpu()
                if (LiveAgent.endedByError) {
                    Bus.emit("say", "Internet slow hai, thodi der baad phir bolo.")
                    worker.execute {
                        try {
                            Speaker.speakPhone(this, "इंटरनेट slow है, थोड़ी देर बाद फिर बोलना।")
                        } catch (e: Throwable) {
                        }
                    }
                }
                if (Store.handsFree) restartWake(600)
            }
        }, { why ->
            h.post {
                Bus.emit("heard", "live failed: " + why.take(120))
                phase = 0
                freeCpu()
                val net = why.contains("slow or no internet") || why.contains("Unable to resolve") || why.contains("timeout", ignoreCase = true)
                forceLocal = net
                if (net) Bus.emit("say", "Internet slow hai, simple commands main khud kar lungi.")
                startFromWake(rest, false)
            }
        })
    }

    private fun startFromWake(rest: String, launch: Boolean) {
        gen++
        killSr()
        h.removeCallbacksAndMessages(null)
        phase = 2
        if (launch) launchUi()
        Bus.emit("state", "listen")
        h.removeCallbacks(unmuteRun)
        unmute()
        if (rest.length > 2) {
            submit(rest)
        } else {
            worker.execute {
                try {
                    Greeter.greet(this, Store.mode) { t ->
                        Bus.emit("say", t)
                        Bus.emit("state", "speak")
                    }
                } catch (e: Throwable) {
                }
                h.post {
                    phase = 1
                    Bus.emit("state", "listen")
                    listen(true)
                }
            }
        }
    }

    private fun endToWake() {
        gen++
        killSr()
        phase = 0
        Bus.emit("state", "")
        val stamp = SystemClock.elapsedRealtime()
        h.postDelayed({
            if (phase == 0 && SystemClock.elapsedRealtime() - stamp >= 5000) Bus.emit("idle", "")
        }, 6000)
        if (Store.handsFree) restartWake(300)
    }

    // ---------------------------------------------------------------- thinking + talking

    private fun submit(text: String) {
        gen++
        killSr()
        phase = 2
        okExchange = false
        h.removeCallbacks(unmuteRun)
        unmute()
        h.removeCallbacks(watchdogRun)
        h.postDelayed(watchdogRun, 45000)
        Bus.emit("say", "🎤 " + text)
        Bus.emit("state", "think")
        worker.execute {
            try {
                converse(text)
            } catch (e: Throwable) {
                val m = e.message ?: e.javaClass.simpleName
                val busy = m.startsWith("HTTP 503") || m.startsWith("HTTP 429") || m.contains("high demand")
                val keyBad = m.startsWith("HTTP 400") || m.startsWith("HTTP 401") || m.startsWith("HTTP 403")
                val friendly = if (busy) "Gemini abhi busy hai, thodi der baad phir bolo."
                else if (keyBad) "API key mein dikkat hai, setup mein key dobara save karo."
                else "Internet mein dikkat lag rahi hai."
                val friendlyHi = if (busy) "Gemini अभी busy है, थोड़ी देर बाद फिर बोलो।"
                else if (keyBad) "API key में दिक्कत है, setup में key दोबारा save करो।"
                else "इंटरनेट में दिक्कत लग रही है।"
                Bus.emit("say", friendly)
                Bus.emit("state", "speak")
                try {
                    Speaker.speakPhone(this, friendlyHi)
                } catch (e2: Throwable) {
                }
            }
            h.post { afterTalk() }
        }
    }

    private fun converse(text: String) {
        val low = text.lowercase()
        if (low.contains("2507") || low.contains("पच्चीस जीरो सात") || low.contains("twenty five zero seven")) {
            Bus.emit("shield", "off")
            okExchange = true
            talk("Pehchaan liya Sid! Phone unlock ho gaya, bolo kya karna hai?", "पहचान लिया Sid! फोन अनलॉक हो गया, बोलो क्या करना है?")
            return
        }
        val local = if (forceLocal) LocalCmd.parse(text) else null
        forceLocal = false
        val r = if (local != null) {
            Brain.Result(local.say, local.spoken, local.action, local.args, "", "")
        } else try {
            Brain.think(this, text)
        } catch (e: Throwable) {
            val lc = LocalCmd.parse(text) ?: throw e
            Brain.Result(lc.say, lc.spoken, lc.action, lc.args, "", "")
        }
        okExchange = true
        if (r.action == "call" || r.action == "sms" || r.action == "whatsapp" || r.action == "whatsapp_call") r.args.put("confirmed", "true")
        if (r.mode == "sid" || r.mode == "family") {
            Store.mode = r.mode
            Bus.emit("mode", r.mode)
        }
        if (r.remember.isNotBlank()) Store.addFact(r.remember)
        Store.addMsg("user", text)
        Store.addMsg("model", r.reply)

        val hasAction = r.action != "none"
        val late = r.action == "call" || r.action == "lock" || r.action == "shield_on"
        actionErr = null
        // Lip-sync and subtitle start only when the voice really starts.
        talk(r.reply, r.say) {
            if (hasAction && !late) {
                Thread { actionErr = Actions.run(this, r.action, r.args) }.start()
            }
        }
        if (hasAction && late) actionErr = Actions.run(this, r.action, r.args)
        val err = actionErr
        if (err != null) {
            Bus.emit("say", err)
            Speaker.speakPhone(this, "Sid, ये नहीं हो पाया।")
        }
    }

    private fun talk(display: String, spoken: String, onAudioStart: () -> Unit = {}) {
        lastSpoken = (display + " " + spoken).lowercase()
        Speaker.speak(this, display, spoken) {
            Bus.emit("say", display)
            Bus.emit("state", "speak")
            onAudioStart()
        }
    }

    /** After a reply, stay in listening mode for a follow-up (no need to say "Hello Mahi" again). */
    private fun afterTalk() {
        h.removeCallbacks(watchdogRun)
        if (!okExchange) {
            endToWake()
            return
        }
        phase = 2
        h.postDelayed({
            phase = 1
            Bus.emit("state", "listen")
            listen(true)
        }, 700)
    }

    private fun isEcho(t: String): Boolean {
        val w = t.lowercase().split(" ").filter { it.length > 2 }
        if (w.size < 3 || lastSpoken.isEmpty()) return false
        val hit = w.count { lastSpoken.contains(it) }
        return hit * 2 >= w.size
    }

    // ---------------------------------------------------------------- floating bubble

    private fun showBubble() {
        if (bubble != null) return
        if (!Settings.canDrawOverlays(this)) return
        try {
            val w = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            wm = w
            val d = resources.displayMetrics.density
            val size = (56 * d).toInt()
            val pad = (3 * d).toInt()

            val img = ImageView(this)
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            try {
                assets.open("mahi_face.jpg").use { img.setImageBitmap(BitmapFactory.decodeStream(it)) }
            } catch (e: Exception) {
                img.setBackgroundColor(Color.parseColor("#0f8f86"))
            }
            img.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setOval(0, 0, view.width, view.height)
                }
            }
            img.clipToOutline = true

            val bg = GradientDrawable()
            bg.shape = GradientDrawable.OVAL
            bg.setColor(Color.WHITE)
            bg.setStroke(pad, Color.parseColor("#14b8a6"))
            val ring = FrameLayout(this)
            ring.setPadding(pad, pad, pad, pad)
            ring.background = bg
            ring.elevation = 8 * d
            ring.addView(img, FrameLayout.LayoutParams(size, size))

            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            val screenW = resources.displayMetrics.widthPixels
            val screenH = resources.displayMetrics.heightPixels
            val full = size + 2 * pad
            lp.x = screenW - full
            lp.y = (screenH * 0.4f).toInt()

            val down = IntArray(4)   // touchX, touchY, startX, startY
            var dragging = false
            ring.setOnTouchListener { _, ev ->
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> {
                        down[0] = ev.rawX.toInt()
                        down[1] = ev.rawY.toInt()
                        down[2] = lp.x
                        down[3] = lp.y
                        dragging = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = ev.rawX.toInt() - down[0]
                        val dy = ev.rawY.toInt() - down[1]
                        if (Math.abs(dx) > 12 || Math.abs(dy) > 12) dragging = true
                        if (dragging) {
                            lp.x = down[2] + dx
                            lp.y = down[3] + dy
                            try {
                                w.updateViewLayout(ring, lp)
                            } catch (e: Exception) {
                            }
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (dragging) {
                            lp.x = if (lp.x + full / 2 < screenW / 2) 0 else screenW - full
                            try {
                                w.updateViewLayout(ring, lp)
                            } catch (e: Exception) {
                            }
                        } else {
                            if (LiveAgent.active) LiveAgent.stop() else if (phase != 2) startConversation("", wakeNeedsScreen())
                        }
                    }
                }
                true
            }

            Bus.bubble = { t, v ->
                h.post {
                    if (t == "say") {
                        val cv = cap
                        if (cv != null) {
                            h.removeCallbacks(capHide)
                            cv.text = v
                            cv.visibility = if (uiVisible) View.GONE else View.VISIBLE
                        }
                    } else if (t == "state") {
                        h.removeCallbacks(capHide)
                        if (v.isEmpty()) h.postDelayed(capHide, 2500)
                        val nv = neon
                        if (nv != null) {
                            if (v.isNotEmpty() && !uiVisible) {
                                nv.visibility = View.VISIBLE
                                nv.start()
                            } else {
                                nv.stop()
                                nv.visibility = View.GONE
                            }
                        }
                        val col = when (v) {
                            "listen", "think" -> "#00f6ff"
                            "speak" -> "#ff2bd6"
                            else -> "#14b8a6"
                        }
                        bg.setStroke(pad, Color.parseColor(col))
                    } else if (t == "visible") {
                        uiVisible = (v == "1")
                        ring.visibility = if (v == "1") View.GONE else View.VISIBLE
                        if (v == "1") {
                            neon?.stop()
                            neon?.visibility = View.GONE
                            cap?.visibility = View.GONE
                        }
                    }
                }
            }
            try {
                val nv = NeonView(this)
                nv.visibility = View.GONE
                val nlp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
                )
                w.addView(nv, nlp)
                neon = nv
            } catch (e: Exception) {
                neon = null
            }
            try {
                val tv = TextView(this)
                tv.setTextColor(Color.WHITE)
                tv.textSize = 15f
                tv.gravity = Gravity.CENTER
                tv.setPadding((16 * d).toInt(), (10 * d).toInt(), (16 * d).toInt(), (10 * d).toInt())
                tv.maxWidth = (screenW * 0.86f).toInt()
                val tbg = GradientDrawable()
                tbg.cornerRadius = 22 * d
                tbg.setColor(Color.parseColor("#CC101A2B"))
                tv.background = tbg
                tv.visibility = View.GONE
                val clp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT
                )
                clp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                clp.y = (120 * d).toInt()
                w.addView(tv, clp)
                cap = tv
            } catch (e: Exception) {
                cap = null
            }
            w.addView(ring, lp)
            bubble = ring
        } catch (e: Exception) {
            bubble = null
        }
    }

    private fun hideBubble() {
        Bus.bubble = null
        try {
            val b = bubble
            if (b != null) wm?.removeView(b)
        } catch (e: Exception) {
        }
        try {
            val nv = neon
            if (nv != null) {
                nv.stop()
                wm?.removeView(nv)
            }
        } catch (e: Exception) {
        }
        try {
            val cv = cap
            if (cv != null) wm?.removeView(cv)
        } catch (e: Exception) {
        }
        cap = null
        neon = null
        bubble = null
    }

    // ---------------------------------------------------------------- helpers

    private fun launchUi() {
        try {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                    .putExtra("wake", true)
            )
        } catch (e: Exception) {
        }
    }

    private fun beep() {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
            tg.startTone(ToneGenerator.TONE_PROP_ACK, 150)
            h.postDelayed({ tg.release() }, 500)
        } catch (e: Exception) {
        }
    }

    private fun scheduleUnmute() {
        h.removeCallbacks(unmuteRun)
        h.postDelayed(unmuteRun, 600)
    }

    /** Disabled: muting streams could leave the phone silent on some Vivo phones. */
    private fun muteBeep() {
    }

    private fun unmute() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            for (s in mutedStreams) {
                try {
                    am.adjustStreamVolume(s, AudioManager.ADJUST_UNMUTE, 0)
                } catch (e2: Exception) {
                }
            }
        } catch (e: Exception) {
        }
        mutedStreams.clear()
    }
}
