package com.vinit.mahi

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Brain {

    class Result(
        val reply: String,
        val say: String,
        val action: String,
        val args: JSONObject,
        val remember: String,
        val mode: String
    )

    private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models/"
    private const val VOICE = "Leda"

    // Google renames models often, so Mahi tries these in order and remembers the one that works.
    private val textModels = listOf("gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-flash-latest")

    // (model, voice format). Format 0 = prebuiltVoiceConfig, 1 = voiceConfig.voice
    private val ttsCfgs = listOf(
        Pair("gemini-3.1-flash-tts-preview", 0),
        Pair("gemini-3.8-flash-tts", 1),
        Pair("gemini-3.8-flash-tts", 0),
        Pair("gemini-2.5-flash-preview-tts", 0)
    )

    private fun post(url: String, body: JSONObject, readMs: Int = 45000): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = readMs
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", Store.apiKey)
        c.doOutput = true
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val txt = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        c.disconnect()
        if (code !in 200..299) throw RuntimeException("HTTP $code: " + txt.take(300))
        return txt
    }

    private fun msg(role: String, text: String): JSONObject {
        return JSONObject()
            .put("role", role)
            .put("parts", JSONArray().put(JSONObject().put("text", text)))
    }

    private fun systemPrompt(c: Context): String {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, hh:mm a", Locale.ENGLISH).format(Date())
        val facts = Store.facts()
        val names = Actions.contactNames(c)
        val sb = StringBuilder()
        sb.append("You are Mahi, Vinit's personal AI companion and voice assistant living inside his Android phone. ")
        sb.append("The user is Vinit. You call him \"Sid\" (and sometimes \"jaanu\" in sid mode).\n")
        sb.append("LANGUAGE: Always speak natural Hinglish (Hindi and English mixed, like \"Haan Sid, kya haal hai?\"). ")
        sb.append("Never reply in stiff formal English. Keep replies short, 1 or 2 sentences, because they are spoken aloud.\n")
        sb.append("MODES: \"sid\" mode = warm, cute, playful and a little flirty like a caring half-girlfriend, always tasteful. ")
        sb.append("\"family\" mode = very polite, respectful and sweet, say \"ji\" to elders, no flirting at all. ")
        sb.append("If Vinit says Mummy, Papa, Bhaiya or family wants to talk, set mode to family. If he says it is him again, set mode to sid. ")
        sb.append("Current mode: ").append(Store.mode).append(".\n")
        sb.append("Current date and time: ").append(now).append(".\n")
        sb.append("OUTPUT: reply with ONLY one JSON object, nothing else:\n")
        sb.append("{\"reply\":\"Hinglish in Roman letters, shown on screen\",")
        sb.append("\"say\":\"the same sentence for the voice: Hindi words in Devanagari, English words in Latin letters\",")
        sb.append("\"action\":\"none\",\"args\":{},\"remember\":\"\",\"mode\":\"\"}\n")
        sb.append("ACTIONS (use ONLY when Vinit clearly asks for it, otherwise \"none\"). Say what you are doing in the reply.\n")
        sb.append("call {to}, sms {to,text}, whatsapp {to,text}, youtube {query}, open_app {name}, brightness {percent}, volume {percent}, ")
        sb.append("wifi {on}, bluetooth {on}, flashlight {on}, alarm {hour,minute,label} (24 hour), timer {seconds}, navigate {place}, ")
        sb.append("search {query}, home, back, recents, notifications, lock (locks the phone screen), shield_on (Mahi security screen).\n")
        sb.append("For call, sms and whatsapp, args.to MUST be exactly one of the contact names listed below (pick the closest to what he said), or digits if he spoke a number. ")
        sb.append("For whatsapp and sms write args.text in the language and tone Vinit asked for.\n")
        sb.append("\"remember\": a short fact about Vinit worth remembering forever (people, likes, plans, promises), else empty. ")
        sb.append("\"mode\": \"sid\" or \"family\" only when switching, else empty.\n")
        if (facts.isNotEmpty()) {
            sb.append("THINGS YOU ALREADY KNOW ABOUT VINIT:\n")
            for (f in facts) sb.append("- ").append(f).append("\n")
        }
        if (names.isNotEmpty()) {
            sb.append("CONTACT NAMES: ").append(names.joinToString(" | ")).append("\n")
        }
        return sb.toString()
    }

    private fun body(sys: String, contents: JSONArray, thinkingOff: Boolean): JSONObject {
        val gc = JSONObject().put("responseMimeType", "application/json").put("temperature", 0.9)
        if (thinkingOff) gc.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
        return JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
            .put("contents", contents)
            .put("generationConfig", gc)
    }

    private fun parse(raw: String): Result {
        val root = JSONObject(raw)
        val parts = root.getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        var txt = ""
        for (i in 0 until parts.length()) txt += parts.getJSONObject(i).s("text")
        txt = txt.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        return try {
            val j = JSONObject(txt)
            val reply = j.s("reply").ifBlank { txt }
            val say = j.s("say").ifBlank { reply }
            val action = j.s("action").ifBlank { "none" }
            Result(reply, say, action, j.optJSONObject("args") ?: JSONObject(), j.s("remember"), j.s("mode"))
        } catch (e: Exception) {
            Result(txt, txt, "none", JSONObject(), "", "")
        }
    }

    fun think(c: Context, userText: String): Result {
        val sys = systemPrompt(c)
        val contents = JSONArray()
        for ((role, t) in Store.recent(16)) contents.put(msg(role, t))
        contents.put(msg("user", userText))

        val attempts = ArrayList<String>()
        if (Store.goodText.isNotEmpty()) attempts.add(Store.goodText)
        for (m in textModels) {
            for (th in listOf("1", "0")) {
                val k = "$m|$th"
                if (!attempts.contains(k)) attempts.add(k)
            }
        }
        var lastErr: Throwable? = null
        var fatal = false
        for (round in 0..1) {
            val skip = HashSet<String>()
            for (k in attempts) {
                val p = k.split("|")
                if (skip.contains(p[0])) continue
                try {
                    val raw = post(BASE + p[0] + ":generateContent", body(sys, contents, p[1] == "1"))
                    val res = parse(raw)
                    Store.goodText = k
                    return res
                } catch (e: Throwable) {
                    lastErr = e
                    val m = e.message ?: ""
                    if (m.startsWith("HTTP 401") || m.startsWith("HTTP 403")) {
                        fatal = true
                        break
                    }
                    if (!m.startsWith("HTTP 400")) skip.add(p[0])
                }
            }
            if (fatal) break
            if (round == 0) Thread.sleep(1200)
        }
        throw lastErr ?: RuntimeException("no model worked")
    }

    /** Natural voice from Gemini. Returns raw 16-bit 24 kHz mono PCM, or null. */
    fun ttsPcm(text: String): ByteArray? {
        val order = ArrayList<Int>()
        if (Store.goodTts >= 0 && Store.goodTts < ttsCfgs.size) order.add(Store.goodTts)
        for (i in ttsCfgs.indices) if (!order.contains(i)) order.add(i)
        var soft = 0
        for (i in order) {
            try {
                val model = ttsCfgs[i].first
                val fmt = ttsCfgs[i].second
                val voice = if (fmt == 1) JSONObject().put("voice", VOICE)
                else JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", VOICE))
                val part = JSONObject()
                if (model.contains("3.8")) {
                    part.put("text", text)
                    part.put("speech_metadata", JSONObject().put("style", "sweet, warm, natural young Indian woman, caring friend"))
                } else {
                    part.put("text", "Say in a sweet, warm, natural young Indian woman's voice, like a caring friend: $text")
                }
                val gc = JSONObject()
                    .put("responseModalities", JSONArray().put("AUDIO"))
                    .put("speechConfig", JSONObject().put("voiceConfig", voice))
                val b = JSONObject()
                    .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(part))))
                    .put("generationConfig", gc)
                val raw = post(BASE + model + ":generateContent", b, 15000)
                val parts = JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts")
                for (k in 0 until parts.length()) {
                    val p = parts.getJSONObject(k)
                    val inl = p.optJSONObject("inlineData") ?: p.optJSONObject("inline_data") ?: continue
                    val data = inl.s("data")
                    if (data.isNotEmpty()) {
                        Store.goodTts = i
                        return Base64.decode(data, Base64.DEFAULT)
                    }
                }
            } catch (e: Throwable) {
                val m = e.message ?: ""
                if (m.startsWith("HTTP 401") || m.startsWith("HTTP 403")) return null
                if (!(m.startsWith("HTTP 400") || m.startsWith("HTTP 404"))) {
                    soft++
                    if (soft >= 2) return null
                }
            }
        }
        return null
    }
}
