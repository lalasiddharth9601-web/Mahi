package com.vinit.mahi

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.concurrent.Executors

/**
 * Always-on foreground service.
 * phase 0 = waiting for "Hello Mahi", 1 = listening for a command, 2 = busy (thinking / talking)
 */
class WakeService : Service() {

    companion object {
        const val ACT_LISTEN = "com.vinit.mahi.LISTEN"
        const val CH = "mahi_listen"

        @Volatile
        var running = false
    }

    private val h = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null
    private var phase = 0
    private var gen = 0
    private var wl: PowerManager.WakeLock? = null
    private val worker = Executors.newSingleThreadExecutor()
    private val mutedStreams = ArrayList<Int>()
    private val nameRe = Regex("(mahi|maahi|mahee|maahee|mahe|mehi|माही|माहि|महि|मही|माई|माहे|माहीं)", RegexOption.IGNORE_CASE)

    private val restartRun = Runnable { if (phase == 0) listen(false) }
    private val unmuteRun = Runnable { unmute() }
    private val watchdogRun = Runnable { if (phase == 2) endToWake() }

    @Volatile
    private var lastSpoken = ""

    @Volatile
    private var okExchange = false

    private var bubble: View? = null
    private var neon: NeonView? = null
    private var cap: TextView? = null
    private val capHide = Runnable { cap?.visibility = View.GONE }
    private var uiVisible = false
    private var wm: WindowManager? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        Store.init(this)
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "Mahi", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), 0)
        val n = Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Mahi is listening")
            .setContentText("Say \"Hello Mahi\" anytime")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        startForeground(1, n)
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "mahi:wake")
            wl?.setReferenceCounted(false)
            wl?.acquire()
        } catch (e: Exception) {
        }
        Speaker.init(this)
        try {
            val am0 = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            for (st in intArrayOf(AudioManager.STREAM_MUSIC, AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_SYSTEM)) {
                try {
                    am0.adjustStreamVolume(st, AudioManager.ADJUST_UNMUTE, 0)
                } catch (e: Exception) {
                }
            }
        } catch (e: Exception) {
        }
        showBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        h.post { showBubble() }
        if (intent?.action == ACT_LISTEN) {
            h.post { startFromWake("", false) }
        } else {
            h.post { if (phase == 0 && sr == null) listen(false) }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        gen++
        h.removeCallbacksAndMessages(null)
        killSr()
        unmute()
        try {
            wl?.release()
        } catch (e: Exception) {
        }
        hideBubble()
        worker.shutdownNow()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- listening

    private fun first(b: Bundle?): List<String> =
        b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: emptyList()

    private fun killSr() {
        try {
            sr?.cancel()
            sr?.destroy()
        } catch (e: Exception) {
        }
        sr = null
    }

    private fun listen(command: Boolean) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Bus.emit("say", "Speech service not found. Install or update the Google app.")
            return
        }
        killSr()
        val my = ++gen
        val rec = SpeechRecognizer.createSpeechRecognizer(this)
        rec.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                if (my != gen) return
                val pl = first(partialResults)
                if (pl.isNotEmpty()) Bus.emit("heard", pl[0])
                if (!command) checkWake(pl, false)
            }

            override fun onResults(results: Bundle?) {
                if (my != gen) return
                scheduleUnmute()
                val list = first(results)
                if (list.isNotEmpty()) Bus.emit("heard", "OK: " + list[0])
                if (!command) {
                    if (!checkWake(list, true)) restartWake(250)
                } else {
                    val tt = list.firstOrNull() ?: ""
                    if (tt.isBlank() || isEcho(tt)) endToWake() else submit(tt)
                }
            }

            override fun onError(error: Int) {
                if (my != gen) return
                scheduleUnmute()
                if (error != 7 && error != 6) Bus.emit("heard", "mic error " + error)
                if (!command) {
                    if (error == 9) {
                        Bus.emit("say", "Microphone permission is missing.")
                        return
                    }
                    restartWake(if (error == 8) 1500L else 350L)
                } else {
                    endToWake()
                }
            }
        })
        sr = rec
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        if (command) {
            // finish quickly after you stop talking
            i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
            i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 800L)
        }
        muteBeep()
        rec.startListening(i)
    }

    private fun restartWake(delay: Long) {
        h.removeCallbacks(restartRun)
        h.postDelayed(restartRun, delay)
    }

    private fun checkWake(cands: List<String>, final: Boolean): Boolean {
        for (t in cands) {
            val m = nameRe.find(t) ?: continue
            val rest = t.substring(m.range.last + 1).trim(' ', ',', '.', '!', '?', '।')
            if (rest.length > 2 && !final) return false   // wait for the whole sentence
            startFromWake(rest, wakeNeedsScreen())
            return true
        }
        return false
    }

    /** True when Mahi must open her own screen (phone locked / screen off / no overlay permission). */
    private fun wakeNeedsScreen(): Boolean {
        return try {
            val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            !(Settings.canDrawOverlays(this) && neon != null && pm.isInteractive && !km.isKeyguardLocked)
        } catch (e: Exception) {
            true
        }
    }

    private fun startFromWake(rest: String, launch: Boolean) {
        gen++
        killSr()
        h.removeCallbacksAndMessages(null)
        phase = 2
        if (launch) launchUi()
        Bus.emit("state", "listen")
        h.removeCallbacks(unmuteRun)
        unmute()
        beep()
        if (rest.length > 2) {
            submit(rest)
        } else {
            h.postDelayed({
                phase = 1
                listen(true)
            }, 400)
        }
    }

    private fun endToWake() {
        gen++
        killSr()
        phase = 0
        Bus.emit("state", "")
        val stamp = SystemClock.elapsedRealtime()
        h.postDelayed({
            if (phase == 0 && SystemClock.elapsedRealtime() - stamp >= 5000) Bus.emit("idle", "")
        }, 6000)
        restartWake(300)
    }

    // ---------------------------------------------------------------- thinking + talking

    private fun submit(text: String) {
        gen++
        killSr()
        phase = 2
        okExchange = false
        h.removeCallbacks(unmuteRun)
        unmute()
        h.removeCallbacks(watchdogRun)
        h.postDelayed(watchdogRun, 45000)
        Bus.emit("state", "think")
        worker.execute {
            try {
                converse(text)
            } catch (e: Throwable) {
                val m = e.message ?: e.javaClass.simpleName
                val friendly = if (m.startsWith("HTTP 503") || m.startsWith("HTTP 429") || m.contains("high demand")) {
                    "Gemini abhi busy hai, thodi der baad phir bolo."
                } else if (m.startsWith("HTTP 400") || m.startsWith("HTTP 401") || m.startsWith("HTTP 403")) {
                    "API key mein dikkat hai, setup mein key dobara save karo."
                } else {
                    "Internet mein dikkat lag rahi hai."
                }
                Bus.emit("say", friendly)
                Bus.emit("state", "speak")
                try {
                    Speaker.speakPhone(this, friendly)
                } catch (e2: Throwable) {
                }
            }
            h.post { afterTalk() }
        }
    }

    private fun converse(text: String) {
        val low = text.lowercase()
        if (low.contains("2507") || low.contains("पच्चीस जीरो सात") || low.contains("twenty five zero seven")) {
            Bus.emit("shield", "off")
            okExchange = true
            talk("Pehchaan liya Sid! Phone unlock ho gaya, bolo kya karna hai?", "पहचान लिया Sid! फोन अनलॉक हो गया, बोलो क्या करना है?")
            return
        }
        val r = Brain.think(this, text)
        okExchange = true
        if (r.mode == "sid" || r.mode == "family") {
            Store.mode = r.mode
            Bus.emit("mode", r.mode)
        }
        if (r.remember.isNotBlank()) Store.addFact(r.remember)
        Store.addMsg("user", text)
        Store.addMsg("model", r.reply)
        talk(r.reply, r.say)
        if (r.action != "none") {
            val err = Actions.run(this, r.action, r.args)
            if (err != null) {
                Bus.emit("say", err)
                Speaker.speak(this, "Sid, ye nahi ho paya. $err")
            }
        }
    }

    private fun talk(display: String, spoken: String) {
        lastSpoken = (display + " " + spoken).lowercase()
        Bus.emit("say", display)
        Bus.emit("state", "speak")
        Speaker.speak(this, display, spoken)
    }

    /** After a reply, stay in listening mode for a follow-up (no need to say "Hello Mahi" again). */
    private fun afterTalk() {
        h.removeCallbacks(watchdogRun)
        if (!okExchange) {
            endToWake()
            return
        }
        phase = 2
        h.postDelayed({
            phase = 1
            Bus.emit("state", "listen")
            listen(true)
        }, 700)
    }

    private fun isEcho(t: String): Boolean {
        val w = t.lowercase().split(" ").filter { it.length > 2 }
        if (w.size < 3 || lastSpoken.isEmpty()) return false
        val hit = w.count { lastSpoken.contains(it) }
        return hit * 2 >= w.size
    }

    // ---------------------------------------------------------------- floating bubble

    private fun showBubble() {
        if (bubble != null) return
        if (!Settings.canDrawOverlays(this)) return
        try {
            val w = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            wm = w
            val d = resources.displayMetrics.density
            val size = (56 * d).toInt()
            val pad = (3 * d).toInt()

            val img = ImageView(this)
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            try {
                assets.open("mahi_face.jpg").use { img.setImageBitmap(BitmapFactory.decodeStream(it)) }
            } catch (e: Exception) {
                img.setBackgroundColor(Color.parseColor("#0f8f86"))
            }
            img.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setOval(0, 0, view.width, view.height)
                }
            }
            img.clipToOutline = true

            val bg = GradientDrawable()
            bg.shape = GradientDrawable.OVAL
            bg.setColor(Color.WHITE)
            bg.setStroke(pad, Color.parseColor("#14b8a6"))
            val ring = FrameLayout(this)
            ring.setPadding(pad, pad, pad, pad)
            ring.background = bg
            ring.elevation = 8 * d
            ring.addView(img, FrameLayout.LayoutParams(size, size))

            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            val screenW = resources.displayMetrics.widthPixels
            val screenH = resources.displayMetrics.heightPixels
            val full = size + 2 * pad
            lp.x = screenW - full
            lp.y = (screenH * 0.4f).toInt()

            val down = IntArray(4)   // touchX, touchY, startX, startY
            var dragging = false
            ring.setOnTouchListener { _, ev ->
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> {
                        down[0] = ev.rawX.toInt()
                        down[1] = ev.rawY.toInt()
                        down[2] = lp.x
                        down[3] = lp.y
                        dragging = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = ev.rawX.toInt() - down[0]
                        val dy = ev.rawY.toInt() - down[1]
                        if (Math.abs(dx) > 12 || Math.abs(dy) > 12) dragging = true
                        if (dragging) {
                            lp.x = down[2] + dx
                            lp.y = down[3] + dy
                            try {
                                w.updateViewLayout(ring, lp)
                            } catch (e: Exception) {
                            }
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (dragging) {
                            lp.x = if (lp.x + full / 2 < screenW / 2) 0 else screenW - full
                            try {
                                w.updateViewLayout(ring, lp)
                            } catch (e: Exception) {
                            }
                        } else {
                            if (phase != 2) startFromWake("", true)
                        }
                    }
                }
                true
            }

            Bus.bubble = { t, v ->
                h.post {
                    if (t == "say") {
                        val cv = cap
                        if (cv != null) {
                            h.removeCallbacks(capHide)
                            cv.text = v
                            cv.visibility = if (uiVisible) View.GONE else View.VISIBLE
                        }
                    } else if (t == "state") {
                        h.removeCallbacks(capHide)
                        if (v.isEmpty()) h.postDelayed(capHide, 2500)
                        val nv = neon
                        if (nv != null) {
                            if (v.isNotEmpty() && !uiVisible) {
                                nv.visibility = View.VISIBLE
                                nv.start()
                            } else {
                                nv.stop()
                                nv.visibility = View.GONE
                            }
                        }
                        val col = when (v) {
                            "listen", "think" -> "#00f6ff"
                            "speak" -> "#ff2bd6"
                            else -> "#14b8a6"
                        }
                        bg.setStroke(pad, Color.parseColor(col))
                    } else if (t == "visible") {
                        uiVisible = (v == "1")
                        ring.visibility = if (v == "1") View.GONE else View.VISIBLE
                        if (v == "1") {
                            neon?.stop()
                            neon?.visibility = View.GONE
                            cap?.visibility = View.GONE
                        }
                    }
                }
            }
            try {
                val nv = NeonView(this)
                nv.visibility = View.GONE
                val nlp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
                )
                w.addView(nv, nlp)
                neon = nv
            } catch (e: Exception) {
                neon = null
            }
            try {
                val tv = TextView(this)
                tv.setTextColor(Color.WHITE)
                tv.textSize = 15f
                tv.gravity = Gravity.CENTER
                tv.setPadding((16 * d).toInt(), (10 * d).toInt(), (16 * d).toInt(), (10 * d).toInt())
                tv.maxWidth = (screenW * 0.86f).toInt()
                val tbg = GradientDrawable()
                tbg.cornerRadius = 22 * d
                tbg.setColor(Color.parseColor("#CC101A2B"))
                tv.background = tbg
                tv.visibility = View.GONE
                val clp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT
                )
                clp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                clp.y = (120 * d).toInt()
                w.addView(tv, clp)
                cap = tv
            } catch (e: Exception) {
                cap = null
            }
            w.addView(ring, lp)
            bubble = ring
        } catch (e: Exception) {
            bubble = null
        }
    }

    private fun hideBubble() {
        Bus.bubble = null
        try {
            val b = bubble
            if (b != null) wm?.removeView(b)
        } catch (e: Exception) {
        }
        try {
            val nv = neon
            if (nv != null) {
                nv.stop()
                wm?.removeView(nv)
            }
        } catch (e: Exception) {
        }
        try {
            val cv = cap
            if (cv != null) wm?.removeView(cv)
        } catch (e: Exception) {
        }
        cap = null
        neon = null
        bubble = null
    }

    // ---------------------------------------------------------------- helpers

    private fun launchUi() {
        try {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                    .putExtra("wake", true)
            )
        } catch (e: Exception) {
        }
    }

    private fun beep() {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
            tg.startTone(ToneGenerator.TONE_PROP_ACK, 150)
            h.postDelayed({ tg.release() }, 500)
        } catch (e: Exception) {
        }
    }

    private fun scheduleUnmute() {
        h.removeCallbacks(unmuteRun)
        h.postDelayed(unmuteRun, 600)
    }

    /** Disabled: muting streams could leave the phone silent on some Vivo phones. */
    private fun muteBeep() {
    }

    private fun unmute() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            for (s in mutedStreams) {
                try {
                    am.adjustStreamVolume(s, AudioManager.ADJUST_UNMUTE, 0)
                } catch (e2: Exception) {
                }
            }
        } catch (e: Exception) {
        }
        mutedStreams.clear()
    }
}
