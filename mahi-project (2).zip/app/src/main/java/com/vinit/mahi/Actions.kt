package com.vinit.mahi

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.app.SearchManager
import android.app.admin.DevicePolicyManager
import android.bluetooth.BluetoothAdapter
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telephony.SmsManager
import org.json.JSONObject

object Actions {

    private fun nt(i: Intent): Intent {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return i
    }

    private fun granted(c: Context, p: String): Boolean =
        c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    fun contactNames(c: Context): List<String> {
        val out = LinkedHashSet<String>()
        if (!granted(c, Manifest.permission.READ_CONTACTS)) return emptyList()
        try {
            val cur = c.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME), null, null, null
            )
            if (cur != null) {
                cur.use {
                    while (it.moveToNext() && out.size < 400) {
                        val n = it.getString(0)
                        if (!n.isNullOrBlank()) out.add(n)
                    }
                }
            }
        } catch (e: Exception) {
        }
        return out.toList()
    }

    fun findNumber(c: Context, who: String): String? {
        val w = who.trim()
        if (w.isEmpty()) return null
        if (w.none { it.isLetter() } && w.count { it.isDigit() } >= 5) {
            return w.filter { it.isDigit() || it == '+' }
        }
        if (!granted(c, Manifest.permission.READ_CONTACTS)) return null
        var best: String? = null
        try {
            val cur = c.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ), null, null, null
            )
            if (cur != null) {
                cur.use {
                    while (it.moveToNext()) {
                        val n = it.getString(0) ?: continue
                        val num = it.getString(1) ?: continue
                        if (n.equals(w, ignoreCase = true)) {
                            best = num
                            break
                        }
                        if (best == null && (n.contains(w, ignoreCase = true) || w.contains(n, ignoreCase = true))) {
                            best = num
                        }
                    }
                }
            }
        } catch (e: Exception) {
        }
        return best
    }

    private fun on(a: JSONObject): Boolean {
        val v = a.s("on").lowercase()
        return !(v == "false" || v == "off" || v == "0" || v == "no")
    }

    private fun pct(a: JSONObject, key: String, def: Int): Int =
        (a.s(key).toDoubleOrNull() ?: def.toDouble()).toInt().coerceIn(0, 100)

    /** Runs a phone action. Returns an error text, or null when it worked. */
    fun run(c: Context, action: String, a: JSONObject): String? {
        try {
            return when (action) {
                "call" -> call(c, a)
                "sms" -> sms(c, a)
                "whatsapp" -> whatsapp(c, a)
                "youtube" -> youtube(c, a)
                "open_app" -> openApp(c, a)
                "brightness" -> brightness(c, a)
                "volume" -> volume(c, a)
                "wifi" -> {
                    val w = c.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                    w.isWifiEnabled = on(a)
                    null
                }
                "bluetooth" -> {
                    val b = BluetoothAdapter.getDefaultAdapter() ?: return "no bluetooth on this phone"
                    if (on(a)) b.enable() else b.disable()
                    null
                }
                "flashlight" -> flashlight(c, a)
                "alarm" -> alarm(c, a)
                "timer" -> {
                    val i = Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, (a.s("seconds").toDoubleOrNull() ?: 60.0).toInt())
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    c.startActivity(nt(i))
                    null
                }
                "navigate" -> navigate(c, a)
                "search" -> {
                    val i = Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, a.s("query"))
                    c.startActivity(nt(i))
                    null
                }
                "home" -> global(AccessibilityService.GLOBAL_ACTION_HOME)
                "back" -> global(AccessibilityService.GLOBAL_ACTION_BACK)
                "recents" -> global(AccessibilityService.GLOBAL_ACTION_RECENTS)
                "notifications" -> global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
                "lock" -> lock(c)
                "shield_on" -> {
                    Bus.emit("shield", "on")
                    null
                }
                else -> null
            }
        } catch (e: Throwable) {
            return "action failed: " + (e.message ?: e.javaClass.simpleName)
        }
    }

    private fun call(c: Context, a: JSONObject): String? {
        val who = a.s("to").ifBlank { a.s("name") }
        val num = findNumber(c, who) ?: return "I could not find $who in contacts"
        val uri = Uri.parse("tel:" + Uri.encode(num))
        val i = if (granted(c, Manifest.permission.CALL_PHONE)) Intent(Intent.ACTION_CALL, uri) else Intent(Intent.ACTION_DIAL, uri)
        c.startActivity(nt(i))
        return null
    }

    private fun sms(c: Context, a: JSONObject): String? {
        if (!granted(c, Manifest.permission.SEND_SMS)) return "SMS permission is off"
        val who = a.s("to")
        val num = findNumber(c, who) ?: return "I could not find $who in contacts"
        val sm = SmsManager.getDefault()
        sm.sendMultipartTextMessage(num, null, sm.divideMessage(a.s("text")), null, null)
        return null
    }

    private fun whatsapp(c: Context, a: JSONObject): String? {
        val who = a.s("to")
        val num = findNumber(c, who) ?: return "I could not find $who in contacts"
        var n = num.filter { it.isDigit() }
        if (n.length == 10) n = "91$n"
        if (n.length == 11 && n.startsWith("0")) n = "91" + n.substring(1)
        val url = "https://wa.me/$n?text=" + Uri.encode(a.s("text"))
        MahiAccess.waSendUntil = System.currentTimeMillis() + 25000
        for (p in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            try {
                c.startActivity(nt(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(p)))
                return null
            } catch (e: Exception) {
            }
        }
        c.startActivity(nt(Intent(Intent.ACTION_VIEW, Uri.parse(url))))
        return null
    }

    private fun youtube(c: Context, a: JSONObject): String? {
        val url = "https://www.youtube.com/results?search_query=" + Uri.encode(a.s("query"))
        MahiAccess.ytPlayUntil = System.currentTimeMillis() + 25000
        try {
            c.startActivity(nt(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.google.android.youtube")))
        } catch (e: Exception) {
            c.startActivity(nt(Intent(Intent.ACTION_VIEW, Uri.parse(url))))
        }
        return null
    }

    private fun openApp(c: Context, a: JSONObject): String? {
        val q = a.s("name").lowercase().trim()
        if (q.isEmpty()) return "which app?"
        val pm = c.packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        var best: String? = null
        for (ri in list) {
            val label = ri.loadLabel(pm).toString().lowercase()
            if (label == q) {
                best = ri.activityInfo.packageName
                break
            }
            if (best == null && label.isNotEmpty() && (label.contains(q) || q.contains(label))) {
                best = ri.activityInfo.packageName
            }
        }
        val pkg = best ?: return "I could not find the app $q"
        val i = pm.getLaunchIntentForPackage(pkg) ?: return "I cannot open $q"
        c.startActivity(nt(i))
        return null
    }

    private fun brightness(c: Context, a: JSONObject): String? {
        if (!Settings.System.canWrite(c)) return "allow Modify system settings in Mahi setup"
        val p = pct(a, "percent", 50).coerceAtLeast(1)
        Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS, p * 255 / 100)
        return null
    }

    private fun volume(c: Context, a: JSONObject): String? {
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val p = pct(a, "percent", 50)
        am.setStreamVolume(
            AudioManager.STREAM_MUSIC,
            am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) * p / 100,
            AudioManager.FLAG_SHOW_UI
        )
        return null
    }

    private fun flashlight(c: Context, a: JSONObject): String? {
        val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        for (id in cm.cameraIdList) {
            val ch = cm.getCameraCharacteristics(id)
            if (ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true) {
                cm.setTorchMode(id, on(a))
                return null
            }
        }
        return "no flashlight found"
    }

    private fun alarm(c: Context, a: JSONObject): String? {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, (a.s("hour").toDoubleOrNull() ?: 7.0).toInt())
            .putExtra(AlarmClock.EXTRA_MINUTES, (a.s("minute").toDoubleOrNull() ?: 0.0).toInt())
            .putExtra(AlarmClock.EXTRA_MESSAGE, a.s("label").ifBlank { "Mahi alarm" })
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        c.startActivity(nt(i))
        return null
    }

    private fun navigate(c: Context, a: JSONObject): String? {
        val place = Uri.encode(a.s("place"))
        try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=$place")).setPackage("com.google.android.apps.maps")
            c.startActivity(nt(i))
        } catch (e: Exception) {
            c.startActivity(nt(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$place"))))
        }
        return null
    }

    private fun global(code: Int): String? {
        val s = MahiAccess.inst ?: return "turn on Mahi in Accessibility settings first"
        s.performGlobalAction(code)
        return null
    }

    private fun lock(c: Context): String? {
        val dpm = c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        if (!dpm.isAdminActive(ComponentName(c, AdminReceiver::class.java))) return "turn on Device admin in Mahi setup to lock the phone"
        dpm.lockNow()
        return null
    }
}
