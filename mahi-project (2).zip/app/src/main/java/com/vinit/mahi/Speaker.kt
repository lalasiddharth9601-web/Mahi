package com.vinit.mahi

import android.content.Context
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

object Speaker {
    private var tts: TextToSpeech? = null

    @Volatile
    private var ready = false

    fun init(c: Context) {
        if (tts != null) return
        tts = TextToSpeech(c.applicationContext) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.setLanguage(Locale("en", "IN"))
                ready = true
            }
        }
    }

    /** Blocking. Natural Gemini voice first, phone voice as backup. */
    fun speak(c: Context, text: String, voiceText: String = text) {
        init(c)
        var ok = false
        if (Store.naturalVoice && Store.apiKey.isNotEmpty()) {
            ok = try {
                val pcm = Brain.ttsPcm(voiceText)
                if (pcm != null && pcm.size > 2000) {
                    play(pcm)
                    true
                } else false
            } catch (e: Throwable) {
                false
            }
        }
        if (!ok) phoneSpeak(text)
    }

    fun speakPhone(c: Context, text: String) {
        init(c)
        phoneSpeak(text)
    }

    private fun play(pcm: ByteArray) {
        val rate = 24000
        val track = AudioTrack(
            AudioManager.STREAM_MUSIC, rate, AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT, pcm.size, AudioTrack.MODE_STATIC
        )
        track.write(pcm, 0, pcm.size)
        track.play()
        val frames = pcm.size / 2
        var guard = 0
        while (track.playbackHeadPosition < frames && guard < 700) {
            Thread.sleep(50)
            guard++
        }
        try {
            track.stop()
        } catch (e: Exception) {
        }
        track.release()
    }

    private fun phoneSpeak(text: String) {
        var n = 0
        while (!ready && n < 30) {
            Thread.sleep(100)
            n++
        }
        val t = tts ?: return
        val latch = CountDownLatch(1)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                latch.countDown()
            }

            override fun onError(utteranceId: String?) {
                latch.countDown()
            }
        })
        t.setPitch(1.15f)
        t.setSpeechRate(0.95f)
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mahi1")
        latch.await(25, TimeUnit.SECONDS)
    }
}
