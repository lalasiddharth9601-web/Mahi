package com.vinit.mahi

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class MahiAccess : AccessibilityService() {

    companion object {
        @Volatile
        var inst: MahiAccess? = null

        @Volatile
        var waSendUntil = 0L

        @Volatile
        var ytPlayUntil = 0L
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        inst = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        inst = null
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val pkg = e?.packageName?.toString() ?: return
        val now = System.currentTimeMillis()
        try {
            if ((pkg == "com.whatsapp" || pkg == "com.whatsapp.w4b") && now < waSendUntil) {
                trySend()
            } else if (pkg == "com.google.android.youtube" && now < ytPlayUntil) {
                tryPlay()
            }
        } catch (ex: Exception) {
        }
    }

    private fun find(n: AccessibilityNodeInfo?, pred: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (n == null) return null
        if (pred(n)) return n
        for (i in 0 until n.childCount) {
            val r = find(n.getChild(i), pred)
            if (r != null) return r
        }
        return null
    }

    private fun clickNode(n0: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = n0
        var depth = 0
        while (n != null && depth < 6) {
            if (n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            n = n.parent
            depth++
        }
        return false
    }

    private fun trySend() {
        val root = rootInActiveWindow ?: return
        var found: AccessibilityNodeInfo? = null
        for (id in listOf("com.whatsapp:id/send", "com.whatsapp.w4b:id/send")) {
            val l = root.findAccessibilityNodeInfosByViewId(id)
            if (l != null && l.isNotEmpty()) {
                found = l[0]
                break
            }
        }
        if (found == null) {
            found = find(root) {
                val d = it.contentDescription?.toString()?.lowercase() ?: ""
                d == "send" || d == "भेजें"
            }
        }
        val node = found
        if (node != null && clickNode(node)) waSendUntil = 0L
    }

    private fun tryPlay() {
        val root = rootInActiveWindow ?: return
        val node = find(root) {
            val d = it.contentDescription?.toString()?.lowercase() ?: ""
            d.contains("play video")
        }
        if (node != null && clickNode(node)) ytPlayUntil = 0L
    }
}
